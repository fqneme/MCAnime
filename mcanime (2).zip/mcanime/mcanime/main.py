"""Entry point for STAND BATTLE: STARDUST SHOWDOWN."""
import os

# Keep the integer-scaled pixel canvas sharp on Windows high-DPI displays.
os.environ.setdefault("SDL_WINDOWS_DPI_AWARENESS", "permonitorv2")

from game.app import Game

if __name__ == "__main__":
    Game().run()
