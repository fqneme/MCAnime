# Build log / code diffs

Every file in this repository is new, so the "diff" for each step is an
addition. The hunks below are the load-bearing parts of each step; the complete
files live in `game/`.

---

## Step 1 — Project structure and 2D pixel-art rendering

**Added:** `main.py`, `game/config.py`, `game/font.py`, `game/app.py`,
`game/stage.py`, `game/sprites.py`, `game/__init__.py`

The game renders into a fixed 480x270 surface and only scales it at the very
end, so every sprite, particle and glyph is a real pixel.

```diff
--- /dev/null
+++ b/game/app.py
+class Game:
+    def __init__(self):
+        pygame.init()
+        self.settings = self._load_settings()
+        self.windowed_size = self._best_window_size()
+        self._apply_display()
+        self.canvas = pygame.Surface((GAME_W, GAME_H)).convert()
+        self.audio = AudioManager(self.settings)
+        self.stage = Stage()
+        self.screen = MenuScreen(self)
+
+    def run(self):
+        while self.running:
+            dt = min(self.clock.tick(FPS) / 1000.0, 0.05)
+            for event in pygame.event.get():
+                ...
+            self.screen.update(dt)
+            self.screen.draw(self.canvas)
+            self._present()
+            pygame.display.flip()
+
+    def _present(self):
+        w, h = self.window.get_size()
+        scale = max(1, min(w // GAME_W, h // GAME_H))
+        scaled = pygame.transform.scale(self.canvas, (GAME_W * scale, GAME_H * scale))
+        self.window.blit(scaled, ((w - GAME_W * scale) // 2,
+                                  (h - GAME_H * scale) // 2))
```

```diff
+++ b/game/font.py
+# Hand-authored 5x7 glyphs -> crisp UI at any integer scale.
+_G = {
+    "A": ("01110", "10001", "10001", "11111", "10001", "10001", "10001"),
+    ...
+}
+def draw_text(surface, text, x, y, scale=1, color=UI_TEXT, shadow=None,
+              outline=None, align="left", gradient=None):
+    img = _render(text.upper(), scale, color, shadow, outline, gradient)
+    surface.blit(img, (x - 2 * scale, y - 2 * scale))
```

Fighters are drawn procedurally from a joint pose, not from sprite sheets:

```diff
+++ b/game/sprites.py
+def draw_fighter(surface, f, t):
+    pose = build_pose(f, t)
+    ...
+    _limb(surface, hip, knee_b, 6, colors["legs_dark"], out)
+    _limb(surface, knee_b, foot_b, 6, colors["legs_dark"], out)
+    _draw_torso(surface, f, colors, hip, neck, facing)
+    _limb(surface, hip, knee_f, 7, colors["legs"], out)
+    _draw_head(surface, f, colors, head, neck, facing, t)
+    _limb(surface, shoulder, elbow_f, 4, colors["uniform"], out)
```

---

## Step 2 — WASD movement and basic punch/kick

**Added:** `game/moves.py`, `game/fighter.py`

```diff
--- /dev/null
+++ b/game/moves.py
+@dataclass(frozen=True)
+class Move:
+    key: str
+    name: str
+    startup: float
+    active: float
+    recovery: float
+    damage: float = 0.0
+    hit_times: tuple[float, ...] = ()
+    hitstun: float = 0.25
+    knockback: float = 90.0
+    reach: float = 44.0
+    cooldown: float = 0.3
+    ...
+
+JOTARO_BASE = {
+    "z": Move(key="jab", startup=0.07, active=0.06, recovery=0.14,
+              damage=5, hit_times=(0.09,), hitstun=0.20, knockback=80,
+              reach=41, cooldown=0.20, sound="punch_light"),
+    "x": Move(key="kick", startup=0.11, active=0.08, recovery=0.20,
+              damage=8, hit_times=(0.14,), knockback=150, reach=49),
+}
```

```diff
+++ b/game/fighter.py
+GRAVITY = 980.0
+JUMP_V = -330.0
+WALK_SPEED = 104.0
+
+def update(self, dt, opponent, game, frozen=False):
+    ...
+    if self.on_ground:
+        self.face(opponent)
+        if self.input_block:
+            self.state = "block"
+        elif self.input_crouch:
+            self.state = "crouch"
+        elif self.input_x:
+            self.state = "walk"
+            self.x += self.input_x * WALK_SPEED * dt
+        else:
+            self.state = "idle"
+        if self.jump_requested:
+            self.jump(game)
+    self._physics(dt)
+
+def _physics(self, dt):
+    if not self.on_ground:
+        self.vy += GRAVITY * dt
+        self.jump_y -= self.vy * dt
+        if self.jump_y <= 0:
+            self.jump_y = 0
+            self.vy = 0
+            self.on_ground = True
```

Attack resolution walks the hit windows and asks the screen for a hit test:

```diff
+def _update_attack(self, dt, opponent, game):
+    prev = self.move_t
+    self.move_t += dt
+    for i, ht in enumerate(m.hit_times):
+        if i not in self.hit_done and prev < ht <= self.move_t:
+            self.hit_done.add(i)
+            game.try_hit(self, opponent, m)
+    if self.move_t >= m.duration:
+        self.state = "idle"
+        self.move = None
```

---

## Step 3 — Stand toggle (Q) and alternate move sets

**Added:** `MOVE_SETS[(character, stand)]`, `try_toggle_stand`, Stand rendering.

```diff
+++ b/game/moves.py
+MOVE_SETS = {
+    ("jotaro", False): JOTARO_BASE,
+    ("jotaro", True): JOTARO_STAND,   # ORA / Star Finger
+    ("dio", False): DIO_BASE,
+    ("dio", True): DIO_STAND,         # MUDA / Road Roller
+}
+def get_move(character, stand, slot):
+    return MOVE_SETS[(character, stand)].get(slot)
```

```diff
+++ b/game/fighter.py
+def try_attack(self, slot, game):
+    if not self.can_act():
+        return False
+    move = get_move(self.character, self.stand_active, slot)
+    ...
+    self.cooldowns[move.key] = move.cooldown
+    self.state = "heal" if move.special in ("heal", "heal_instant") else "attack"
+
+def try_toggle_stand(self, game):
+    if not self.can_act() or self.stand_flash > 0:
+        return False
+    self.stand_active = not self.stand_active
+    self.stand_flash = 0.28
+    self.summon_pose = 0.45 if self.stand_active else 0.0
+    game.audio.play("whoosh", 0.7)
+    ...
```

The Stand itself is a separate translucent skeleton with its own poses:

```diff
+++ b/game/sprites.py
+def draw_stand(surface, f, t):
+    attacking = f.state == "attack" and f.move is not None
+    offset = 8 if attacking else -20
+    ...
+    if f.move.key in ("ora", "muda"):
+        # three afterimage arms
+    elif f.move.key in ("ora_kick", "muda_kick"):
+        # extended kick leg
+    elif f.move.key == "star_finger":
+        # 178px glowing finger beam
+    elif f.ult_pose > 0:
+        # arms spread during stopped time
```

---

## Step 4 — Time Stop ultimate (R)

**Added:** `FightScreen.start_time_stop`, `end_time_stop`, frozen update skip,
clock overlay, music ducking, free-combo behaviour.

```diff
+++ b/game/fighter.py
+def try_ult(self, game):
+    if not self.can_act() or not self.stand_active:
+        return False
+    if self.ult < self.max_ult - 0.01:
+        return False
+    self.ult = 0.0
+    self.ult_pose = 1.2
+    game.start_time_stop(self)
+    return True
```

```diff
+++ b/game/screens.py
+def start_time_stop(self, owner):
+    self.time_stop_owner = owner
+    self.time_stop_timer = 3.0
+    self.game.audio.set_duck(0.22)
+    self.game.audio.ultimate_voice(
+        "za_warudo" if owner.character == "dio" else "star_platinum_world")
+    self.effects.add_flash(0.85)
+    self.effects.add_shake(1.0)
+
+def update(self, dt):
+    ...
+    if self.time_stop_owner is not None:
+        self.time_stop_timer -= dt
+        if self.time_stop_timer <= 0:
+            self.end_time_stop()
+    frozen_player = self.is_frozen(self.player)
+    frozen_enemy = self.is_frozen(self.enemy)
+    if not frozen_player:
+        self.player.update(dt, self.enemy, self)
+    if not frozen_enemy:
+        self.enemy.update(dt, self.player, self)
```

The frozen fighter is also excluded from the AI update and gets a blue aura:

```diff
+def _update_ai(self, dt):
+    if self.is_frozen(self.enemy):
+        self.enemy.input_x = 0
+        self.enemy.input_block = False
+        return
+    self.ai.update(dt, self.player, self)
```

---

## Step 5 — CPU state machine

**Added:** `game/ai.py`

```diff
--- /dev/null
+++ b/game/ai.py
+class AI:
+    def update(self, dt, opponent, game):
+        # 1. react to the start of a player attack -> block
+        if opponent.state == "attack" and self.prev_opp_state != "attack":
+            if abs(opponent.x - f.x) < 96 and random.random() < self.d["block"]:
+                self.block_t = random.uniform(0.28, 0.5)
+
+        # 2. heal when low, but only in base form
+        if f.hp < 48 and base_c <= 0 and dist > 55:
+            if f.stand_active:
+                f.try_toggle_stand(game)
+            else:
+                f.try_attack("c", game)
+
+        # 3. ultimate when the meter is full
+        if f.ult >= f.max_ult - 0.5:
+            if not f.stand_active:
+                f.try_toggle_stand(game)
+            elif dist < 150:
+                f.try_ult(game)
+
+        # 4. Walk -> Attack -> Block
+        if dist > 62:
+            f.input_x = direction
+        elif dist < 34:
+            f.input_x = -direction
+        else:
+            if r < self.d["aggression"]:
+                f.try_attack("z" if random.random() < 0.55 else "x", game)
+            elif r < self.d["aggression"] + 0.2:
+                self.block_t = random.uniform(0.2, 0.4)
```

---

## Step 6 — Character heals / utilities

**Added:** cigarette, blood bottle, their cooldowns and interruption rules.

```diff
+++ b/game/moves.py
+"c": Move(key="smoke", name="CIGARETTE", recovery=3.0, cooldown=9.0,
+          special="heal", heal_total=18.0, heal_duration=3.0),
+"c": Move(key="blood", name="BLOOD BOTTLE", recovery=0.9, cooldown=13.0,
+          special="heal_instant", heal_total=26.0, heal_duration=0.9),
```

```diff
+++ b/game/fighter.py
+def _update_heal(self, dt, game):
+    if m.special == "heal":
+        # Jotaro: slow 6 HP/s heal over 3 seconds
+        amount = min(self.heal_left, self.heal_rate * dt)
+        self.heal_left -= amount
+        self.hp = min(self.max_hp, self.hp + amount)
+        game.effects.add_smoke(self.x + 6 * self.facing, self.feet_y - 78)
+    else:
+        # DIO: one big gulp after 0.45s
+        if not self.heal_done and self.move_t >= 0.45:
+            self.hp = min(self.max_hp, self.hp + m.heal_total)
+
+def receive_hit(self, damage, move, attacker, blocked, game):
+    # Taking a hit interrupts the cigarette / bottle.
+    if self.state == "heal":
+        self.heal_left = 0.0
+        game.effects.add_text(..., "INTERRUPTED!", ...)
+        self.state = "hurt"
```

---

## Step 7 — CC0 audio and pitch processing

**Added:** `game/audio.py`, `assets/audio/*`, `tools/gen_voice.py`

Impact sample families are grouped and pitch-shifted at load time:

```diff
--- /dev/null
+++ b/game/audio.py
+def _resample(arr, speed):
+    n = max(1, int(len(arr) / speed))
+    src = np.linspace(0.0, len(arr) - 1, n)
+    return np.interp(src, np.arange(len(arr)), arr).astype(np.int16)
+
+families = {
+    "punch_light": (0.90, 1.0, 1.10),
+    "punch_heavy": (0.88, 1.0, 1.12),
+    "kick_medium": (0.92, 1.0, 1.08),
+    "kick_heavy": (0.90, 1.0, 1.10),
+    "whoosh": (0.88, 1.0, 1.12),
+    ...
+}
+for name, ratios in families.items():
+    group = [snd for key, snd in self.sounds.items()
+             if key == name or (key.startswith(name + "_") and key[len(name)+1:].isdigit())]
+    self.sounds[name] = group[0]
+    bucket = list(group)
+    for r in ratios:
+        bucket.append(_make_sound(_resample(array(group[0]), r)))
+    self.variants[name] = bucket
```

Voice cues are generated offline (not mathematically synthesised from scratch):

```diff
--- /dev/null
+++ b/tools/gen_voice.py
+LINES = [
+    ("ora_ora", "オラオラオラオラオラ！", "ja-JP-KeitaNeural", "+10%", "-4Hz", 0.94),
+    ("muda_muda", "無駄無駄無駄無駄無駄！", "ja-JP-KeitaNeural", "+5%", "-8Hz", 0.86),
+    ("za_warudo", "ザ・ワールド！時を止まれ！", ...),
+    ("star_platinum_world", "スタープラチナ・ザ・ワールド！時を止まれ！", ...),
+    ("road_roller", "ロードローラーだ！", ...),
+    ("star_finger", "スターフィンガー！", ...),
+]
+
+def process(arr, speed):
+    arr = speed_change(arr, speed)       # tape-style pitch shift
+    arr = np.tanh(arr * 2.2) * 0.62      # tube saturation
+    for delay_ms, gain in ((85, 0.22), (170, 0.10)):
+        ...                              # slap-back echo
+    return fade_and_clip(arr)
```

CC0 sources: Kenney *Impact Sounds*, *Foley/Woosh*, *UI Audio*,
*Voiceover Pack Fighter*, *Music Loops* (CC0 1.0), mirrored by
gamesounds.xyz. No anime audio was ripped.

---

## Step 8 — Main menu, HUD and polish
**Added:** `game/ui.py`, `game/screens.py`

```diff
--- /dev/null
+++ b/game/ui.py
+def draw_hud(surface, player, enemy, time_left, combo, ...):
+    draw_health_bar(surface, 46, 11, 166, 14, player.hp, player_ghost, GREEN)
+    draw_health_bar(surface, 268, 11, 166, 14, enemy.hp, enemy_ghost, GREEN, flip=True)
+    draw_star_icon(surface, 52, 43, p_col, 2)
+    font.draw_text(surface, "STAND OUT" if player.stand_active else "STAND OFF",
+                   60, 39, 1, p_col)
+    draw_ult_bar(surface, 14, 252, 148, 7, player.ult, PURPLE, label="ULTIMATE")
+    if player.ult >= 100:
+        font.draw_text(surface, "R  TIME STOP READY", 148, 261, 1, pulsing_gold)
+```

```diff
+++ b/game/screens.py
+class MenuScreen(Screen):
+    ITEMS = ["FIGHT", "SETTINGS", "INFO", "QUIT"]
+    def _activate(self):
+        if self.selected == 0:
+            self.game.set_screen(SelectScreen(self.game))
+        elif self.selected == 1:
+            self.game.set_screen(SettingsScreen(self.game))
+        elif self.selected == 2:
+            self.game.set_screen(InfoScreen(self.game))
+        else:
+            self.game.quit()
+
+class FightScreen(Screen):
+    def __init__(self, game, player_char="jotaro", enemy_char="dio"):
+        self.player = Fighter(player_char, 152, 1)
+        self.enemy = Fighter(enemy_char, 328, -1, is_ai=True)
+        self.ai = AI(self.enemy, game.settings["difficulty"])
+        self.phase = "intro"      # intro -> fight -> ko -> results
+        self.time_left = 99.0
+```

---

## Step 9 — Imported sprite art + code-driven animation

**Added:** `game/art.py`, `tools/build_sprites.py`, `assets/characters/*`
**Changed:** `game/sprites.py` (sprite path + procedural fallback), `game/screens.py`
(draw order, separation guard), `game/app.py` (load after display init)

### 9a. Importing and cleaning the images

`tools/build_sprites.py` cuts the 4x3 reference sheet into 12 figures and makes
each one game-ready. Background removal works for both alpha sources and flat
opaque backgrounds:

```diff
--- /dev/null
+++ b/tools/build_sprites.py
+ROW_BANDS = [(10, 256), (256, 506), (510, 756), (762, 1016)]
+COL_BANDS = [(560, 780), (805, 1030), (1070, 1220)]
+ROW_NAMES = ["dio", "the_world", "jotaro", "star_platinum"]
+VIEWS = ["front", "back", "side"]
+
+def strip_background(img, thresh=96):
+    arr = np.array(img.convert("RGBA"))
+    if arr[:, :, 3].min() > 250:          # fully opaque source
+        arr = _flood_key(arr, tolerance=40)   # border flood fill
+    hard = np.where(arr[:, :, 3] >= thresh, 255, 0).astype(np.uint8)
+    # de-halo: kill the light AA fringe left on the outline
+    light = (arr[:, :, :3].mean(axis=2) > 205) & (hard > 0)
+    arr[:, :, :3][light] = (arr[:, :, :3][light] * 0.35)
+    arr[:, :, 3] = hard
+    out = Image.fromarray(arr, "RGBA")
+    return out.crop(out.getbbox())
+
+def resize_to_height(img, height):
+    small = img.resize((..., height), Image.BOX)     # area downsample
+    arr = np.array(small).astype(np.float32)
+    blur[:, 1:] = (arr[:, 1:] + arr[:, :-1]) / 2
+    sharp = np.clip(arr * 1.45 - blur * 0.45, 0, 255)  # unsharp mask
+    sharp[:, :, 3] = np.where(sharp[:, :, 3] > 120, 255, 0)
+    return Image.fromarray(sharp, "RGBA")
```

Output: `jotaro_front/side/back.png` (96 px tall), `star_platinum_*.png`
(104 px), `the_world_*.png`, plus 40x40 `*_portrait.png` head crops.

### 9b. Stand tinting by hue shift / colour overlay

```diff
--- /dev/null
+++ b/game/art.py
+STAND_TINT = {"jotaro": (150, 96, 236), "dio": (255, 224, 132)}
+STAND_TINT_STRENGTH = {"jotaro": 0.40, "dio": 0.55}
+STAND_HUE = {"jotaro": 205.0, "dio": 62.0}   # fallback if no Stand art
+
+def colorize(surf, color, strength=0.45):
+    arr = pygame.surfarray.array3d(surf).astype(np.float32)
+    luma = arr.mean(axis=2, keepdims=True) / 255.0
+    target = np.array(color, dtype=np.float32)[None, None, :] / 255.0
+    tint = target * np.clip(luma * 2.1, 0.0, 1.0)   # keep outlines dark
+    rgb = arr * (1.0 - strength) + tint * 255.0 * strength
+    ...
+
+def hue_shift(surf, degrees, sat_mul=1.0, val_mul=1.0):
+    hsv = _rgb_to_hsv(arr)
+    hsv[:, :, 0] = (hsv[:, :, 0] + degrees) % 360.0
+    ...
```

```diff
+            if views:
+                self.stands[char] = {
+                    view: colorize(self._normalize(s, STAND_H),
+                                   STAND_TINT[char], STAND_TINT_STRENGTH[char])
+                    for view, s in views.items()
+                }
+            elif char in self.fighters:
+                # no Stand art: hue-shift the fighter's own sprite
+                self.stands[char] = {
+                    view: hue_shift(s, STAND_HUE[char], 1.25, 1.05)
+                    for view, s in self.fighters[char].items()
+                }
```

### 9c. Code-driven animation (no hand-drawn frames)

```diff
+def attack_curve(move, move_t):
+    if move_t < move.startup:
+        return 0.35 * (move_t / move.startup)
+    if move_t < move.startup + move.active:
+        return 1.0
+    rem = (move_t - move.startup - move.active) / move.recovery
+    return max(0.0, 1.0 - _ease_out(rem))
+
+def compute_transform(f, t):
+    out = {"sx": 1.0, "sy": 1.0, "angle": 0.0, "dx": 0.0, "dy": 0.0, "alpha": 255}
+    breathe = math.sin(t * 2.4 + f.anim_t * 0.7)
+
+    if f.state == "ko":                     # topple + settle
+        k = _ease_out(min(1.0, f.ko_timer / 0.55))
+        out["angle"] = -72 * k * facing
+        out["dy"] = 10 * k
+    if f.state == "hurt":                   # snappy recoil
+        k = max(0.0, min(1.0, f.hurt_t / 0.22))
+        out["angle"] = -9 * k * facing
+        out["dx"] = -5 * k * facing + math.sin(f.anim_t * 70) * 0.5 * k
+        out["sx"] = 1.0 + 0.05 * k
+    if not f.on_ground:                     # stretch up, squash down
+        k = min(1.0, abs(f.vy) / 330.0)
+        out["sx"] = 1.0 - 0.07 * k
+        out["sy"] = 1.0 + 0.09 * k
+    if f.state == "crouch":
+        out["sx"], out["sy"] = 1.10, 0.80
+    if f.state == "attack" and f.move is not None:
+        ext = attack_curve(f.move, f.move_t)
+        if f.move.key in ("jab", "punch"):
+            out["sx"] = 1.0 + 0.10 * ext
+            out["sy"] = 1.0 - 0.06 * ext
+            out["dx"] = 3.0 * ext * facing
+        elif f.move.key in ("ora", "muda"):
+            jitter = math.sin(f.move_t * 62.0)
+            out["sx"] = 1.0 + 0.055 * ext + 0.015 * jitter
+            out["dx"] = (2.5 * ext + 0.8 * jitter) * facing
+    if f.state == "walk":
+        out["dy"] = -abs(math.sin(f.anim_t * 9.0)) * 2.6
+    # idle breathing
+    out["dy"] = breathe * 1.8
+    out["sx"] = 1.0 + 0.016 * breathe
+    out["sy"] = 1.0 - 0.014 * breathe
+```

Frames are produced by scaling/rotating/flipping a cached surface:

```diff
+    def framed(self, char, view, facing, sx, sy, angle=0.0, stand=False, alpha=255):
+        base = self.stand_surface(char, view) if stand else self.fighter_surface(char, view)
+        w = max(1, int(round(base.get_width() * sx)))
+        h = max(1, int(round(base.get_height() * sy)))
+        a = int(round(angle / 2.0)) * 2          # quantised so the cache hits
+        key = (char, view, facing, w, h, a, stand, alpha)
+        def build():
+            surf = pygame.transform.scale(base, (w, h))
+            if facing < 0:
+                surf = pygame.transform.flip(surf, True, False)
+            if a:
+                surf = pygame.transform.rotate(surf, a)
+            return surf
+        return self._cached(key, build)
```

### 9d. The Stand floats larger and behind

```diff
+def stand_transform(f, t):
+    bob = math.sin(t * 1.9 + 1.1)
+    out["dx"] = -34.0 * facing + sway * 1.6      # behind the fighter
+    out["dy"] = -4.0 + bob * 2.2                 # floating
+    out["sx"] = out["sy"] = 1.10                 # slightly larger
+    if f.state == "attack" and f.move.key in ("ora", "muda"):
+        out["dx"] = (-34.0 + 66.0 * ext) * facing   # lunge to the target
+    if f.ult_pose > 0 or f.state == "timestop":
+        out["dx"] = -44.0 * facing
+        out["sx"] = out["sy"] = 1.16
```

### 9e. Sprite path with procedural fallback

```diff
+++ b/game/sprites.py
+from .art import ART, draw_sprite_fighter, draw_sprite_stand
+
+ def draw_fighter(surface, f, t):
+    if draw_sprite_fighter(surface, f, t):
+        return
+    _draw_skeleton_fighter(surface, f, t)
+
+ def draw_stand(surface, f, t):
+    if draw_sprite_stand(surface, f, t):
+        return
+    _draw_skeleton_stand(surface, f, t)
+
+def draw_portrait(surface, character, x, y, scale=2, border=None, bg=None):
+    art = ART.portrait(character)
+    if art is not None:
+        size = 16 * scale
+        surface.blit(pygame.transform.scale(art, (size, size)), (x, y))
+        ...
```

Lazy loading matters: `convert_alpha()` needs a display, and the art module is
imported before `pygame.display.set_mode()`:

```diff
+class ArtLibrary:
+    def ensure_loaded(self):
+        if self.loaded or pygame.display.get_surface() is None:
+            return
+        self.loaded = True
+        self._load()
```

### 9f. Star Finger beam (still procedural)

```diff
+def draw_star_finger_beam(surface, f, t):
+    grow = max(0.0, min(1.0, (f.move_t - m.startup * 0.7) / 0.12))
+    length = (m.reach + 14) * grow
+    pygame.draw.line(layer, (*accent, 70), (lx, 11), (ex, 11), 11)   # glow
+    pygame.draw.line(layer, (*accent, 170), (lx, 11), (ex, 11), 5)   # shaft
+    pygame.draw.line(layer, (*core, 235), (lx, 11), (ex, 11), 2)     # core
+    for i in range(1, 6):                                            # knuckles
+        surface.fill(accent, (int(kx) - 1, int(y0) - 1, 3, 3))
+    pygame.draw.circle(surface, accent, tip, 4, 1)
+```

### 9g. Frozen fighters must not be pushed

Splitting the fighters apart could previously drag a Time-Stop-frozen opponent:

```diff
 def _separate(self):
+    if abs(dx) >= 46:
+        return
+    a_frozen = self.is_frozen(a)
+    b_frozen = self.is_frozen(b)
+    if a_frozen and b_frozen:
+        return
+    if a_frozen:
+        b.x += push * 2 * sign          # only the active fighter moves
+    elif b_frozen:
+        a.x -= push * 2 * sign
```

---

## Verification

```bash
python tools/simtest.py           # full matches + ultimate/roller assertions
python tools/mechtest.py          # blocking, timeout, AI ult, heal, jump
python tools/apptest.py           # real app loop through every screen
python tools/flowtest.py          # menu -> select -> fight -> results -> rematch
python tools/test_asset_layouts.py  # opaque imports + background removal
python tools/anim_strip.py        # animation strips + transform samples
python tools/screenshot.py        # regenerate shots/*.png
```
