# Audio & asset credits

## CC0 sound effects and music — Kenney (kenney.nl)

Downloaded from the CC0 mirror at <https://gamesounds.xyz/> (Kenney's Sound Pack).
All packs below are **Creative Commons Zero 1.0 Universal (CC0 1.0)** — free for
personal, educational and commercial use. Attribution is not required; this file
is included as a courtesy.

| Pack | Files used | Local names |
| --- | --- | --- |
| [Impact Sounds](https://kenney.nl/assets/impact-sounds) | `impactPunch_medium_000/001`, `impactPunch_heavy_000/001/002`, `impactSoft_medium_000/001`, `impactSoft_heavy_000/001`, `impactWood_heavy_000/001`, `impactMetal_heavy_000`, `impactPlank_medium_000`, `footstep_concrete_000/001/002` | `punch_light_*`, `punch_heavy_*`, `kick_medium_*`, `kick_heavy_*`, `roller_impact_*`, `metal_clang`, `thud`, `step_*` |
| [Foley Sounds](https://kenney.nl/assets/foley-sounds) (Woosh) | `woosh1`–`woosh4` | `whoosh_1`–`whoosh_4` |
| [UI Audio](https://kenney.nl/assets/ui-audio) | `click1`, `rollover1`, `switch2` | `ui_click`, `ui_move`, `ui_confirm` |
| [Voiceover Pack: Fighter](https://kenney.nl/assets/voiceover-pack-fighter) | voice grunts 1–10, `fight`, `winner`, `you_win`, `you_lose`, `game_over` | `grunt_*`, `announcer_*` |
| [Music Loops](https://kenney.nl/assets/music-loops) | `Time Driving`, `Infinite Descent` | `bgm_menu`, `bgm_fight` |

Kenney: <https://kenney.nl/> · CC0 text: <https://creativecommons.org/publicdomain/zero/1.0/>

## Voice cues — generated placeholders

`assets/audio/voice_*.wav` were generated locally with Microsoft Edge's neural
TTS through the open-source [`edge-tts`](https://github.com/rany2/edge-tts)
package (`ja-JP-KeitaNeural` and `en-US-GuyNeural`), then processed with numpy:

* tape-style pitch shift (resampling),
* `tanh` tube saturation,
* two slap-back echo taps,
* short fade in/out.

The text prompts are short fan phrases: **ORA ORA**, **MUDA MUDA**, **ZA
WARUDO / Star Platinum: The World**, **ROAD ROLLER DA**, **STAR FINGER**,
**YARE YARE DAZE**, **WRYYYY**, the two heal lines, and one time-resume line.
They are **not** clips from the anime and contain no copyrighted recordings.

If you plan to publish the game, replace these placeholders with your own
recorded lines or a CC0 voice pack. Regenerate/replace them by editing
`tools/gen_voice.py`.

## Code & pixel art

All game code was written for this project.

**Character and Stand sprites** are imported from the artwork supplied for this
project (`assets/characters/jojo_sheet.png` and the derived
`*_front/_side/_back/_portrait.png` files). They are processed locally by
`tools/build_sprites.py` — background removal, trim, downscale, palette
reduction — and animated entirely in code.

The stage, the Road Roller, the Star Finger beam, particles and the 5x7 bitmap
UI font are drawn procedurally in `game/`. A procedural skeleton fighter remains
in `game/sprites.py` purely as a fallback if the art files are missing.

## Disclaimer

*JoJo's Bizarre Adventure* is © Hirohiko Araki / Shueisha. This is a
non-commercial fan project, not affiliated with or endorsed by the rights
holders. Character names and Stand names are used descriptively.
