"""Headless screenshot harness for visual QA (not part of the game)."""
import os
import sys

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame  # noqa: E402

from game.app import Game  # noqa: E402
from game.screens import (  # noqa: E402
    FightScreen, InfoScreen, MenuScreen, SelectScreen, SettingsScreen,
)

OUT = os.path.join(os.path.dirname(__file__), "..", "shots")
os.makedirs(OUT, exist_ok=True)


def save(game, name, scale=3):
    img = pygame.transform.scale(game.canvas, (480 * scale, 270 * scale))
    pygame.image.save(img, os.path.join(OUT, name))


def main():
    g = Game()
    g.screen = MenuScreen(g)
    for _ in range(60):
        g.screen.update(1 / 60)
    g.screen.draw(g.canvas)
    save(g, "01_menu.png")

    g.screen = SelectScreen(g)
    for _ in range(10):
        g.screen.update(1 / 60)
    g.screen.draw(g.canvas)
    save(g, "02_select.png")

    fs = FightScreen(g, "jotaro", "dio")
    fs.phase = "fight"
    fs.phase_t = 0
    fs.hint_timer = 8
    fs.player.x = 196
    fs.enemy.x = 262
    fs.player.stand_active = True
    fs.player.stand_alpha = 1
    fs.player.anim_t = 0.5
    fs.enemy.anim_t = 0.2
    for _ in range(8):
        fs.update(1 / 60)
    fs.draw(g.canvas)
    save(g, "03_fight_idle.png")

    fs.player.try_attack("z", fs)
    for _ in range(10):
        fs.update(1 / 60)
    fs.draw(g.canvas)
    save(g, "04_ora.png")

    fs.player.try_attack("c", fs)
    for _ in range(20):
        fs.update(1 / 60)
    fs.draw(g.canvas)
    save(g, "05_star_finger.png")

    # dedicated wide-range star finger shot
    fs.player.x, fs.enemy.x = 150, 330
    fs.player.cooldowns.clear()
    fs.player.state = "idle"
    fs.player.move = None
    fs.player.try_attack("c", fs)
    for _ in range(18):
        fs.update(1 / 60)
    fs.draw(g.canvas)
    save(g, "05b_star_finger_reach.png")

    # DIO road roller
    fs2 = FightScreen(g, "dio", "jotaro")
    fs2.phase = "fight"
    fs2.phase_t = 0
    fs2.player.x = 210
    fs2.enemy.x = 280
    fs2.player.stand_active = True
    fs2.player.stand_alpha = 1
    fs2.player.ult = 100
    fs2.ai.update = lambda *a, **k: None
    fs2.player.try_attack("c", fs2)
    for _ in range(78):
        fs2.update(1 / 60)
    fs2.draw(g.canvas)
    save(g, "06_road_roller.png")

    # time stop
    fs3 = FightScreen(g, "jotaro", "dio")
    fs3.phase = "fight"
    fs3.phase_t = 0
    fs3.player.x = 210
    fs3.enemy.x = 280
    fs3.player.stand_active = True
    fs3.player.stand_alpha = 1
    fs3.player.ult = 100
    fs3.player.try_ult(fs3)
    for _ in range(30):
        fs3.update(1 / 60)
    fs3.draw(g.canvas)
    save(g, "07_time_stop.png")

    # heal pose
    fs4 = FightScreen(g, "jotaro", "dio")
    fs4.phase = "fight"
    fs4.phase_t = 0
    fs4.player.x = 210
    fs4.enemy.x = 300
    fs4.player.hp = 55
    fs4.player.try_attack("c", fs4)
    for _ in range(40):
        fs4.update(1 / 60)
    fs4.draw(g.canvas)
    save(g, "08_heal.png")

    g.screen = SettingsScreen(g)
    for _ in range(5):
        g.screen.update(1 / 60)
    g.screen.draw(g.canvas)
    save(g, "09_settings.png")

    g.screen = InfoScreen(g)
    g.screen.update(1 / 60)
    g.screen.draw(g.canvas)
    save(g, "10_info.png")

    # results
    fs5 = FightScreen(g, "jotaro", "dio")
    fs5.phase = "results"
    fs5.winner = fs5.player
    fs5.player.hp = 40
    fs5.enemy.hp = 0
    fs5.enemy.state = "ko"
    fs5.update(1 / 60)
    fs5.draw(g.canvas)
    save(g, "11_results.png")

    # pause
    fs.phase = "fight"
    fs.paused = True
    fs.draw(g.canvas)
    save(g, "12_pause.png")

    print("saved screenshots to", os.path.abspath(OUT))


if __name__ == "__main__":
    main()
