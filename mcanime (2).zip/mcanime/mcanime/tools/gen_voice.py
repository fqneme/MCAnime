"""Generate stylised voice cues for the game.

Uses Microsoft Edge's free neural TTS (edge-tts) for placeholder voice lines,
then applies pitch / saturation / echo processing with numpy and writes
16-bit mono WAVs that pygame can pitch-shift further at runtime.

Usage:  python tools/gen_voice.py
"""
from __future__ import annotations

import asyncio
import os
import wave

import edge_tts
import numpy as np
import pygame

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "audio")
SR = 44100

LINES = [
    # key, text, voice, rate, pitch, playback-speed (lower = deeper)
    ("ora_ora", "オラオラオラオラオラ！", "ja-JP-KeitaNeural", "+10%", "-4Hz", 0.94),
    ("ora_ora_2", "オラオラオラ！", "ja-JP-KeitaNeural", "+15%", "-2Hz", 0.98),
    ("muda_muda", "無駄無駄無駄無駄無駄！", "ja-JP-KeitaNeural", "+5%", "-8Hz", 0.86),
    ("muda_muda_2", "無駄無駄無駄！", "ja-JP-KeitaNeural", "+10%", "-6Hz", 0.90),
    ("za_warudo", "ザ・ワールド！時を止まれ！", "ja-JP-KeitaNeural", "-8%", "-12Hz", 0.82),
    ("star_platinum_world", "スタープラチナ・ザ・ワールド！時を止まれ！", "ja-JP-KeitaNeural", "-4%", "-2Hz", 0.93),
    ("road_roller", "ロードローラーだ！", "ja-JP-KeitaNeural", "-5%", "-10Hz", 0.84),
    ("star_finger", "スターフィンガー！", "ja-JP-KeitaNeural", "+5%", "-2Hz", 0.96),
    ("yare_yare", "やれやれだぜ…", "ja-JP-KeitaNeural", "-10%", "-2Hz", 0.92),
    ("wryyy", "WRYYYYYYY!", "en-US-GuyNeural", "+0%", "-20Hz", 0.78),
    ("heal_jotaro", "ふぅ…", "ja-JP-KeitaNeural", "-20%", "+0Hz", 0.90),
    ("heal_dio", "うまい…", "ja-JP-KeitaNeural", "-25%", "-15Hz", 0.80),
    ("time_resume", "時は動き出す。", "ja-JP-KeitaNeural", "-12%", "-10Hz", 0.84),
]


def read_sound(path: str) -> np.ndarray:
    """Load any pygame-supported file and return mono float32 @ SR."""
    snd = pygame.mixer.Sound(path)
    arr = pygame.sndarray.array(snd).astype(np.float32)
    if arr.ndim == 2:
        arr = arr.mean(axis=1)
    # pygame gives us whatever the mixer rate is; we init at SR.
    return arr


def speed_change(arr: np.ndarray, speed: float) -> np.ndarray:
    """Resample (changes pitch + length), like tape speed."""
    n = max(1, int(len(arr) / speed))
    src = np.linspace(0.0, len(arr) - 1, n)
    return np.interp(src, np.arange(len(arr)), arr).astype(np.float32)


def process(arr: np.ndarray, speed: float) -> np.ndarray:
    arr = speed_change(arr, speed)
    arr /= max(1e-6, np.max(np.abs(arr)))

    # Subtle tube saturation for a punchier, anime-grit voice.
    arr = np.tanh(arr * 2.2) * 0.62

    # Short slap-back echo (two taps) to sell the "arena" feel.
    echo = np.zeros_like(arr)
    for delay_ms, gain in ((85, 0.22), (170, 0.10)):
        d = int(SR * delay_ms / 1000)
        if d < len(arr):
            echo[d:] += arr[:-d] * gain
    arr = arr + echo

    # Fade in/out to avoid clicks.
    fade = int(SR * 0.012)
    if len(arr) > fade * 2:
        arr[:fade] *= np.linspace(0, 1, fade)
        arr[-fade:] *= np.linspace(1, 0, fade)

    arr = np.clip(arr, -1, 1)
    return (arr * 32767).astype(np.int16)


def write_wav(path: str, data: np.ndarray) -> None:
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


async def synth(key: str, text: str, voice: str, rate: str, pitch: str) -> str:
    mp3 = os.path.join(OUT, f"voice_{key}.mp3")
    comm = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await comm.save(mp3)
    return mp3


async def main() -> None:
    pygame.mixer.pre_init(SR, -16, 1, 512)
    pygame.mixer.init()
    os.makedirs(OUT, exist_ok=True)
    for key, text, voice, rate, pitch, speed in LINES:
        mp3 = await synth(key, text, voice, rate, pitch)
        raw = read_sound(mp3)
        data = process(raw, speed)
        wav = os.path.join(OUT, f"voice_{key}.wav")
        write_wav(wav, data)
        print(f"{key:14s} {len(data)/SR:5.2f}s  -> {os.path.basename(wav)}")


if __name__ == "__main__":
    asyncio.run(main())
