"""Drive the real app loop headlessly through every screen and a quick match."""
import os
import sys

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame  # noqa: E402

from game.app import Game  # noqa: E402
from game import screens  # noqa: E402

g = Game()

# replace the blocking clock with a tiny fixed step
class FakeClock:
    def tick(self, fps):
        return 16
g.clock = FakeClock()

frame = {"n": 0}
real_get = pygame.event.get

def fake_get():
    frame["n"] += 1
    if frame["n"] > 900:
        return [pygame.event.Event(pygame.QUIT)]
    return []

pygame.event.get = fake_get
g.run()
print("app loop completed", frame["n"], "frames")

# exercise every screen directly with events
g2 = Game()
for ScreenCls in (screens.MenuScreen, screens.SelectScreen, screens.SettingsScreen, screens.InfoScreen):
    s = ScreenCls(g2)
    s.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_s))
    s.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_d))
    s.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_a))
    s.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE))
    for _ in range(10):
        s.update(1 / 60)
        s.draw(g2.canvas)
    print(ScreenCls.__name__, "ok")

fs = screens.FightScreen(g2, "dio", "jotaro")
fs.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE))
fs.draw(g2.canvas)
fs.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE))
for _ in range(200):
    fs.update(1 / 60)
    fs.draw(g2.canvas)
print("FightScreen ok, phase", fs.phase)

# mouse hover/click on the main menu and character cards
g2.mouse_pos = lambda: (240, 128)  # type: ignore
menu = screens.MenuScreen(g2)
g2.set_screen(menu)
menu.handle_event(pygame.event.Event(pygame.MOUSEMOTION, pos=(720, 384), rel=(0, 0), buttons=(0, 0, 0)))
menu.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=(720, 384), button=1))
assert isinstance(g2.screen, screens.SelectScreen), type(g2.screen)
sel = g2.screen
g2.mouse_pos = lambda: (300, 120)  # type: ignore
sel.handle_event(pygame.event.Event(pygame.MOUSEMOTION, pos=(900, 360), rel=(0, 0), buttons=(0, 0, 0)))
assert sel.selected == 1, sel.selected
print("mouse hover/click ok")
print("ALL APP CHECKS PASSED")
