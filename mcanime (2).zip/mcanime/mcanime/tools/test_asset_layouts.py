"""Verify the loader against different asset layouts the user might provide.

1. ``assets/characters/jotaro.png`` etc. (one file per character, opaque white
   background, no alpha channel) -> must be keyed out and auto-tinted.
2. Sheet-only layout -> handled by the splitter in build_sprites.py.
"""
from __future__ import annotations

import os
import shutil
import sys

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame
from PIL import Image

pygame.init()
pygame.display.set_mode((320, 240))

from game.art import ArtLibrary  # noqa: E402
import tools.build_sprites as bs  # noqa: E402

TMP = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "shots", "_tmp_layout")
shutil.rmtree(TMP, ignore_errors=True)
os.makedirs(TMP)

# Build "user style" single files: front figure flattened onto pure white,
# saved as RGB (no alpha), exactly like a typical PNG the user might drop in.
sheet = Image.open(os.path.join("assets", "characters", "jojo_sheet.png")).convert("RGBA")
boxes = bs.find_sheet_boxes(sheet)
for name, out_name in (("jotaro", "jotaro"), ("dio", "dio"),
                       ("star_platinum", "star_platinum"),
                       ("the_world", "the_world")):
    crop = sheet.crop(boxes[(name, "front")])
    white = Image.new("RGB", crop.size, (255, 255, 255))
    white.paste(crop, mask=crop.split()[3])
    white.save(os.path.join(TMP, f"{out_name}.png"))

print("wrote test PNGs:", sorted(os.listdir(TMP)))

# --- background removal on a fully opaque image
opaque = Image.open(os.path.join(TMP, "jotaro.png"))
print("mode:", opaque.mode, "corner:", opaque.getpixel((1, 1)))
cut = bs.strip_background(opaque)
alpha = cut.split()[3]
print("after strip -> size:", cut.size, "alpha range:", alpha.getextrema())
assert alpha.getextrema()[0] == 0, "background not made transparent"
assert alpha.getextrema()[1] == 255, "figure lost its opacity"

# --- the library should still find fighters and stands from single files
lib = ArtLibrary(TMP)
lib.ensure_loaded()
print("fighters:", sorted(lib.fighters), "stands:", sorted(lib.stands))
print("stand source:", lib.stand_from_fighter)
assert "jotaro" in lib.fighters and "dio" in lib.fighters
assert "jotaro" in lib.stands and "dio" in lib.stands
assert lib.portrait("jotaro") is not None

img = lib.framed("jotaro", "front", 1, 1.05, 0.97, 4.0, stand=False, alpha=255)
print("framed sprite:", img.get_size())
assert img.get_width() > 10 and img.get_height() > 40

shutil.rmtree(TMP, ignore_errors=True)
print("\nLAYOUT TEST PASSED (opaque single-file assets work end to end)")
