"""Headless gameplay simulation / regression test."""
from __future__ import annotations

import os
import sys

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame  # noqa: E402

from game.app import Game  # noqa: E402
from game.screens import FightScreen  # noqa: E402

FAILS = []


def check(cond, msg):
    if not cond:
        FAILS.append(msg)
        print("FAIL:", msg)


class FakeKeys:
    def __init__(self):
        self.down = set()

    def __getitem__(self, k):
        return k in self.down


def run_bot_match(player_char, enemy_char, seconds=90, seed=1):
    """Player side is driven by a simple scripted bot so the sim is deterministic-ish."""
    import random
    random.seed(seed)
    g = Game()
    fs = FightScreen(g, player_char, enemy_char)
    fs.phase = "fight"
    fs.phase_t = 0
    fs.hint_timer = 0
    fake = FakeKeys()
    pygame.key.get_pressed = lambda: fake  # type: ignore

    dt = 1 / 60
    frames = int(seconds * 60)
    for i in range(frames):
        # scripted player behaviour
        p = fs.player
        dist = abs(fs.enemy.x - p.x)
        fake.down.clear()
        if p.can_act() and fs.phase == "fight":
            if p.ult >= 100 and p.stand_active and dist < 140:
                p.try_ult(fs)
            elif not p.stand_active and p.ult > 60:
                p.try_toggle_stand(fs)
            elif dist > 60:
                fake.down.add(pygame.K_d if fs.enemy.x > p.x else pygame.K_a)
            else:
                if i % 7 == 0:
                    p.try_attack("z", fs)
                elif i % 11 == 0:
                    p.try_attack("x", fs)
                elif i % 53 == 0:
                    p.try_attack("c", fs)
        fs.update(dt)
        if fs.phase == "results":
            break
    return fs


def main():
    for pair in (("jotaro", "dio"), ("dio", "jotaro")):
        fs = run_bot_match(*pair)
        print(f"{pair}: phase={fs.phase} p_hp={fs.player.hp:.1f} e_hp={fs.enemy.hp:.1f} "
              f"time={fs.time_left:.1f} winner={fs.winner.name if fs.winner else None}")
        check(fs.phase in ("results", "ko", "fight"), "match did not progress")
        check(fs.enemy.hp < 100 or fs.player.hp < 100, "no damage was ever dealt")
        check(fs.player.x != fs.enemy.x, "fighters overlap exactly")

    # time stop freezes the enemy and allows damage
    g = Game()
    fs = FightScreen(g, "jotaro", "dio")
    fs.phase = "fight"
    fs.phase_t = 0
    fs.player.x, fs.enemy.x = 220, 262
    fs.player.stand_active = True
    fs.player.stand_alpha = 1
    fs.player.ult = 100
    ok = fs.player.try_ult(fs)
    check(ok, "ult did not trigger with full meter + stand")
    check(fs.time_stop_owner is fs.player, "time stop owner not set")
    check(fs.player.ult == 0, "ult meter not consumed")
    frozen_x = fs.enemy.x
    hp_before = fs.enemy.hp
    for _ in range(90):  # 1.5s
        fs.update(1 / 60)
    check(abs(fs.enemy.x - frozen_x) < 0.001, "frozen enemy moved during time stop")
    fs.player.try_attack("z", fs)
    for _ in range(40):
        fs.update(1 / 60)
    check(fs.enemy.hp < hp_before, "no damage during time stop")
    check(fs.time_stop_owner is not None, "time stop ended too early")
    for _ in range(120):
        fs.update(1 / 60)
    check(fs.time_stop_owner is None, "time stop never ended")

    # ult requires stand
    fs2 = FightScreen(g, "dio", "jotaro")
    fs2.player.stand_active = False
    fs2.player.ult = 100
    check(not fs2.player.try_ult(fs2), "ult should require stand")

    # heal is interrupted by damage
    fs3 = FightScreen(g, "jotaro", "dio")
    fs3.phase = "fight"
    fs3.phase_t = 0
    fs3.player.hp = 60
    fs3.player.x, fs3.enemy.x = 220, 250
    fs3.ai.update = lambda *a, **k: None
    fs3.enemy.input_x = 0
    check(fs3.player.try_attack("c", fs3), "cigarette did not start")
    for _ in range(30):
        fs3.update(1 / 60)
    healed = fs3.player.hp
    check(healed > 60, "cigarette did not heal")
    fs3.enemy.try_attack("z", fs3)
    for _ in range(20):
        fs3.update(1 / 60)
    check(fs3.player.state != "heal" or fs3.player.hp < 70, "heal not interrupted by hit")

    # stand toggling changes move set
    fs4 = FightScreen(g, "jotaro", "dio")
    fs4.phase = "fight"
    fs4.phase_t = 0
    base = fs4.player.try_attack("z", fs4)
    check(base and fs4.player.move.key == "jab", "base punch wrong move")
    fs4.player.state = "idle"
    fs4.player.move = None
    fs4.player.cooldowns.clear()
    fs4.player.try_toggle_stand(fs4)
    fs4.player.state = "idle"
    fs4.player.stand_flash = 0
    fs4.player.cooldowns.clear()
    fs4.player.try_attack("z", fs4)
    check(fs4.player.move is not None and fs4.player.move.key == "ora", "stand punch wrong move")

    # road roller spawns and damages
    fs5 = FightScreen(g, "dio", "jotaro")
    fs5.phase = "fight"
    fs5.phase_t = 0
    fs5.player.x, fs5.enemy.x = 210, 250
    fs5.player.stand_active = True
    fs5.player.stand_alpha = 1
    fs5.ai.update = lambda *a, **k: None  # keep the dummy still for a clean test
    fs5.enemy.input_x = 0
    fs5.player.try_attack("c", fs5)
    for _ in range(160):
        fs5.update(1 / 60)
    check(len(fs5.rollers) > 0 or fs5.enemy.hp < 100, "road roller never spawned/hit")
    check(fs5.enemy.hp < 100, "road roller did not damage")

    # ai never softlocks
    fs6 = run_bot_match("jotaro", "dio", seconds=25)
    check(fs6.enemy.state != "ko" or fs6.enemy.ko_timer > 0, "enemy stuck in ko")

    print("\nRESULT:", "ALL CHECKS PASSED" if not FAILS else f"{len(FAILS)} FAILURES")
    return 1 if FAILS else 0


if __name__ == "__main__":
    raise SystemExit(main())
