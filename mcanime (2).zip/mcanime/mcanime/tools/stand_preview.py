"""Side-by-side proof sheet: fighters vs. their tinted Stands."""
from __future__ import annotations

import os

import harness  # noqa: F401

import pygame

from game.art import ART, STAND_TINT, colorize
from game.app import Game

OUT = os.path.join(harness._ROOT, "shots")
g = Game()

PAD = 10
rows = [("jotaro", "side"), ("jotaro", "front"), ("dio", "side"), ("dio", "front")]
cols = ["fighter", "stand", "stand_on_dark"]
cell_w, cell_h = 110, 130
sheet = pygame.Surface((cell_w * len(cols), cell_h * len(rows)))
sheet.fill((26, 22, 34))

for r, (char, view) in enumerate(rows):
    fighter = ART.fighter_surface(char, view)
    stand = ART.stand_surface(char, view)
    for c, kind in enumerate(cols):
        surf = fighter if kind == "fighter" else stand
        if surf is None:
            continue
        img = pygame.transform.scale(surf, (surf.get_width() * 1, surf.get_height() * 1))
        x = c * cell_w + (cell_w - img.get_width()) // 2
        y = r * cell_h + cell_h - PAD - img.get_height()
        sheet.blit(img, (x, y))

pygame.image.save(pygame.transform.scale(sheet, (sheet.get_width() * 3,
                                                 sheet.get_height() * 3)),
                  os.path.join(OUT, "_stand_compare.png"))

# Stand-only showcase at 2x for clarity
show = pygame.Surface((460, 230))
show.fill((20, 16, 28))
x = 10
for char in ("jotaro", "dio"):
    for label, surf in (("fighter", ART.fighter_surface(char, "side")),
                        ("stand", ART.stand_surface(char, "side"))):
        img = pygame.transform.scale(surf, (surf.get_width() * 2, surf.get_height() * 2))
        show.blit(img, (x, 220 - img.get_height()))
        x += img.get_width() + 14
pygame.image.save(pygame.transform.scale(show, (show.get_width() * 3,
                                                show.get_height() * 3)),
                  os.path.join(OUT, "_stand_showcase.png"))
print("saved shots/_stand_compare.png and _stand_showcase.png")
