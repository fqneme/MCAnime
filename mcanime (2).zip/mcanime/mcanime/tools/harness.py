"""Shared bootstrap for the headless test/QA tools.

Import this *before* `game.app` so the settings file used by tests is a
throwaway temp file instead of the player's real ``settings.json``.
"""
from __future__ import annotations

import os
import sys

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

_TMP = os.path.join(os.environ.get("TEMP", _ROOT), "mcanime_test_settings.json")
if not os.path.exists(_TMP):
    with open(_TMP, "w", encoding="utf-8") as f:
        f.write("{}")
os.environ["MCANIME_SETTINGS"] = _TMP

import pygame  # noqa: E402

# Fixed-step clock so the app loop can run headlessly without sleeping.
class FixedClock:
    def tick(self, fps):
        return 16


def use_fixed_clock(game):
    game.clock = FixedClock()
    return game
