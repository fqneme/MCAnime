import os
import sys

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame  # noqa: E402

from game.app import Game  # noqa: E402
from game.screens import (  # noqa: E402
    FightScreen, MenuScreen, SelectScreen, SettingsScreen, InfoScreen,
)

g = Game()
menu = MenuScreen(g)
g.set_screen(menu)
menu.selected = 0
menu._activate()
assert isinstance(g.screen, SelectScreen), type(g.screen)
sel = g.screen
sel.selected = 1
sel._start()
assert isinstance(g.screen, FightScreen)
fs = g.screen
assert fs.player.character == "dio" and fs.enemy.character == "jotaro"
fs.phase, fs.phase_t = "fight", 0
fs.enemy.hp = 1
fs.enemy.receive_hit(10, fs.player.move or type("M", (), {"hitstun": 0.2, "knockback": 0, "special": "", "key": "x", "damage": 10})(), fs.player, False, fs)
assert fs.phase == "ko", fs.phase
for _ in range(230):
    fs.update(1 / 60)
assert fs.phase == "results", fs.phase
fs.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN))
assert isinstance(g.screen, FightScreen) and g.screen is not fs
# pause -> main menu
fs2 = g.screen
fs2.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE))
for _ in range(2):
    fs2.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_s))
fs2.handle_event(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN))
assert isinstance(g.screen, MenuScreen), type(g.screen)
print("FLOW OK: menu -> select -> fight -> results -> rematch -> pause -> menu")
