"""Import the Ken Kaneki source atlases into per-animation PNG frame folders.

The three source sheets in ``assets/Kaneki_Source`` are AI-generated concept
atlases: each animation occupies its own horizontal strip, introduced by a
black label plate, and the sprites are *not* on a regular grid (frames have
different widths, some touch each other, some are split into several connected
components).

The tool therefore segments **by hand-authored region** (x-range, y-range,
expected frame count and row count, taken from the label layout of each sheet)
and then splits each region into exactly that many frames using a column
occupancy valley search. No frame is invented: if a region cannot be split into
the expected count the tool reports it and writes what it found.

Per frame it then trims to the alpha bbox, hardens the alpha (the atlas has a
soft anti-aliased edge), de-halos the light fringe, and downscales with one
uniform scale per form so the character never changes size between animations.

Output:
    assets/characters/kaneki/<form>/<animation>/frame_NNN.png
    assets/characters/kaneki/manifest.json

Run:  python tools/build_kaneki.py
"""
from __future__ import annotations

import json
import os

import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "assets", "Kaneki_Source")
DST = os.path.join(ROOT, "assets", "characters", "kaneki")

SHEETS = {
    "normal": "kaneki_normal.png",
    "centipede": "kaneki_centipede.png",
    "kagune": "kaneki_kagune.png",
}

# form -> [(animation, x0, x1, y0, y1, frames, rows), ...]
# Values were read off the label plates of each atlas.
REGIONS = {
    "normal": [
        ("idle", 20, 600, 97, 242, 7, 1),
        ("walk", 700, 1520, 97, 242, 9, 1),
        ("kagune_release", 20, 760, 300, 478, 8, 1),
        ("kagune_hide", 790, 1500, 300, 478, 7, 1),
        ("punch", 20, 740, 540, 710, 6, 1),
        ("kick", 800, 1515, 540, 710, 7, 1),
        ("bite", 8, 715, 776, 972, 6, 1),
        ("kagune_barrage", 760, 1532, 776, 972, 6, 1),
    ],
    "centipede": [
        ("transformation", 12, 1055, 10, 198, 7, 1),
        ("idle", 2, 775, 198, 385, 6, 1),
        ("walk", 815, 1530, 198, 385, 6, 1),
        ("punch", 6, 785, 386, 562, 6, 1),
        ("kick", 815, 1525, 386, 562, 7, 1),
        ("bite", 2, 755, 566, 768, 6, 1),
        ("kagune_barrage", 755, 1532, 566, 768, 7, 1),
        ("return_transformation", 2, 1515, 796, 975, 13, 1),
    ],
    "kagune": [
        ("idle", 5, 762, 38, 197, 5, 1),
        ("release", 765, 1532, 38, 197, 5, 1),
        ("hide", 5, 712, 236, 382, 6, 1),
        ("barrage_start", 752, 1528, 236, 382, 5, 1),
        ("barrage_loop", 5, 1532, 415, 848, 30, 3),
        ("barrage_end", 5, 662, 855, 1008, 5, 1),
        ("aftermath", 652, 1532, 855, 1008, 10, 1),
    ],
}

# Target heights in game pixels (canvas 480x270, JoJo fighters are 96 tall).
TARGET_H = {"normal": 96, "centipede": 100, "kagune": 88}

# Which animations loop (everything else plays once).
LOOPS = {
    "normal": {"idle", "walk"},
    "centipede": {"idle", "walk"},
    "kagune": {"idle", "barrage_loop"},
}

# Playback rate, frames per second.
FPS = {
    "normal": {"idle": 8, "walk": 12, "kagune_release": 14, "kagune_hide": 14,
               "punch": 16, "kick": 14, "bite": 12, "kagune_barrage": 16},
    "centipede": {"transformation": 12, "idle": 8, "walk": 12, "punch": 16,
                  "kick": 14, "bite": 12, "kagune_barrage": 16,
                  "return_transformation": 12},
    "kagune": {"idle": 8, "release": 14, "hide": 14, "barrage_start": 16,
               "barrage_loop": 22, "barrage_end": 16, "aftermath": 12},
}

ALPHA_CUT = 96        # atlas alpha is soft; above this is solid
HARD_ALPHA = 110      # threshold re-applied after downscaling
LABEL_MAX_H = 46
LABEL_MIN_W = 55


# ------------------------------------------------------------- segmentation
def components(mask: np.ndarray):
    """8-connected components via union-find over horizontal runs."""
    h = mask.shape[0]
    parent: list[int] = []

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        ri, rj = find(i), find(j)
        if ri != rj:
            parent[rj] = ri

    prev: list[tuple[int, int, int]] = []
    boxes: list[list[int]] = []
    for y in range(h):
        row = mask[y]
        if not row.any():
            prev = []
            continue
        d = np.diff(np.concatenate(([0], row.astype(np.int8), [0])))
        starts = np.flatnonzero(d == 1)
        ends = np.flatnonzero(d == -1)
        cur = []
        for x0, x1 in zip(starts, ends):
            idx = len(parent)
            parent.append(idx)
            boxes.append([x0, y, x1 - 1, y])
            cur.append((x0, x1 - 1, idx))
        for ax0, ax1, ai in cur:
            for bx0, bx1, bi in prev:
                if ax0 - 1 <= bx1 and bx0 - 1 <= ax1:
                    union(ai, bi)
        prev = cur

    merged: dict[int, list[int]] = {}
    for i, b in enumerate(boxes):
        r = find(i)
        c = merged.setdefault(r, [b[0], b[1], b[2], b[3], 0])
        c[0] = min(c[0], b[0])
        c[1] = min(c[1], b[1])
        c[2] = max(c[2], b[2])
        c[3] = max(c[3], b[3])
        c[4] += b[2] - b[0] + 1
    return [tuple(v) for v in merged.values()]


def find_labels(rgba: np.ndarray, comps):
    """The black animation-name plates: short, wide, dark, white lettering."""
    labels = []
    for (x0, y0, x1, y1, area) in comps:
        w = x1 - x0 + 1
        h = y1 - y0 + 1
        if h > LABEL_MAX_H or w < LABEL_MIN_W or w / h < 1.8:
            continue
        sub = rgba[y0:y1 + 1, x0:x1 + 1]
        m = sub[:, :, 3] > ALPHA_CUT
        if m.mean() < 0.72:
            continue
        luma = sub[:, :, :3][m].astype(np.float32).mean(axis=1)
        if luma.mean() > 92 or (luma > 190).sum() < 25:
            continue
        labels.append((int(x0), int(y0), int(x1), int(y1)))
    return labels


def blank_labels(mask: np.ndarray, rgba: np.ndarray, pad: int = 3) -> np.ndarray:
    """Remove the label plates so their glyphs never end up inside a frame."""
    clean = mask.copy()
    for (x0, y0, x1, y1) in find_labels(rgba, components(mask)):
        clean[max(0, y0 - pad):y1 + pad + 1, max(0, x0 - pad):x1 + pad + 1] = False
    return clean


def bands(mask, x0, x1, y0, y1, nrows, min_gap=5):
    """Find the ``nrows`` horizontal strips inside a region."""
    sub = mask[y0:y1 + 1, x0:x1 + 1]
    rows = sub.any(axis=1)
    out = []
    start = None
    for i, v in enumerate(rows):
        if v and start is None:
            start = i
        elif not v and start is not None:
            out.append([y0 + start, y0 + i - 1])
            start = None
    if start is not None:
        out.append([y0 + start, y0 + len(rows) - 1])

    merged = []
    for b in out:
        if merged and b[0] - merged[-1][1] <= min_gap:
            merged[-1][1] = b[1]
        else:
            merged.append(list(b))

    if len(merged) > nrows:
        merged = sorted(merged, key=lambda b: -(b[1] - b[0]))[:nrows]
        merged.sort()
    while len(merged) < nrows and merged:
        # rows touch: cut the tallest strip at its emptiest scanline
        merged.sort(key=lambda b: -(b[1] - b[0]))
        big = merged.pop(0)
        prof = mask[big[0]:big[1] + 1, x0:x1 + 1].sum(axis=1).astype(float)
        half = max(1, len(prof) // 2)
        lo = max(1, half - max(2, len(prof) // 6))
        hi = min(len(prof) - 1, half + max(2, len(prof) // 6))
        cut = min(range(lo, hi + 1), key=lambda i: (prof[i], abs(i - half)))
        merged.append([big[0], big[0] + cut - 1])
        merged.append([big[0] + cut, big[1]])
        merged.sort()
    return merged


def valley_split(occ: np.ndarray, n: int):
    """Split a 1-D occupancy profile into ``n`` segments at its deepest valleys."""
    length = len(occ)
    if n <= 1 or length < n:
        return [(0, length - 1)]
    cuts = []
    for k in range(1, n):
        centre = k * length / n
        lo = int(max(1, centre - length / n * 0.42))
        hi = int(min(length - 1, centre + length / n * 0.42))
        if hi <= lo:
            cuts.append(int(round(centre)))
            continue
        seg = occ[lo:hi + 1]
        best = min(range(len(seg)), key=lambda i: (seg[i], abs(lo + i - centre)))
        cuts.append(lo + best)
    cuts = [0] + sorted(set(cuts)) + [length]
    return [(cuts[i], cuts[i + 1] - 1) for i in range(len(cuts) - 1)]


def bbox(mask, x0, x1, y0, y1):
    sub = mask[y0:y1 + 1, x0:x1 + 1]
    ys, xs = np.nonzero(sub)
    if not len(ys):
        return None
    return (x0 + int(xs.min()), y0 + int(ys.min()),
            x0 + int(xs.max()), y0 + int(ys.max()))


def column_runs(occ: np.ndarray, min_width: int = 12, join_gap: int = 2):
    """Empty-column separators inside one strip -> [(x0, x1), ...]."""
    runs = []
    start = None
    for i, v in enumerate(occ > 0):
        if v and start is None:
            start = i
        elif not v and start is not None:
            runs.append([start, i - 1])
            start = None
    if start is not None:
        runs.append([start, len(occ) - 1])
    merged = []
    for r in runs:
        if merged and r[0] - merged[-1][1] <= join_gap:
            merged[-1][1] = r[1]
        else:
            merged.append(r)
    # absorb dust / debris fragments into their neighbour
    out = []
    for r in merged:
        if out and (r[1] - r[0] + 1) < min_width:
            out[-1][1] = r[1]
        else:
            out.append(r)
    if len(out) > 1 and (out[0][1] - out[0][0] + 1) < min_width:
        out[1][0] = out[0][0]
        out.pop(0)
    return [(a, b) for a, b in out]


def sprite_runs(mask, x0, x1, y0, y1, min_area: int = 480):
    """Solid sprite bodies in a strip, ignoring loose debris components.

    The atlases scatter small blood-droplet shards around each pose; taking the
    alpha column occupancy alone would cut frames through those shards. Using
    the substantial components and then merging anything that overlaps keeps
    one figure per frame.
    """
    sub = mask[y0:y1 + 1, x0:x1 + 1]
    boxes = [c for c in components(sub) if c[4] >= min_area]
    boxes = [list(b) for b in boxes]
    changed = True
    while changed:
        changed = False
        out = []
        for b in boxes:
            for o in out:
                xo = min(b[2], o[2]) - max(b[0], o[0])
                yo = min(b[3], o[3]) - max(b[1], o[1])
                if (xo >= 0 and b[1] - o[3] <= 12 and o[1] - b[3] <= 12) or \
                   (yo >= 0 and b[0] - o[2] <= 4 and o[0] - b[2] <= 4):
                    o[0] = min(o[0], b[0]); o[1] = min(o[1], b[1])
                    o[2] = max(o[2], b[2]); o[3] = max(o[3], b[3])
                    changed = True
                    break
            else:
                out.append(b)
        boxes = out
    boxes.sort(key=lambda b: b[0])
    return [(x0 + b[0], x0 + b[2]) for b in boxes]


def body_runs(mask, x0, x1, y0, y1, expected: int):
    """Split a strip into ``expected`` figures using the lower body.

    Overlapping kagune / tentacle art merges whole rows into one blob, so the
    top-down column occupancy cannot separate the poses. The legs and feet at
    the bottom of each figure are separate though, so scanning upward from the
    ground and taking the first band that yields the wanted number of runs
    recovers the real frame boundaries.
    """
    height = y1 - y0 + 1
    for frac in (0.78, 0.74, 0.70, 0.84, 0.66, 0.62, 0.90, 0.58):
        yy0 = y0 + int(height * frac)
        if yy1 := y1:
            occ = mask[yy0:yy1 + 1, x0:x1 + 1].sum(axis=0)
            runs = column_runs(occ, min_width=10)
            if len(runs) == expected:
                return [(x0 + a, x0 + b) for a, b in runs]
    return None


def fit_frames(runs, expected: int):
    """Decide how many frames each horizontal run holds (total == expected)."""
    if not runs:
        return []
    widths = [b - a + 1 for a, b in runs]
    if len(runs) == expected:
        return [(a, b, 1) for a, b in runs]

    def counts_for(scale):
        return [max(1, int(round(w / scale))) for w in widths]

    best = None
    for scale in np.arange(20.0, max(widths) + 40.0, 1.0):
        c = counts_for(scale)
        diff = abs(sum(c) - expected)
        if best is None or diff < best[0]:
            best = (diff, scale, c)
        if diff == 0:
            break
    _, scale, c = best
    return [(a, b, n) for (a, b), n in zip(runs, c)]


def normalise_segments(segs, target: int):
    """Force the segment count to ``target`` by merging narrow / splitting wide."""
    segs = [list(s) for s in segs]
    while len(segs) > target and len(segs) > 1:
        # merge the adjacent pair with the smallest combined width
        best = min(range(len(segs) - 1),
                   key=lambda i: (segs[i][1] - segs[i][0] + 1) + (segs[i + 1][1] - segs[i + 1][0] + 1))
        segs[best][1] = segs[best + 1][1]
        segs.pop(best + 1)
    while len(segs) < target:
        i = max(range(len(segs)), key=lambda k: segs[k][1] - segs[k][0] + 1)
        a, b = segs[i]
        mid = (a + b) // 2
        if mid <= a or mid >= b:
            break
        segs[i] = [a, mid]
        segs.insert(i + 1, [mid + 1, b])
    return [(a, b) for a, b in segs]


def region_frames(mask, x0, x1, y0, y1, count, rows):
    """Return the frame bboxes for one animation region."""
    strips = bands(mask, x0, x1, y0, y1, rows)
    if not strips:
        return []
    # distribute the expected frame count across the strips by their width
    widths = [x1 - x0 + 1 for _ in strips]
    total_w = float(sum(widths)) or 1.0
    targets = [max(1, int(round(count * w / total_w))) for w in widths]
    while sum(targets) > count and max(targets) > 1:
        targets[targets.index(max(targets))] -= 1
    while sum(targets) < count:
        targets[targets.index(min(targets))] += 1

    frames = []
    for (by0, by1), per in zip(strips, targets):
        runs = sprite_runs(mask, x0, x1, by0, by1)
        plan = fit_frames(runs, per)
        segs = []
        for (a, b, n) in plan:
            w = b - a + 1
            if n == 1:
                segs.append([a, b])
            else:
                step = w / n
                for k in range(n):
                    segs.append([int(round(a + k * step)), int(round(a + (k + 1) * step)) - 1])
        for (sa, sb) in normalise_segments(segs, per):
            bb = bbox(mask, sa, sb, by0, by1)
            if bb is not None:
                frames.append(bb)
    return frames


# ------------------------------------------------------------------ cleanup
def clean_frame(rgba: np.ndarray, mask: np.ndarray, box) -> Image.Image | None:
    x0, y0, x1, y1 = box
    sub = rgba[y0:y1 + 1, x0:x1 + 1]
    hard = mask[y0:y1 + 1, x0:x1 + 1].astype(np.uint8) * 255
    if not hard.any():
        return None
    rgb = sub[:, :, :3].astype(np.float32)
    # the atlas keeps a bright AA fringe; darken it so it stops reading as a
    # white outline against the night stage
    light = (rgb.mean(axis=2) > 186) & (hard > 0)
    rgb[light] *= 0.42
    out = np.dstack([np.clip(rgb, 0, 255).astype(np.uint8), hard])
    img = Image.fromarray(out, "RGBA")
    return img.crop(img.getbbox())


def downscale(img: Image.Image, scale: float) -> Image.Image:
    w = max(1, int(round(img.width * scale)))
    h = max(1, int(round(img.height * scale)))
    arr = np.array(img.resize((w, h), Image.BOX)).astype(np.float32)
    rgb, alpha = arr[:, :, :3], arr[:, :, 3]
    hard = np.where(alpha >= HARD_ALPHA, 255, 0).astype(np.uint8)
    light = (rgb.mean(axis=2) > 186) & (hard > 0)
    rgb[light] *= 0.5
    out = np.dstack([np.clip(rgb, 0, 255).astype(np.uint8), hard])
    img2 = Image.fromarray(out, "RGBA")
    return img2.crop(img2.getbbox())


def frames_equal(a: Image.Image, b: Image.Image) -> bool:
    return a.size == b.size and np.array_equal(np.array(a), np.array(b))


# -------------------------------------------------------------------- build
def main():
    manifest = {"forms": {}, "warnings": [], "source": {}, "notes": []}
    for form, fname in SHEETS.items():
        path = os.path.join(SRC, fname)
        if not os.path.exists(path):
            manifest["warnings"].append(f"missing source sheet {fname}")
            continue
        manifest["source"][form] = fname
        rgba = np.array(Image.open(path).convert("RGBA"))
        raw_mask = rgba[:, :, 3] > ALPHA_CUT
        mask = blank_labels(raw_mask, rgba)

        # uniform scale per form, from the median standing height
        all_boxes = {}
        heights = []
        for (name, x0, x1, y0, y1, count, rows) in REGIONS[form]:
            boxes = region_frames(mask, x0, x1, y0, y1, count, rows)
            all_boxes[name] = boxes
            if len(boxes) != count:
                manifest["warnings"].append(
                    f"{form}/{name}: split into {len(boxes)} frames, "
                    f"expected {count}")
            heights.extend(b[3] - b[1] + 1 for b in boxes)
        if not heights:
            manifest["warnings"].append(f"{form}: no sprites found")
            continue
        scale = TARGET_H[form] / float(np.median(heights))

        form_dir = os.path.join(DST, form)
        info = {}
        for (name, *_rest) in REGIONS[form]:
            imgs = []
            for bb in all_boxes.get(name, []):
                img = clean_frame(rgba, mask, bb)
                if img is None:
                    continue
                small = downscale(img, scale)
                if small.width < 6 or small.height < 10:
                    manifest["warnings"].append(
                        f"{form}/{name}: dropped tiny crop {small.size}")
                    continue
                if imgs and frames_equal(imgs[-1], small):
                    continue
                imgs.append(small)
            adir = os.path.join(form_dir, name)
            os.makedirs(adir, exist_ok=True)
            for old in os.listdir(adir):
                if old.startswith("frame_") and old.endswith(".png"):
                    os.remove(os.path.join(adir, old))
            for i, img in enumerate(imgs, 1):
                img.save(os.path.join(adir, f"frame_{i:03d}.png"))
            if not imgs:
                manifest["warnings"].append(f"{form}/{name}: no usable frames")
            info[name] = {
                "frames": len(imgs),
                "fps": FPS[form][name],
                "loop": name in LOOPS[form],
                "size": list(imgs[0].size) if imgs else None,
            }
        manifest["forms"][form] = info
        print(form, {k: v["frames"] for k, v in info.items()})

    manifest["notes"] = [
        "Frames were split from AI-generated concept atlases: several attack "
        "frames are cropped mid-limb and the punch/kick/bite rows have no "
        "dedicated wind-up frame, so the game holds frame 1 briefly instead.",
        "The kagune atlas has no separate 'idle sway' contact sheet beyond 5 "
        "frames; those 5 loop as the kagune idle.",
        "Normal-form Kagune_Barrage is a 6-frame burst (the last frame is the "
        "tentacle spike impact), so the barrage reuses it and adds its own "
        "extra hit windows.",
    ]
    os.makedirs(DST, exist_ok=True)
    with open(os.path.join(DST, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    for w in manifest["warnings"]:
        print("WARN:", w)
    print("wrote", DST)


if __name__ == "__main__":
    main()
