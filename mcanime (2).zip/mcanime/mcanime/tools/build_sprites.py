"""Build game-ready character sprites from the source art.

Source priority
---------------
1. ``assets/characters/<name>.png`` (one file per character, any background)
2. ``assets/characters/jojo_sheet.png`` (the 4x3 reference sheet)

For every figure this script:
  * removes the background (alpha threshold + edge de-halo, and a flood-fill
    fallback for opaque sources with a flat background),
  * trims to the figure's bounding box,
  * downsamples to the game's fighter height with an area filter,
  * optionally reduces the palette for a crisp retro look,
  * writes ``assets/characters/<name>_<view>.png`` plus a 16x16 head portrait.

Run:  python tools/build_sprites.py
"""
from __future__ import annotations

import argparse
import os
import sys

import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_DIR = os.path.join(ROOT, "assets", "characters")
SHEET = os.path.join(SRC_DIR, "jojo_sheet.png")

# Fighter sprite height in game pixels (GROUND_Y=238, canvas 480x270).
FIGHTER_H = 96
STAND_H = 104
PORTRAIT = 40

# Detected on the reference sheet: 4 rows x 3 views.
ROW_BANDS = [(10, 256), (256, 506), (510, 756), (762, 1016)]
COL_BANDS = [(560, 780), (805, 1030), (1070, 1220)]
ROW_NAMES = ["dio", "the_world", "jotaro", "star_platinum"]
VIEWS = ["front", "back", "side"]

# Which figures are fighters (get the full treatment) vs. Stands.
FIGHTER_NAMES = {"jotaro", "dio"}
STAND_NAMES = {"star_platinum", "the_world"}


# --------------------------------------------------------------------- helpers
def strip_background(img: Image.Image, thresh: int = 96) -> Image.Image:
    """Make the background transparent.

    The reference art already has an alpha channel with a soft AA halo, so the
    main job is to harden the alpha and kill the light fringe. If the image is
    fully opaque we fall back to a corner flood fill.
    """
    arr = np.array(img.convert("RGBA"))
    alpha = arr[:, :, 3]

    if alpha.min() > 250:
        # Opaque source: flood fill from the border with a colour tolerance.
        arr = _flood_key(arr, tolerance=40)

    alpha = arr[:, :, 3]
    hard = np.where(alpha >= thresh, 255, 0).astype(np.uint8)

    # De-halo: pixels that survived but are very light (background bleed on the
    # anti-aliased outline) get pushed toward the local dark outline colour.
    rgb = arr[:, :, :3].astype(np.int16)
    light = (rgb.mean(axis=2) > 205) & (hard > 0)
    if light.any():
        rgb[light] = (rgb[light] * 0.35).astype(np.int16)

    arr[:, :, :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    arr[:, :, 3] = hard
    out = Image.fromarray(arr, "RGBA")
    return out.crop(out.getbbox())


def _flood_key(arr: np.ndarray, tolerance: int = 40) -> np.ndarray:
    """Flood fill the background from the image border and clear its alpha."""
    h, w = arr.shape[:2]
    rgb = arr[:, :, :3].astype(np.int16)
    # Sample the most common border colour.
    border = np.concatenate([rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]])
    key = np.median(border, axis=0)
    similar = np.abs(rgb - key).sum(axis=2) < tolerance

    visited = np.zeros((h, w), dtype=bool)
    stack = []
    for x in range(w):
        stack.append((0, x))
        stack.append((h - 1, x))
    for y in range(h):
        stack.append((y, 0))
        stack.append((y, w - 1))
    while stack:
        y, x = stack.pop()
        if y < 0 or x < 0 or y >= h or x >= w or visited[y, x]:
            continue
        if not similar[y, x]:
            continue
        visited[y, x] = True
        stack.extend(((y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)))

    out = arr.copy()
    out[:, :, 3] = np.where(visited, 0, arr[:, :, 3])
    return out


def resize_to_height(img: Image.Image, height: int) -> Image.Image:
    """Area-downsample, then restore contrast lost in the shrink."""
    w, h = img.size
    scale = height / h
    small = img.resize((max(1, round(w * scale)), height), Image.BOX)

    arr = np.array(small).astype(np.float32)
    if arr.shape[0] < 2:
        return small
    blur = arr.copy()
    blur[:, 1:] = (arr[:, 1:] + arr[:, :-1]) / 2
    sharp = np.clip(arr * 1.45 - blur * 0.45, 0, 255).astype(np.uint8)
    # Keep the silhouette hard-edged so it reads as pixel art.
    sharp[:, :, 3] = np.where(sharp[:, :, 3] > 120, 255, 0)
    return Image.fromarray(sharp, "RGBA")


def reduce_palette(img: Image.Image, colors: int) -> Image.Image:
    """Quantize RGB while preserving the alpha mask."""
    arr = np.array(img)
    rgb = Image.fromarray(arr[:, :, :3]).quantize(colors=colors, method=Image.MEDIANCUT)
    out = np.array(rgb.convert("RGB"))
    res = np.dstack([out, arr[:, :, 3]])
    return Image.fromarray(res, "RGBA")


def head_portrait(img: Image.Image, size: int = PORTRAIT) -> Image.Image:
    """Square head-and-shoulders crop from a front sprite."""
    w, h = img.size
    side = min(w, int(h * 0.42))
    head = img.crop(((w - side) // 2, 0, (w + side) // 2, side))
    return head.resize((size, size), Image.BOX)


# ------------------------------------------------------------------- sheet cut
def find_sheet_boxes(sheet: Image.Image) -> dict[tuple[str, str], tuple[int, int, int, int]]:
    arr = np.array(sheet.convert("RGBA"))
    mask = arr[:, :, 3] > 24
    boxes = {}
    for ri, (ry0, ry1) in enumerate(ROW_BANDS):
        for ci, (cx0, cx1) in enumerate(COL_BANDS):
            sub = mask[ry0:ry1, cx0:cx1]
            ys = np.where(sub.any(axis=1))[0]
            xs = np.where(sub.any(axis=0))[0]
            if len(ys) == 0:
                continue
            boxes[(ROW_NAMES[ri], VIEWS[ci])] = (
                int(cx0 + xs.min()), int(ry0 + ys.min()),
                int(cx0 + xs.max() + 1), int(ry0 + ys.max() + 1),
            )
    return boxes


# ------------------------------------------------------------------------ main
def build(quantize: int | None = 28, verbose: bool = True) -> None:
    os.makedirs(SRC_DIR, exist_ok=True)
    outputs = []

    single = {
        name: os.path.join(SRC_DIR, f"{name}.png")
        for name in ("jotaro", "dio", "star_platinum", "the_world")
    }
    have_singles = {k: v for k, v in single.items() if os.path.exists(v)}
    sheet = Image.open(SHEET).convert("RGBA") if os.path.exists(SHEET) else None

    if not have_singles and sheet is None:
        print("No source art found in", SRC_DIR)
        return

    boxes = find_sheet_boxes(sheet) if sheet is not None else {}

    for name in ROW_NAMES:
        for view in VIEWS:
            if name in have_singles:
                src = Image.open(have_singles[name]).convert("RGBA")
            elif (name, view) in boxes:
                src = sheet.crop(boxes[(name, view)])
            else:
                continue

            img = strip_background(src)
            height = STAND_H if name in STAND_NAMES else FIGHTER_H
            img = resize_to_height(img, height)
            if quantize:
                img = reduce_palette(img, quantize)

            out_name = f"{name}_{view}.png"
            img.save(os.path.join(SRC_DIR, out_name))
            outputs.append((out_name, img.size))

            if view == "front":
                head_portrait(img).save(os.path.join(SRC_DIR, f"{name}_portrait.png"))

    if verbose:
        print(f"built {len(outputs)} sprites -> {SRC_DIR}")
        for name, size in outputs:
            print(f"  {name:28s} {size[0]:3d} x {size[1]:3d}")
        print(f"  {'portraits':28s} {PORTRAIT} x {PORTRAIT} (x{len(ROW_NAMES)})")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--quantize", type=int, default=48,
                    help="palette size per sprite (0 to disable)")
    args = ap.parse_args()
    build(quantize=args.quantize or None)
