"""Extra mechanics checks: blocking, timeout, AI ultimate, heals and cooldowns."""
import os
import sys

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame  # noqa: E402

from game.app import Game  # noqa: E402
from game.screens import FightScreen  # noqa: E402

FAILS = []


def check(cond, msg):
    if not cond:
        FAILS.append(msg)
        print("FAIL:", msg)


g = Game()

# --- blocking reduces damage
class FakeKeys:
    def __init__(self, down):
        self.down = set(down)

    def __getitem__(self, k):
        return k in self.down


fs = FightScreen(g, "jotaro", "dio")
fs.phase, fs.phase_t = "fight", 0
fs.player.x, fs.enemy.x = 220, 252
pygame.key.get_pressed = lambda: FakeKeys({pygame.K_a})  # type: ignore
fs.ai.update = lambda *a, **k: None
fs.enemy.input_x = 0
before = fs.player.hp
fs.enemy.try_attack("z", fs)
for _ in range(20):
    fs.update(1 / 60)
check(0 < before - fs.player.hp < 5, f"block damage wrong: {before - fs.player.hp}")
check(fs.player.state != "hurt", "blocking fighter entered hurt state")
check(fs.player.state == "block", f"player not blocking: {fs.player.state}")

# --- timeout decides by health
fs2 = FightScreen(g, "jotaro", "dio")
fs2.phase, fs2.phase_t = "fight", 0
fs2.player.hp, fs2.enemy.hp = 70, 40
fs2.time_left = 0.001
fs2.update(1 / 60)
check(fs2.phase == "ko" and fs2.winner is fs2.player, "timeout winner wrong")

# --- AI uses its ultimate
fs3 = FightScreen(g, "jotaro", "dio")
fs3.phase, fs3.phase_t = "fight", 0
fs3.player.x, fs3.enemy.x = 220, 300
fs3.enemy.stand_active = True
fs3.enemy.stand_alpha = 1
fs3.enemy.ult = 100
used = False
for _ in range(60 * 8):
    fs3.update(1 / 60)
    if fs3.time_stop_owner is fs3.enemy:
        used = True
        break
check(used, "AI never used time stop with a full meter")

# --- DIO heal is fast and on a long cooldown
fs4 = FightScreen(g, "dio", "jotaro")
fs4.phase, fs4.phase_t = "fight", 0
fs4.player.hp = 40
fs4.ai.update = lambda *a, **k: None
fs4.enemy.input_x = 0
fs4.player.x, fs4.enemy.x = 200, 320
check(fs4.player.try_attack("c", fs4), "DIO heal failed to start")
for _ in range(40):
    fs4.update(1 / 60)
check(fs4.player.hp > 60, f"DIO heal too weak: {fs4.player.hp}")
check(fs4.player.cooldown("blood") > 10, "DIO heal cooldown too short")

# --- Jotaro heal is slow (still healing after ~0.5s)
fs5 = FightScreen(g, "jotaro", "dio")
fs5.phase, fs5.phase_t = "fight", 0
fs5.player.hp = 40
fs5.ai.update = lambda *a, **k: None
fs5.enemy.input_x = 0
fs5.player.x, fs5.enemy.x = 200, 320
fs5.player.try_attack("c", fs5)
for _ in range(30):
    fs5.update(1 / 60)
check(40 < fs5.player.hp < 48, f"Jotaro heal not gradual: {fs5.player.hp}")
check(fs5.player.state == "heal", "Jotaro heal ended too early")

# --- stand toggle actually swaps C from heal to special
fs6 = FightScreen(g, "jotaro", "dio")
fs6.phase, fs6.phase_t = "fight", 0
fs6.player.hp = 50
fs6.player.try_toggle_stand(fs6)
fs6.player.state = "idle"
fs6.player.stand_flash = 0
check(fs6.player.try_attack("c", fs6), "stand C failed")
check(fs6.player.move.key == "star_finger", "stand C is not star finger")

# --- cooldown prevents mashing
fs7 = FightScreen(g, "jotaro", "dio")
fs7.phase, fs7.phase_t = "fight", 0
fs7.player.stand_active = True
fs7.player.stand_alpha = 1
fs7.player.x, fs7.enemy.x = 220, 260
check(fs7.player.try_attack("z", fs7), "first ora failed")
fs7.player.state = "idle"
check(not fs7.player.try_attack("z", fs7), "ora ignored cooldown")

# --- jump and crouch states
fs8 = FightScreen(g, "jotaro", "dio")
fs8.phase, fs8.phase_t = "fight", 0
fs8.player.jump_requested = True
for _ in range(10):
    fs8.update(1 / 60)
check(fs8.player.jump_y > 10, "jump did not lift fighter")
for _ in range(80):
    fs8.update(1 / 60)
check(fs8.player.jump_y == 0, "fighter never landed")

print("\nRESULT:", "ALL CHECKS PASSED" if not FAILS else f"{len(FAILS)} FAILURES")
raise SystemExit(1 if FAILS else 0)
