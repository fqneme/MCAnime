"""Render animation strips so the code-driven motion can be eyeballed."""
from __future__ import annotations

import os

import harness  # noqa: F401  (sets dummy drivers + temp settings)

import pygame

from game.app import Game
from game.art import ART, compute_transform
from game.screens import FightScreen

OUT = os.path.join(harness._ROOT, "shots")
os.makedirs(OUT, exist_ok=True)

g = Game()
fs = FightScreen(g, "jotaro", "dio")
fs.phase, fs.phase_t = "fight", 0
fs.hint_timer = 0
fs.ai.update = lambda *a, **k: None
fs.player.x, fs.enemy.x = 190, 300
fs.enemy.input_x = 0

CELL_W, CELL_H = 70, 110
SCALE = 3


def strip(name, setup, frames=10, step=1 / 30):
    """Render `frames` frames into a horizontal strip."""
    setup()
    images = []
    for _ in range(frames):
        fs.update(step)
        fs.draw(g.canvas)
        images.append((g.canvas.copy(), int(fs.player.x)))
    out = pygame.Surface((CELL_W * frames, CELL_H))
    out.fill((18, 14, 26))
    for i, (img, px) in enumerate(images):
        cx = max(CELL_W // 2, min(480 - CELL_W // 2, px))
        sub = img.subsurface((cx - CELL_W // 2, 130, CELL_W, CELL_H)).copy()
        out.blit(sub, (i * CELL_W, 0))
    pygame.image.save(pygame.transform.scale(out, (out.get_width() * SCALE,
                                                   out.get_height() * SCALE)),
                      os.path.join(OUT, name))


def idle_setup():
    fs.player.state = "idle"
    fs.player.stand_active = False
    fs.player.stand_alpha = 0
    fs.player.anim_t = 0.0


def walk_setup():
    fs.player.state = "walk"
    fs.player.input_x = 1
    fs.player.anim_t = 0.0
    fs.player.stand_active = False
    fs.player.stand_alpha = 0


def punch_setup():
    fs.player.state = "idle"
    fs.player.stand_active = False
    fs.player.stand_alpha = 0
    fs.player.cooldowns.clear()
    fs.player.try_attack("z", fs)


def stand_punch_setup():
    fs.player.stand_active = True
    fs.player.stand_alpha = 1
    fs.player.cooldowns.clear()
    fs.player.state = "idle"
    fs.player.try_attack("z", fs)


def hit_setup():
    from game.moves import JOTARO_BASE
    fs.player.state = "idle"
    fs.player.hp = 90
    fs.player.receive_hit(8, JOTARO_BASE["x"], fs.enemy, False, fs)


def jump_setup():
    fs.player.state = "idle"
    fs.player.on_ground = False
    fs.player.vy = -320
    fs.player.jump_y = 8


strip("_anim_idle.png", idle_setup, frames=8, step=1 / 12)
strip("_anim_walk.png", walk_setup, frames=8, step=1 / 14)
strip("_anim_punch.png", punch_setup, frames=10, step=1 / 40)
strip("_anim_stand_punch.png", stand_punch_setup, frames=10, step=1 / 40)
strip("_anim_hit.png", hit_setup, frames=8, step=1 / 45)
strip("_anim_jump.png", jump_setup, frames=8, step=1 / 30)

# numeric proof that the transforms really animate
from game.fighter import Fighter  # noqa: E402

probe = Fighter("jotaro", 200, 1)

print("\nidle transform samples (sx, sy, dy, angle):")
probe.state = "idle"
for i in range(5):
    tr = compute_transform(probe, i * 0.18)
    print(f"  t={i * 0.18:.2f}  sx={tr['sx']:.3f} sy={tr['sy']:.3f} "
          f"dy={tr['dy']:+.2f} ang={tr['angle']:+.2f}")

print("\npunch transform samples:")
from game.moves import JOTARO_BASE  # noqa: E402
probe.state = "attack"
probe.move = JOTARO_BASE["z"]
for i in range(6):
    probe.move_t = i * 0.03
    tr = compute_transform(probe, 0.0)
    print(f"  move_t={probe.move_t:.2f} sx={tr['sx']:.3f} sy={tr['sy']:.3f} "
          f"dx={tr['dx']:+.2f} ang={tr['angle']:+.2f}")

print("\nhurt transform samples:")
probe.state = "hurt"
for i in range(4):
    probe.hurt_t = 0.22 - i * 0.06
    probe.anim_t = i * 0.03
    tr = compute_transform(probe, 0.0)
    print(f"  hurt_t={probe.hurt_t:.2f} ang={tr['angle']:+.2f} dx={tr['dx']:+.2f} "
          f"sx={tr['sx']:.3f}")

print("\nwalk transform samples:")
probe.state = "walk"
for i in range(5):
    probe.anim_t = i * 0.06
    tr = compute_transform(probe, 0.0)
    print(f"  anim_t={probe.anim_t:.2f} dy={tr['dy']:+.2f} sx={tr['sx']:.3f} "
          f"ang={tr['angle']:+.2f}")

print("\nsprites saved to shots/_anim_*.png")
