"""Pixel HUD, menus, cards and dramatic overlays."""
from __future__ import annotations

import math

import pygame

from . import font
from .config import (
    BLUE, CYAN, GAME_H, GAME_W, GOLD, GOLD_DARK, GREEN, GREEN_DARK,
    GREEN_GHOST, INK, PURPLE, PURPLE_LIGHT, RED, RED_DARK, UI_BG,
    UI_BORDER, UI_DIM, UI_PANEL, UI_TEXT, WHITE, YELLOW,
)
from .sprites import draw_clock, draw_heart_icon, draw_portrait, draw_star_icon


# ------------------------------------------------------------------ basics
def _alpha_rect(surface, color, rect):
    x, y, w, h = rect
    s = pygame.Surface((max(1, w), max(1, h)), pygame.SRCALPHA)
    s.fill(color)
    surface.blit(s, (x, y))


def panel(surface, rect, fill=UI_PANEL, border=UI_BORDER, alpha=225, border_w=1):
    x, y, w, h = rect
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    s.fill((*fill, alpha))
    surface.blit(s, (x, y))
    if border:
        pygame.draw.rect(surface, border, (x, y, w, h), border_w)


def scanlines(surface, alpha=26, step=3):
    line = pygame.Surface((GAME_W, 1), pygame.SRCALPHA)
    line.fill((0, 0, 0, alpha))
    for y in range(0, GAME_H, step):
        surface.blit(line, (0, y))


def draw_health_bar(surface, x, y, w, h, hp, ghost, color, flip=False, accent=(255, 255, 255)):
    # frame
    surface.fill(INK, (x - 2, y - 2, w + 4, h + 4))
    surface.fill((42, 30, 40), (x, y, w, h))
    inner_w = int(w * max(0.0, min(1.0, hp / 100.0)))
    ghost_w = int(w * max(0.0, min(1.0, ghost / 100.0)))
    if flip:
        if ghost_w > inner_w:
            surface.fill(GREEN_GHOST, (x + w - ghost_w, y, ghost_w - inner_w, h))
        if inner_w > 0:
            surface.fill(color, (x + w - inner_w, y, inner_w, h))
            surface.fill(tuple(min(255, c + 45) for c in color),
                         (x + w - inner_w, y, inner_w, max(1, h // 3)))
    else:
        if ghost_w > inner_w:
            surface.fill(GREEN_GHOST, (x + inner_w, y, ghost_w - inner_w, h))
        if inner_w > 0:
            surface.fill(color, (x, y, inner_w, h))
            surface.fill(tuple(min(255, c + 45) for c in color),
                         (x, y, inner_w, max(1, h // 3)))
    # segment ticks
    for i in range(1, 10):
        tx = x + int(w * i / 10)
        pygame.draw.line(surface, (20, 16, 24), (tx, y), (tx, y + h - 1), 1)
    pygame.draw.rect(surface, accent, (x - 2, y - 2, w + 4, h + 4), 1)
    pygame.draw.line(surface, (255, 255, 255), (x, y), (x + w, y), 1)
    if hp < 25:
        pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() * 0.012)
        frame = (int(200 + 55 * pulse), int(50 + 40 * pulse), int(50 + 40 * pulse))
        pygame.draw.rect(surface, frame, (x - 3, y - 3, w + 6, h + 6), 1)


def draw_ult_bar(surface, x, y, w, h, value, color, flip=False, label="ULT"):
    surface.fill(INK, (x - 1, y - 1, w + 2, h + 2))
    surface.fill((30, 26, 40), (x, y, w, h))
    fillw = int(w * max(0.0, min(1.0, value / 100.0)))
    if fillw > 0:
        if flip:
            surface.fill(color, (x + w - fillw, y, fillw, h))
        else:
            surface.fill(color, (x, y, fillw, h))
        hi = tuple(min(255, c + 60) for c in color)
        if flip:
            surface.fill(hi, (x + w - fillw, y, fillw, 1))
        else:
            surface.fill(hi, (x, y, fillw, 1))
    for i in range(1, 10):
        tx = x + int(w * i / 10)
        pygame.draw.line(surface, (22, 18, 30), (tx, y), (tx, y + h), 1)
    font.draw_text(surface, label, x + (w if flip else 0), y - 11, 1,
                   UI_DIM, align="right" if flip else "left")


def draw_hud(surface, player, enemy, time_left, combo, combo_owner, player_ghost,
             enemy_ghost, show_hints=False, hint_alpha=255):
    # dark plates keep the HUD readable over the bright moon
    _alpha_rect(surface, (8, 6, 14, 150), (4, 4, 218, 48))
    _alpha_rect(surface, (8, 6, 14, 150), (258, 4, 218, 48))
    # portraits
    draw_portrait(surface, player.character, 8, 8, 2, border=player.cfg["accent"], bg=(20, 16, 28))
    draw_portrait(surface, enemy.character, 440, 8, 2, border=enemy.cfg["accent"], bg=(20, 16, 28))

    bar_w = 166
    draw_health_bar(surface, 46, 11, bar_w, 14, player.hp, player_ghost, GREEN,
                    accent=player.cfg["accent"])
    draw_health_bar(surface, 268, 11, bar_w, 14, enemy.hp, enemy_ghost, GREEN,
                    flip=True, accent=enemy.cfg["accent"])

    font.draw_text(surface, player.cfg["full"], 46, 29, 1, UI_TEXT)
    font.draw_text(surface, enemy.cfg["full"], 434, 29, 1, UI_TEXT, align="right")

    # stand indicator
    p_col = player.cfg["accent"] if player.stand_active else UI_DIM
    e_col = enemy.cfg["accent"] if enemy.stand_active else UI_DIM
    draw_star_icon(surface, 52, 43, p_col, 2)
    font.draw_text(surface, "STAND OUT" if player.stand_active else "STAND OFF",
                   60, 39, 1, p_col)
    draw_star_icon(surface, 428, 43, e_col, 2)
    font.draw_text(surface, "STAND OUT" if enemy.stand_active else "STAND OFF",
                   420, 39, 1, e_col, align="right")

    # timer
    panel(surface, (216, 6, 48, 30), fill=(14, 12, 20), border=UI_BORDER, alpha=235)
    secs = max(0, int(math.ceil(time_left)))
    col = RED if secs <= 10 else WHITE
    font.draw_text(surface, f"{secs:02d}", 240, 11, 3, col, shadow=(0, 0, 0), align="center")

    # ult meters
    p_ult = PURPLE if player.character == "jotaro" else GOLD
    e_ult = PURPLE if enemy.character == "jotaro" else GOLD
    draw_ult_bar(surface, 14, 252, 148, 7, player.ult, p_ult, label="ULTIMATE")
    draw_ult_bar(surface, 318, 252, 148, 7, enemy.ult, e_ult, flip=True, label="ULTIMATE")

    pct = int(player.ult)
    font.draw_text(surface, f"{pct}%", 14, 261, 1, UI_DIM)
    if player.ult >= 100:
        pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() * 0.008)
        c = (255, int(210 + 40 * pulse), int(90 + 80 * pulse))
        font.draw_text(surface, "R  TIME STOP READY", 148, 261, 1, c, align="right")
    elif player.stand_active:
        font.draw_text(surface, "R  NEEDS FULL METER", 148, 261, 1, UI_DIM, align="right")
    else:
        font.draw_text(surface, "R  SUMMON STAND FIRST", 148, 261, 1, UI_DIM, align="right")

    # utility cooldown (player)
    util = None
    if player.stand_active:
        util_key = "star_finger" if player.character == "jotaro" else "road_roller"
    else:
        util_key = "smoke" if player.character == "jotaro" else "blood"
    cd = player.cooldown(util_key)
    if cd > 0:
        font.draw_text(surface, f"C  {cd:4.1f}S", 240, 252, 1, UI_DIM, align="center")
    else:
        font.draw_text(surface, "C  READY", 240, 252, 1, GREEN, align="center")

    # combo
    if combo >= 2:
        if combo_owner is player:
            x, align = 30, "left"
        else:
            x, align = 450, "right"
        font.draw_text(surface, f"{combo} HITS", x, 62, 2, GOLD,
                       shadow=(60, 30, 0), align=align)
        font.draw_text(surface, "COMBO", x, 78, 1, UI_DIM, align=align)

    if show_hints:
        c = (UI_DIM[0], UI_DIM[1], UI_DIM[2])
        alpha = max(0, min(255, hint_alpha))
        _alpha_rect(surface, (8, 6, 14, int(120 * alpha / 255)), (46, 214, 388, 18))
        hint = pygame.Surface((GAME_W, 16), pygame.SRCALPHA)
        font.draw_text(hint, "WASD MOVE   Z/X ATTACK   C UTILITY   Q STAND   R ULT   HOLD BACK = BLOCK",
                       240, 2, 1, (*c, alpha), align="center")
        surface.blit(hint, (0, 214))


# ------------------------------------------------------------------ overlays
def draw_time_stop(surface, owner, remaining, duration, t):
    overlay = pygame.Surface((GAME_W, GAME_H), pygame.SRCALPHA)
    overlay.fill((28, 18, 74, 104))
    surface.blit(overlay, (0, 0))
    # sparse horizontal "frozen signal" bands
    for i in range(0, GAME_H, 16):
        if i % 32 == 0:
            _alpha_rect(surface, (120, 160, 255, 20), (0, i, GAME_W, 2))
    # vignette
    for i in range(6):
        pygame.draw.rect(surface, (10, 6, 28), (i * 5, i * 4, GAME_W - i * 10, GAME_H - i * 8), 5)
    font.draw_text(surface, "TIME STOPPED", 240, 52, 4,
                   (214, 242, 255), shadow=(30, 20, 80), outline=(20, 12, 50), align="center")
    name = "STAR PLATINUM: THE WORLD" if owner.character == "jotaro" else "THE WORLD"
    font.draw_text(surface, name, 240, 86, 1, owner.cfg["accent"], shadow=(0, 0, 0), align="center")
    # clock in the upper-right so it never sits on the fighters
    ang = -math.pi / 2 + (1 - remaining / max(0.01, duration)) * math.pi * 2
    draw_clock(surface, 414, 132, 26, (200, 235, 255), ang)
    font.draw_text(surface, f"{remaining:3.1f}", 414, 125, 2, WHITE, shadow=(0, 0, 0), align="center")
    font.draw_text(surface, "FREE COMBO", 240, 100, 1, GOLD, shadow=(0, 0, 0), align="center")


def draw_frozen_aura(surface, f, t):
    x, y = int(f.x), int(f.feet_y - 42)
    for i in range(3):
        r = 30 + i * 8 + math.sin(t * 3 + i) * 3
        a = 22 - i * 5
        s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        pygame.draw.circle(s, (110, 180, 255, a), (r, r), int(r), 2)
        surface.blit(s, (x - r, y - r))
    for i in range(4):
        px = f.x + math.sin(t * 2 + i * 1.7) * 20
        py = f.feet_y - 80 + ((t * 18 + i * 17) % 70)
        surface.fill((180, 230, 255), (int(px), int(py), 1, 3))
    font.draw_text(surface, "FROZEN", x, y - 54, 1, (170, 225, 255), shadow=(0, 0, 0), align="center")


def draw_banner(surface, title, subtitle="", color=GOLD, scale=4, y=104, t=0.0,
                sub_color=UI_TEXT, outline=(20, 10, 30)):
    font.draw_text(surface, title, 240, y, scale, color, shadow=(0, 0, 0),
                   outline=outline, align="center")
    if subtitle:
        font.draw_text(surface, subtitle, 240, y + 7 * scale + 10, 1, sub_color,
                       shadow=(0, 0, 0), align="center")


def draw_menu_list(surface, items, selected, cx, y, spacing=24, t=0.0,
                   width=210, accent=GOLD):
    h = len(items) * spacing + 14
    panel(surface, (cx - width // 2, y - 9, width, h), fill=(16, 12, 24), border=UI_BORDER, alpha=215)
    for i, item in enumerate(items):
        iy = y + i * spacing
        sel = i == selected
        if sel:
            pulse = 0.6 + 0.4 * math.sin(t * 6)
            c = (int(accent[0]), int(accent[1] * (0.8 + 0.2 * pulse)), int(accent[2] * 0.7))
            _alpha_rect(surface, (*accent, 255), (cx - width // 2 + 4, iy - 5, width - 8, 22))
            _alpha_rect(surface, (10, 8, 16, 190), (cx - width // 2 + 6, iy - 3, width - 12, 18))
            font.draw_text(surface, ">", cx - width // 2 + 14, iy, 2, c)
            font.draw_text(surface, item, cx + 4, iy, 2, c, shadow=(0, 0, 0), align="center")
        else:
            font.draw_text(surface, item, cx + 4, iy, 2, UI_DIM, align="center")


def draw_logo(surface, cx, y, t):
    # glow behind the logo
    glow = pygame.Surface((360, 96), pygame.SRCALPHA)
    for r, a in ((90, 22), (64, 26), (42, 30)):
        pygame.draw.ellipse(glow, (180, 120, 255, a), (180 - r * 1.7, 46 - r * 0.42, r * 3.4, r * 0.84))
    surface.blit(glow, (cx - 180, y - 18))
    font.draw_text(surface, "STAND BATTLE", cx, y, 4, (255, 236, 170),
                   shadow=(20, 8, 30), outline=(20, 10, 30),
                   gradient=((255, 240, 180), (226, 160, 72)), align="center")
    font.draw_text(surface, "S T A R D U S T   S H O W D O W N", cx, y + 36, 1,
                   (198, 168, 255), shadow=(0, 0, 0), align="center")
    # little stand arrows
    draw_star_icon(surface, cx - 176, y + 14, GOLD, 3)
    draw_star_icon(surface, cx + 176, y + 14, PURPLE_LIGHT, 3)


def draw_character_card(surface, x, y, w, h, character, cfg, selected, t):
    accent = cfg["accent"]
    panel(surface, (x, y, w, h), fill=(18, 14, 28), border=accent if selected else UI_BORDER, alpha=232)
    if selected:
        pulse = 0.5 + 0.5 * math.sin(t * 5)
        pygame.draw.rect(surface, tuple(min(255, int(c * (0.7 + 0.3 * pulse))) for c in accent),
                         (x - 2, y - 2, w + 4, h + 4), 2)
    draw_portrait(surface, character, x + w // 2 - 40, y + 10, 5,
                  border=accent, bg=(12, 10, 20))
    font.draw_text(surface, cfg["full"], x + w // 2, y + 96, 2, accent, shadow=(0, 0, 0), align="center")
    font.draw_text(surface, f"STAND: {cfg['stand']}", x + w // 2, y + 113, 1,
                   UI_DIM, align="center")
    # stat bars
    for i, (label, key) in enumerate((("POWER", "power"), ("SPEED", "speed"), ("UTILITY", "utility"))):
        yy = y + 128 + i * 9
        font.draw_text(surface, label, x + 12, yy, 1, UI_DIM)
        val = cfg[key]
        bw = 86
        bx = x + w - bw - 12
        surface.fill((40, 34, 48), (bx, yy + 1, bw, 4))
        surface.fill(accent, (bx, yy + 1, int(bw * val / 10), 4))
    if selected:
        font.draw_text(surface, "SELECTED", x + w // 2, y + h - 13, 1,
                       (255, 230, 150), align="center")


def draw_results(surface, player, enemy, winner, selected, t):
    overlay = pygame.Surface((GAME_W, GAME_H), pygame.SRCALPHA)
    overlay.fill((8, 6, 14, 190))
    surface.blit(overlay, (0, 0))
    w, h = 300, 194
    x, y = (GAME_W - w) // 2, 38
    panel(surface, (x, y, w, h), fill=(22, 16, 34), border=GOLD if winner is player else RED, alpha=242)
    if winner is player:
        title, sub, col = "YOU WIN", "YARE YARE DAZE" if player.character == "jotaro" else "WRYYYY!", GOLD
        char = player.character
    else:
        title, sub, col = "YOU LOSE", "USELESS, USELESS, USELESS!" if enemy.character == "dio" else "YARE YARE...", RED
        char = enemy.character
    draw_portrait(surface, char, x + 18, y + 18, 3, border=col, bg=(12, 10, 20))
    font.draw_text(surface, title, x + 184, y + 24, 4, col, shadow=(0, 0, 0), align="center")
    font.draw_text(surface, sub, x + 184, y + 58, 1, UI_TEXT, align="center")
    font.draw_text(surface, f"WINNER: {winner.cfg['full']}", x + 184, y + 74, 1,
                   winner.cfg["accent"], align="center")
    items = ["REMATCH", "CHARACTER SELECT", "MAIN MENU"]
    draw_menu_list(surface, items, selected, GAME_W // 2, y + 104, spacing=22, t=t,
                   width=250, accent=GOLD)


def draw_pause(surface, selected, t):
    overlay = pygame.Surface((GAME_W, GAME_H), pygame.SRCALPHA)
    overlay.fill((6, 4, 12, 200))
    surface.blit(overlay, (0, 0))
    font.draw_text(surface, "PAUSED", 240, 34, 4, GOLD, shadow=(0, 0, 0),
                   outline=(20, 10, 30), align="center")
    draw_menu_list(surface, ["RESUME", "RESTART", "MAIN MENU"], selected, 240, 98,
                   spacing=24, t=t, width=200, accent=GOLD)
    font.draw_text(surface, "WASD MOVE   Z PUNCH   X KICK   C UTILITY", 240, 202, 1,
                   UI_DIM, align="center")
    font.draw_text(surface, "Q STAND   R TIME STOP   HOLD BACK = BLOCK", 240, 214, 1,
                   UI_DIM, align="center")
    font.draw_text(surface, "ESC  RESUME", 240, 240, 1, UI_TEXT, align="center")


def draw_info(surface, t):
    overlay = pygame.Surface((GAME_W, GAME_H), pygame.SRCALPHA)
    overlay.fill((6, 4, 12, 210))
    surface.blit(overlay, (0, 0))
    font.draw_text(surface, "INFO", 240, 14, 3, GOLD, shadow=(0, 0, 0), align="center")
    lines = [
        ("STORY", GOLD),
        ("DIO HAS STOPPED TIME IN CAIRO. JOTARO AND STAR PLATINUM", UI_TEXT),
        ("MUST BREAK THROUGH THE WORLD BEFORE THE CLOCK MOVES AGAIN.", UI_TEXT),
        ("", UI_TEXT),
        ("CONTROLS", GOLD),
        ("WASD  MOVE / JUMP / CROUCH      Z  LIGHT PUNCH      X  KICK", UI_TEXT),
        ("C  HEAL / UTILITY      Q  SUMMON OR DISMISS STAND      R  TIME STOP", UI_TEXT),
        ("HOLD BACK (AWAY FROM YOUR OPPONENT) TO BLOCK.", UI_TEXT),
        ("", UI_TEXT),
        ("MECHANICS", GOLD),
        ("TIME STOP NEEDS A FULL ULTIMATE METER AND YOUR STAND OUT.", UI_TEXT),
        ("DURING TIME STOP THE OPPONENT IS FROZEN FOR 3 SECONDS.", UI_TEXT),
        ("JOTARO'S CIGARETTE HEALS SLOWLY BUT LEAVES HIM OPEN.", UI_TEXT),
        ("DIO'S BOTTLE HEALS FAST BUT HAS A LONG COOLDOWN.", UI_TEXT),
        ("", UI_TEXT),
        ("CREDITS", GOLD),
        ("FAN PROJECT. JOJO'S BIZARRE ADVENTURE (C) HIROHIKO ARAKI.", UI_DIM),
        ("SFX + MUSIC: KENNEY.NL (CC0). VOICE CUES: EDGE-TTS, PROCESSED.", UI_DIM),
        ("MADE WITH PYGAME. NOT AFFILIATED WITH THE RIGHTS HOLDERS.", UI_DIM),
    ]
    y = 44
    for text, col in lines:
        font.draw_text(surface, text, 28, y, 1, col)
        y += 10
    font.draw_text(surface, "ESC  BACK", 240, 252, 1, UI_DIM, align="center")


def draw_settings(surface, settings, selected, values, t):
    overlay = pygame.Surface((GAME_W, GAME_H), pygame.SRCALPHA)
    overlay.fill((6, 4, 12, 210))
    surface.blit(overlay, (0, 0))
    font.draw_text(surface, "SETTINGS", 240, 18, 3, GOLD, shadow=(0, 0, 0), align="center")
    rows = [
        ("MUSIC VOLUME", f"{int(settings['music'] * 100)}%"),
        ("SFX VOLUME", f"{int(settings['sfx'] * 100)}%"),
        ("DIFFICULTY", settings["difficulty"]),
        ("FULLSCREEN", "ON" if settings["fullscreen"] else "OFF"),
        ("SCREEN SHAKE", "ON" if settings["screen_shake"] else "OFF"),
        ("CONTROL HINTS", "ON" if settings["show_hints"] else "OFF"),
    ]
    w, h = 340, 156
    x, y = (GAME_W - w) // 2, 50
    panel(surface, (x, y, w, h), fill=(20, 16, 30), border=UI_BORDER, alpha=235)
    for i, (label, value) in enumerate(rows):
        yy = y + 12 + i * 24
        sel = i == selected
        if sel:
            _alpha_rect(surface, (*GOLD, 22), (x + 6, yy - 4, w - 12, 20))
            font.draw_text(surface, ">", x + 12, yy, 1, GOLD)
        font.draw_text(surface, label, x + 24, yy, 1, UI_TEXT if sel else UI_DIM)
        font.draw_text(surface, f"< {value} >" if sel else value, x + w - 16, yy, 1,
                       GOLD if sel else UI_TEXT, align="right")
    font.draw_text(surface, "UP/DOWN SELECT   LEFT/RIGHT CHANGE   ESC BACK", 240, 220, 1,
                   UI_DIM, align="center")
