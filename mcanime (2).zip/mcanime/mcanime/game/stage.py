"""Pixel-art Cairo rooftop stage, drawn once and animated with tiny details."""
from __future__ import annotations

import math
import random

import pygame

from .config import GAME_H, GAME_W, GROUND_Y


def _lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


class Stage:
    def __init__(self, seed: int = 7):
        self.base = pygame.Surface((GAME_W, GAME_H)).convert()
        self.rng = random.Random(seed)
        self.stars = []
        self.dust = []
        self._build()
        for _ in range(70):
            self.stars.append((
                self.rng.randrange(0, GAME_W),
                self.rng.randrange(0, 150),
                self.rng.choice((0.6, 1.0, 1.6)),
                self.rng.randrange(0, 60) / 10,
            ))
        for _ in range(26):
            self.dust.append([
                self.rng.uniform(0, GAME_W),
                self.rng.uniform(120, GROUND_Y),
                self.rng.uniform(2, 9),
                self.rng.uniform(0, 6.28),
            ])

    # ------------------------------------------------------------------ build
    def _build(self) -> None:
        s = self.base
        rng = self.rng
        # sky gradient
        top, mid, bot = (9, 8, 26), (40, 18, 54), (110, 46, 66)
        for y in range(0, 190):
            t = y / 190
            if t < 0.55:
                c = _lerp(top, mid, t / 0.55)
            else:
                c = _lerp(mid, bot, (t - 0.55) / 0.45)
            pygame.draw.line(s, c, (0, y), (GAME_W, y))
        # stars
        for _ in range(130):
            x, y = rng.randrange(0, GAME_W), rng.randrange(0, 165)
            c = rng.choice(((210, 210, 230), (160, 160, 200), (240, 230, 190)))
            s.set_at((x, y), c)
        # moon
        mx, my, mr = 368, 58, 28
        glow = pygame.Surface((mr * 6, mr * 6), pygame.SRCALPHA)
        for r, a in ((mr * 2.8, 18), (mr * 2.0, 24), (mr * 1.4, 30)):
            pygame.draw.circle(glow, (250, 236, 200, a), (mr * 3, mr * 3), int(r))
        s.blit(glow, (mx - mr * 3, my - mr * 3))
        pygame.draw.circle(s, (238, 228, 198), (mx, my), mr)
        pygame.draw.circle(s, (250, 242, 218), (mx - 3, my - 4), mr - 3)
        for cx, cy, cr in ((-9, -6, 4), (7, 3, 6), (-3, 11, 3), (12, -10, 2)):
            pygame.draw.circle(s, (218, 206, 178), (mx + cx, my + cy), cr)
        # thin clouds across the moon
        cloud = pygame.Surface((GAME_W, 40), pygame.SRCALPHA)
        for i in range(5):
            pygame.draw.ellipse(cloud, (180, 130, 160, 34),
                                (40 + i * 86, 10 + (i % 2) * 8, 110, 12))
        s.blit(cloud, (0, 36))

        # far skyline
        x = -10
        while x < GAME_W + 20:
            w = rng.randrange(14, 34)
            h = rng.randrange(20, 54)
            y = 186 - h
            pygame.draw.rect(s, (28, 22, 46), (x, y, w, h + 60))
            if rng.random() < 0.5:
                pygame.draw.rect(s, (36, 28, 56), (x + 2, y - 5, w - 4, 5))
            x += w + rng.randrange(2, 9)
        # minarets
        for mx0, hh in ((48, 74), (196, 58), (318, 66), (438, 80)):
            pygame.draw.rect(s, (26, 20, 42), (mx0, 186 - hh, 7, hh))
            pygame.draw.rect(s, (26, 20, 42), (mx0 - 3, 186 - hh + 16, 13, 4))
            pygame.draw.rect(s, (26, 20, 42), (mx0 - 2, 186 - hh + 30, 11, 3))
            pygame.draw.polygon(s, (26, 20, 42), [
                (mx0 - 2, 186 - hh), (mx0 + 3, 186 - hh - 9), (mx0 + 8, 186 - hh),
            ])
        # dome
        pygame.draw.rect(s, (30, 24, 46), (96, 148, 60, 42))
        pygame.draw.ellipse(s, (34, 27, 52), (94, 124, 64, 52))
        pygame.draw.ellipse(s, (42, 33, 60), (100, 128, 52, 42))
        pygame.draw.rect(s, (30, 24, 46), (122, 112, 8, 22))
        pygame.draw.polygon(s, (34, 27, 52), [(122, 112), (126, 103), (130, 112)])

        # mid buildings with lit windows
        buildings = [
            (0, 176, 52, 66), (56, 166, 40, 76), (150, 158, 46, 84),
            (222, 172, 36, 70), (260, 154, 52, 88), (344, 170, 38, 72),
            (390, 162, 54, 80), (448, 178, 40, 64),
        ]
        for bx, by, bw, bh in buildings:
            pygame.draw.rect(s, (20, 16, 34), (bx, by, bw, bh))
            pygame.draw.rect(s, (28, 22, 44), (bx + 2, by + 2, bw - 4, bh - 2))
            # roof details
            pygame.draw.rect(s, (14, 12, 26), (bx - 2, by, bw + 4, 4))
            for wy in range(by + 8, by + bh - 6, 9):
                for wx in range(bx + 5, bx + bw - 4, 9):
                    if rng.random() < 0.45:
                        col = rng.choice(((232, 196, 108), (212, 160, 82), (120, 150, 190)))
                        s.fill(col, (wx, wy, 3, 4))
        # balcony rails on nearest roof
        pygame.draw.rect(s, (58, 42, 52), (0, 190, GAME_W, 3))
        for rx in range(0, GAME_W, 12):
            pygame.draw.rect(s, (44, 32, 42), (rx, 184, 2, 10))
        pygame.draw.rect(s, (66, 48, 58), (0, 182, GAME_W, 2))

        # ground / rooftop
        for y in range(int(GROUND_Y), GAME_H):
            t = (y - GROUND_Y) / (GAME_H - GROUND_Y)
            c = _lerp((108, 84, 64), (62, 48, 42), t)
            pygame.draw.line(s, c, (0, y), (GAME_W, y))
        pygame.draw.line(s, (156, 122, 86), (0, int(GROUND_Y)), (GAME_W, int(GROUND_Y)), 2)
        # tiles / cracks
        for _ in range(90):
            px = rng.randrange(0, GAME_W)
            py = rng.randrange(int(GROUND_Y) + 4, GAME_H)
            c = rng.choice(((88, 66, 52), (128, 98, 70), (70, 54, 44)))
            s.fill(c, (px, py, rng.randrange(1, 5), 1))
        for _ in range(16):
            px = rng.randrange(10, GAME_W - 10)
            py = rng.randrange(int(GROUND_Y) + 6, GAME_H - 2)
            pygame.draw.line(s, (76, 58, 48), (px, py), (px + rng.randrange(-9, 10), py + rng.randrange(2, 6)), 1)
        # foreground pavement edge
        pygame.draw.rect(s, (48, 38, 38), (0, GAME_H - 8, GAME_W, 8))
        pygame.draw.line(s, (90, 70, 60), (0, GAME_H - 8), (GAME_W, GAME_H - 8), 1)

        # rooftop props: AC unit, crates, sandbags
        pygame.draw.rect(s, (34, 30, 40), (8, 212, 44, 26))
        pygame.draw.rect(s, (56, 52, 64), (10, 214, 40, 18))
        for i in range(4):
            pygame.draw.line(s, (36, 34, 44), (14 + i * 9, 216), (14 + i * 9, 230), 1)
        pygame.draw.rect(s, (72, 68, 82), (10, 232, 40, 3))
        pygame.draw.rect(s, (34, 30, 40), (438, 216, 34, 22))
        pygame.draw.rect(s, (70, 54, 40), (440, 218, 30, 16))
        pygame.draw.line(s, (96, 74, 54), (440, 226), (470, 226), 1)
        pygame.draw.line(s, (96, 74, 54), (455, 218), (455, 234), 1)
        for bx, by in ((28, 238), (30, 241), (26, 240), (44, 239), (452, 238)):
            pygame.draw.ellipse(s, (120, 102, 78), (bx, by, 7, 3))
        # a puddle catching the moon
        pygame.draw.ellipse(s, (58, 62, 82), (250, 250, 46, 7))
        pygame.draw.ellipse(s, (90, 96, 120), (256, 251, 22, 3))

        # street lamps
        for lx, flip in ((30, 1), (450, -1)):
            pygame.draw.rect(s, (30, 26, 36), (lx - 2, 172, 4, int(GROUND_Y) - 172))
            pygame.draw.rect(s, (30, 26, 36), (lx - 2, 172, 14 * flip, 3))
            lx2 = lx + 12 * flip
            pygame.draw.rect(s, (42, 36, 48), (lx2 - 3, 168, 7, 6))
            pygame.draw.rect(s, (250, 208, 120), (lx2 - 2, 169, 5, 4))
            lamp_glow = pygame.Surface((54, 54), pygame.SRCALPHA)
            for r, a in ((26, 22), (16, 30), (8, 40)):
                pygame.draw.circle(lamp_glow, (255, 200, 110, a), (27, 27), r)
            s.blit(lamp_glow, (lx2 - 27, 150))
        # distant crowd / market awnings
        for ax in range(0, GAME_W, 46):
            pygame.draw.polygon(s, (58, 34, 44), [
                (ax, 198), (ax + 22, 198), (ax + 18, 205), (ax + 4, 205),
            ])
            pygame.draw.line(s, (82, 52, 56), (ax, 198), (ax + 22, 198), 1)

    # ------------------------------------------------------------------ draw
    def draw(self, surface, t: float, frozen: bool = False):
        surface.blit(self.base, (0, 0))
        if frozen:
            return
        # twinkling stars
        for i, (x, y, size, phase) in enumerate(self.stars):
            a = 0.55 + 0.45 * math.sin(t * 2.2 + phase)
            if a > 0.7:
                c = (int(220 * a), int(220 * a), int(235 * a))
                surface.fill(c, (x, y, 1, 1))
                if size > 1.2 and int(t * 3 + phase) % 4 == 0:
                    surface.fill(c, (x - 1, y, 3, 1))
                    surface.fill(c, (x, y - 1, 1, 3))
        # drifting dust motes
        for d in self.dust:
            d[0] += d[2] * 0.06
            d[1] += math.sin(t * 0.7 + d[3]) * 0.08
            if d[0] > GAME_W + 4:
                d[0] = -4
            px, py = int(d[0]), int(d[1])
            surface.fill((190, 160, 120), (px, py, 1, 1))
