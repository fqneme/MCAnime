"""A readable Walk -> Attack -> Block state machine for the CPU opponent."""
from __future__ import annotations

import random

from .config import DIFFICULTIES


class AI:
    def __init__(self, fighter, difficulty: str = "NORMAL"):
        self.f = fighter
        self.difficulty = difficulty if difficulty in DIFFICULTIES else "NORMAL"
        self.d = DIFFICULTIES[self.difficulty]
        self.think = 0.3
        self.block_t = 0.0
        self.mode = "approach"
        self.mode_t = 0.0
        self.prev_opp_state = "idle"
        self.summon_wait = 0.0
        self.wants_ult = False
        self.wants_heal = False
        self.action_cd = 0.0

    def _rng_reaction(self):
        lo, hi = self.d["reaction"]
        return random.uniform(lo, hi)

    def update(self, dt: float, opponent, game):
        f = self.f
        if f.state == "ko" or game.time_stop_owner is opponent:
            f.input_x = 0
            f.input_block = False
            f.jump_requested = False
            return
        self.block_t = max(0.0, self.block_t - dt)
        self.mode_t = max(0.0, self.mode_t - dt)
        self.action_cd = max(0.0, self.action_cd - dt)
        self.summon_wait = max(0.0, self.summon_wait - dt)

        # React to the start of a player attack.
        if opponent.state == "attack" and self.prev_opp_state != "attack":
            dist = abs(opponent.x - f.x)
            if dist < 96 and random.random() < self.d["block"]:
                # Guarding is a reflex, so it is much faster than a normal decision.
                self.block_t = random.uniform(0.28, 0.5)
        self.prev_opp_state = opponent.state

        # A guarding CPU can cancel its own recovery into a block.
        if self.block_t > 0 and f.state == "attack" and f.move is not None:
            if f.move_t < f.move.startup * 0.6:
                f.state = "block"
                f.move = None
                f.move_t = 0.0

        if f.is_busy():
            f.input_x = 0
            f.input_block = False
            f.jump_requested = False
            return

        if self.block_t > 0 and f.can_act():
            f.input_x = 0
            f.input_crouch = False
            f.input_block = True
            f.jump_requested = False
            return

        f.input_block = False
        f.input_crouch = False
        dist = abs(opponent.x - f.x)
        direction = 1 if opponent.x > f.x else -1

        # Heal when hurt. Base form only, so dismiss the Stand first.
        if f.hp < 48 and self.action_cd <= 0:
            base_c = f.cooldowns.get("smoke" if f.character == "jotaro" else "blood", 0)
            if base_c <= 0 and dist > 55:
                if f.stand_active:
                    f.try_toggle_stand(game)
                    self.action_cd = 0.35
                    return
                if f.try_attack("c", game):
                    self.action_cd = 0.7
                    return

        # Ultimate logic.
        if f.ult >= f.max_ult - 0.5 and self.action_cd <= 0:
            if not f.stand_active:
                if f.try_toggle_stand(game):
                    self.action_cd = 0.35
                    return
            elif dist < 150:
                if f.try_ult(game):
                    self.action_cd = 1.2
                    return
                self.action_cd = 0.3

        self.think -= dt
        if self.think > 0:
            # Continue current movement intent between decisions.
            if self.mode == "approach" and dist > 52:
                f.input_x = direction
            elif self.mode == "retreat" and dist < 120:
                f.input_x = -direction
            else:
                f.input_x = 0
            return

        self.think = self._rng_reaction()
        r = random.random()

        # Summon the Stand fairly early, but not while being pressured.
        if not f.stand_active and r < 0.5 and dist > 50 and self.summon_wait <= 0:
            if f.try_toggle_stand(game):
                self.summon_wait = 1.4
                self.action_cd = 0.3
                return

        # Use the Stand special at the right spacing.
        if f.stand_active and f.action_ready_special() and self.action_cd <= 0:
            if f.character == "dio":
                if 50 < dist < 105 and random.random() < 0.55:
                    if f.try_attack("c", game):
                        self.action_cd = 0.9
                        return
            else:
                if 55 < dist < 180 and random.random() < 0.5:
                    if f.try_attack("c", game):
                        self.action_cd = 0.9
                        return

        if dist > 62:
            if r < self.d["aggression"]:
                self.mode = "approach"
                f.input_x = direction
            elif r < self.d["aggression"] + 0.14:
                self.mode = "approach"
                f.input_x = direction
                if random.random() < 0.25:
                    f.jump_requested = True
            else:
                self.mode = "retreat"
                f.input_x = -direction
        elif dist < 34:
            if r < 0.55:
                f.input_x = -direction
                self.mode = "retreat"
            else:
                self.mode = "attack"
        else:
            # In range: attack, block, or reposition.
            if r < self.d["aggression"] and self.action_cd <= 0:
                slot = "z" if random.random() < 0.55 else "x"
                if f.try_attack(slot, game):
                    self.action_cd = 0.18
                    self.mode = "attack"
                    return
            elif r < self.d["aggression"] + 0.2:
                self.block_t = random.uniform(0.2, 0.4)
                f.input_block = True
            else:
                self.mode = "retreat"
                f.input_x = -direction
