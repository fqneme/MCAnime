"""Move definitions for both fighters, with and without their Stand."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Move:
    key: str
    name: str
    startup: float
    active: float
    recovery: float
    damage: float = 0.0
    hit_times: tuple[float, ...] = ()
    hitstun: float = 0.25
    knockback: float = 90.0
    reach: float = 44.0
    hit_low: float = 24.0
    hit_high: float = 78.0
    cooldown: float = 0.3
    block_ratio: float = 0.18
    meter_gain: float = 3.0
    lunge: float = 0.0
    sound: str = "punch_light"
    voice: str | None = None
    special: str | None = None
    heal_total: float = 0.0
    heal_duration: float = 0.0
    high: bool = True
    unblockable: bool = False
    shake: float = 1.0
    hitstop: float = 0.05
    push_self: float = 0.0

    @property
    def duration(self) -> float:
        return self.startup + self.active + self.recovery

    @property
    def hit_frame(self) -> float:
        if self.hit_times:
            return self.hit_times[0]
        return self.startup + self.active * 0.5


# ------------------------------------------------------------------ Jotaro
JOTARO_BASE = {
    "z": Move(
        key="jab", name="", startup=0.07, active=0.06, recovery=0.14,
        damage=5, hit_times=(0.09,), hitstun=0.20, knockback=80,
        reach=41, hit_low=34, hit_high=78, cooldown=0.20,
        sound="punch_light", shake=0.8,
    ),
    "x": Move(
        key="kick", name="", startup=0.11, active=0.08, recovery=0.20,
        damage=8, hit_times=(0.14,), hitstun=0.28, knockback=150,
        reach=49, hit_low=12, hit_high=58, cooldown=0.32,
        sound="kick_medium", shake=1.3,
    ),
    "c": Move(
        key="smoke", name="CIGARETTE", startup=0.0, active=0.0, recovery=3.0,
        cooldown=9.0, special="heal", heal_total=18.0, heal_duration=3.0,
        voice="heal_jotaro", sound="whoosh", shake=0.0,
    ),
}

JOTARO_STAND = {
    "z": Move(
        key="ora", name="ORA ORA!", startup=0.12, active=0.50, recovery=0.26,
        damage=4, hit_times=(0.16, 0.25, 0.34, 0.43, 0.52),
        hitstun=0.14, knockback=26, reach=52, hit_low=30, hit_high=84,
        cooldown=2.6, sound="punch_light", voice="ora_ora",
        shake=1.0, hitstop=0.03, meter_gain=1.6,
    ),
    "x": Move(
        key="ora_kick", name="ORA!", startup=0.13, active=0.09, recovery=0.28,
        damage=13, hit_times=(0.16,), hitstun=0.40, knockback=310,
        reach=57, hit_low=10, hit_high=64, cooldown=1.4,
        sound="kick_heavy", voice="ora_ora_2", shake=2.2, hitstop=0.07,
    ),
    "c": Move(
        key="star_finger", name="STAR FINGER", startup=0.20, active=0.12, recovery=0.34,
        damage=15, hit_times=(0.25,), hitstun=0.45, knockback=170,
        reach=178, hit_low=34, hit_high=74, cooldown=4.0,
        sound="punch_heavy", voice="star_finger", special="finger",
        shake=1.6, hitstop=0.06, meter_gain=5.0,
    ),
}

# --------------------------------------------------------------------- DIO
DIO_BASE = {
    "z": Move(
        key="jab", name="", startup=0.07, active=0.06, recovery=0.14,
        damage=5, hit_times=(0.09,), hitstun=0.20, knockback=80,
        reach=41, hit_low=34, hit_high=78, cooldown=0.20,
        sound="punch_light", shake=0.8,
    ),
    "x": Move(
        key="kick", name="", startup=0.11, active=0.08, recovery=0.20,
        damage=8, hit_times=(0.14,), hitstun=0.28, knockback=150,
        reach=49, hit_low=12, hit_high=58, cooldown=0.32,
        sound="kick_medium", shake=1.3,
    ),
    "c": Move(
        key="blood", name="BLOOD BOTTLE", startup=0.0, active=0.0, recovery=0.9,
        cooldown=13.0, special="heal_instant", heal_total=26.0,
        heal_duration=0.9, voice="heal_dio", sound="whoosh", shake=0.0,
    ),
}

DIO_STAND = {
    "z": Move(
        key="muda", name="MUDA MUDA!", startup=0.12, active=0.55, recovery=0.30,
        damage=5, hit_times=(0.16, 0.25, 0.34, 0.43, 0.52, 0.61),
        hitstun=0.14, knockback=28, reach=53, hit_low=30, hit_high=84,
        cooldown=3.0, sound="punch_heavy", voice="muda_muda",
        shake=1.3, hitstop=0.035, meter_gain=1.4,
    ),
    "x": Move(
        key="muda_kick", name="MUDA!", startup=0.13, active=0.09, recovery=0.28,
        damage=14, hit_times=(0.16,), hitstun=0.42, knockback=330,
        reach=58, hit_low=10, hit_high=64, cooldown=1.4,
        sound="kick_heavy", voice="muda_muda_2", shake=2.4, hitstop=0.07,
    ),
    "c": Move(
        key="road_roller", name="ROAD ROLLER DA!", startup=0.95, active=0.30, recovery=0.75,
        damage=34, hitstun=0.8, knockback=240, reach=90, hit_low=0, hit_high=110,
        cooldown=14.0, sound="whoosh", voice="road_roller", special="roller",
        shake=4.0, hitstop=0.10, block_ratio=0.4, meter_gain=8.0,
    ),
}

MOVE_SETS = {
    ("jotaro", False): JOTARO_BASE,
    ("jotaro", True): JOTARO_STAND,
    ("dio", False): DIO_BASE,
    ("dio", True): DIO_STAND,
}


def get_move(character: str, stand: bool, slot: str) -> Move | None:
    return MOVE_SETS[(character, stand)].get(slot)
