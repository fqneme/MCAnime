"""Particles, hit sparks, floating text, speed lines and screen shake."""
from __future__ import annotations

import math
import random

import pygame

from . import font


class Effects:
    def __init__(self):
        self.particles: list[dict] = []
        self.texts: list[dict] = []
        self.rings: list[dict] = []
        self.trauma = 0.0
        self.flash = 0.0

    # ------------------------------------------------------------------ spawn
    def add_shake(self, amount: float):
        self.trauma = min(1.0, self.trauma + amount * 0.18)

    def add_flash(self, amount: float = 0.5):
        self.flash = max(self.flash, amount)

    def add_hit(self, x, y, color, power=1.0, blocked=False):
        n = int(8 + 12 * power)
        for _ in range(n):
            ang = random.uniform(-math.pi, math.pi)
            spd = random.uniform(40, 190) * (0.6 + power * 0.5)
            self.particles.append({
                "x": x, "y": y,
                "vx": math.cos(ang) * spd,
                "vy": math.sin(ang) * spd - 30,
                "life": random.uniform(0.15, 0.4),
                "max": 0.4, "color": color,
                "size": random.choice((1, 1, 2, 2, 3)),
                "grav": 260, "kind": "spark",
            })
        if blocked:
            color = (120, 180, 255)
        self.rings.append({"x": x, "y": y, "r": 2, "vr": 85 * power,
                           "life": 0.20, "max": 0.20, "color": color, "w": 2})
        self.add_shake(power)

    def add_dust(self, x, y, count=10, color=(190, 156, 112), spread=1.0):
        for _ in range(count):
            self.particles.append({
                "x": x + random.uniform(-12, 12) * spread,
                "y": y + random.uniform(-3, 2),
                "vx": random.uniform(-55, 55) * spread,
                "vy": random.uniform(-75, -15),
                "life": random.uniform(0.3, 0.8),
                "max": 0.8, "color": color,
                "size": random.choice((1, 2, 2, 3)),
                "grav": 140, "kind": "dust",
            })

    def add_smoke(self, x, y, color=(200, 200, 210), count=1):
        for _ in range(count):
            self.particles.append({
                "x": x + random.uniform(-2, 2), "y": y,
                "vx": random.uniform(-8, 8), "vy": random.uniform(-26, -12),
                "life": random.uniform(0.6, 1.3), "max": 1.3,
                "color": color, "size": random.choice((1, 2)),
                "grav": -4, "kind": "smoke",
            })

    def add_speed_lines(self, x, y, facing, color, count=5, spread=40):
        for _ in range(count):
            yy = y + random.uniform(-spread, spread)
            self.particles.append({
                "x": x, "y": yy,
                "vx": -facing * random.uniform(260, 480),
                "vy": random.uniform(-12, 12),
                "life": 0.16, "max": 0.16, "color": color,
                "size": random.choice((1, 2)), "grav": 0, "kind": "line",
            })

    def add_text(self, x, y, text, color=(255, 255, 255), scale=1, life=0.8, vy=-34):
        self.texts.append({
            "x": x, "y": y, "text": str(text), "color": color, "scale": scale,
            "life": life, "max": life, "vy": vy,
        })

    def add_ring(self, x, y, color, radius=6, speed=180, life=0.3, width=2):
        self.rings.append({"x": x, "y": y, "r": radius, "vr": speed,
                           "life": life, "max": life, "color": color, "w": width})

    # ------------------------------------------------------------------ update
    def update(self, dt: float):
        for p in self.particles:
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["vy"] += p["grav"] * dt
            p["life"] -= dt
            if p["kind"] == "dust":
                p["vx"] *= 0.96
        self.particles = [p for p in self.particles if p["life"] > 0]

        for t in self.texts:
            t["y"] += t["vy"] * dt
            t["vy"] *= 0.96
            t["life"] -= dt
        self.texts = [t for t in self.texts if t["life"] > 0]

        for r in self.rings:
            r["r"] += r["vr"] * dt
            r["life"] -= dt
        self.rings = [r for r in self.rings if r["life"] > 0]

        self.trauma = max(0.0, self.trauma - dt * 1.8)
        self.flash = max(0.0, self.flash - dt * 4.0)

    # ------------------------------------------------------------------ draw
    def get_shake(self):
        if self.trauma <= 0:
            return 0, 0
        amp = self.trauma * self.trauma * 7
        return int(random.uniform(-amp, amp)), int(random.uniform(-amp, amp))

    def draw(self, surface, ox=0, oy=0):
        for r in self.rings:
            a = max(0.0, r["life"] / r["max"])
            rr = int(r["r"])
            if rr < 1 or a < 0.3:
                continue
            size = rr * 2 + r["w"] * 2 + 4
            layer = pygame.Surface((size, size), pygame.SRCALPHA)
            pygame.draw.circle(layer, (*r["color"], int(255 * (a ** 1.5))),
                               (size // 2, size // 2), rr, r["w"])
            surface.blit(layer, (int(r["x"] + ox - size / 2), int(r["y"] + oy - size / 2)))
        for p in self.particles:
            a = max(0.0, p["life"] / p["max"])
            if p["kind"] == "line":
                pygame.draw.line(surface, p["color"],
                                 (int(p["x"] + ox), int(p["y"] + oy)),
                                 (int(p["x"] + ox + p["vx"] * 0.03), int(p["y"] + oy)), 1)
                continue
            if p["kind"] == "smoke":
                col = tuple(int(c * 0.8 + 40 * (1 - a)) for c in p["color"])
            else:
                col = tuple(int(c * (0.55 + 0.45 * a)) for c in p["color"])
            size = max(1, int(p["size"] * (0.6 + 0.4 * a)))
            surface.fill(col, (int(p["x"] + ox), int(p["y"] + oy), size, size))
        for t in self.texts:
            a = max(0.0, t["life"] / t["max"])
            tw = font.text_width(t["text"], t["scale"]) + 16
            layer = pygame.Surface((tw, 7 * t["scale"] + 12), pygame.SRCALPHA)
            col = (*t["color"], int(255 * min(1.0, a * 1.6)))
            font.draw_text(layer, t["text"], tw // 2, 4, t["scale"], col,
                           shadow=(0, 0, 0, int(200 * a)), align="center")
            surface.blit(layer, (int(t["x"] + ox) - tw // 2, int(t["y"] + oy) - 4))

    def draw_flash(self, surface):
        if self.flash > 0:
            f = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            f.fill((255, 255, 255, int(200 * self.flash)))
            surface.blit(f, (0, 0))
