"""Pixel-art rendering for fighters, Stands, portraits and props.

Fighters and Stands come from the imported art in ``assets/characters`` and are
animated entirely in code (bobbing, squash & stretch, lean, hit recoil) by
``game.art``. A procedural skeleton renderer is kept as a fallback so the game
still runs if the art is missing.
"""
from __future__ import annotations

import math
import random

import pygame

from .art import ART, draw_sprite_fighter, draw_sprite_stand
from .config import CYAN, GOLD, GROUND_Y, INK, PURPLE, PURPLE_LIGHT

# ------------------------------------------------------------------ palettes
JOTARO = {
    "skin": (236, 188, 150),
    "skin_sh": (196, 140, 108),
    "hair": (26, 30, 44),
    "hair_hi": (52, 58, 80),
    "uniform": (30, 42, 64),
    "uniform_hi": (50, 68, 98),
    "uniform_dark": (19, 27, 43),
    "coat": (26, 36, 56),
    "coat_hi": (44, 60, 88),
    "trim": (216, 176, 86),
    "cap": (36, 54, 74),
    "cap_hi": (58, 84, 114),
    "eye": (104, 228, 204),
    "shoe": (24, 20, 28),
    "legs": (30, 42, 64),
    "legs_dark": (19, 27, 43),
    "outline": (12, 10, 20),
}

DIO = {
    "skin": (242, 216, 190),
    "skin_sh": (198, 164, 146),
    "hair": (246, 214, 112),
    "hair_hi": (255, 240, 168),
    "hair_sh": (184, 144, 62),
    "uniform": (236, 196, 76),
    "uniform_hi": (255, 226, 122),
    "uniform_dark": (164, 124, 38),
    "coat": (226, 184, 68),
    "coat_hi": (255, 224, 120),
    "trim": (76, 164, 120),
    "cap": (58, 142, 102),
    "cap_hi": (96, 196, 144),
    "eye": (236, 74, 78),
    "shoe": (46, 36, 34),
    "legs": (52, 56, 68),
    "legs_dark": (34, 38, 48),
    "outline": (24, 14, 18),
}

STAR_PLATINUM = {
    "body": (132, 96, 196),
    "body_hi": (178, 142, 236),
    "body_sh": (86, 58, 140),
    "accent": (108, 230, 255),
    "accent2": (64, 168, 206),
    "gold": (232, 190, 92),
    "hair": (36, 30, 62),
    "eye": (140, 245, 255),
    "outline": (26, 16, 44),
}

THE_WORLD = {
    "body": (218, 182, 88),
    "body_hi": (252, 224, 138),
    "body_sh": (158, 124, 44),
    "accent": (52, 104, 106),
    "accent2": (34, 70, 74),
    "gold": (244, 226, 160),
    "hair": (44, 70, 72),
    "eye": (244, 86, 86),
    "outline": (34, 24, 16),
}

CHAR_PALETTES = {"jotaro": JOTARO, "dio": DIO}
STAND_PALETTES = {"jotaro": STAR_PLATINUM, "dio": THE_WORLD}


# ------------------------------------------------------------------ helpers
def _p(x, y):
    return (int(round(x)), int(round(y)))


def _line(s, c, a, b, w):
    pygame.draw.line(s, c, _p(*a), _p(*b), max(1, int(w)))


def _circle(s, c, a, r):
    pygame.draw.circle(s, c, _p(*a), max(1, int(r)))


def _rect(s, c, x, y, w, h):
    s.fill(c, (int(round(x)), int(round(y)), max(1, int(round(w))), max(1, int(round(h)))))


def _poly(s, c, pts):
    pygame.draw.polygon(s, c, [_p(*p) for p in pts])


def _limb(s, a, b, w, color, outline, hi=None):
    """Chunky pixel limb with a 1px outline and optional highlight."""
    _line(s, outline, a, b, w + 2)
    _circle(s, outline, a, (w + 2) // 2)
    _circle(s, outline, b, (w + 2) // 2)
    _line(s, color, a, b, w)
    _circle(s, color, a, w // 2)
    _circle(s, color, b, w // 2)
    if hi:
        _line(s, hi, (a[0] - 1, a[1] - 1), (b[0] - 1, b[1] - 1), max(1, w // 3))


def _shoe(s, x, y, facing, colors, big=False):
    """Local coords; facing is applied by caller through the transform."""
    w = 9 if big else 8
    _rect(s, colors["outline"], x - 4, y - 3, w + 2, 5)
    _rect(s, colors["shoe"], x - 3, y - 3, w, 4)
    _rect(s, colors.get("uniform_dark", colors["shoe"]), x - 3, y - 1, w, 1)


# ------------------------------------------------------------------ poses
def _base_pose():
    return {
        "hip": (0.0, -44.0),
        "neck": (0.0, -70.0),
        "head": (0.0, -81.0),
        "hand_f": (8.0, -50.0),
        "elbow_f": (9.0, -61.0),
        "hand_b": (-8.0, -49.0),
        "elbow_b": (-9.0, -61.0),
        "knee_f": (8.0, -22.0),
        "foot_f": (9.0, 0.0),
        "knee_b": (-9.0, -22.0),
        "foot_b": (-10.0, 0.0),
        "lean": 0.0,
    }


def _attack_extent(move, t: float) -> float:
    if move is None:
        return 0.0
    if t < move.startup:
        return -0.25 * (t / max(0.001, move.startup))
    if t < move.startup + move.active:
        return 1.0
    rem = (t - move.startup - move.active) / max(0.001, move.recovery)
    return max(0.0, 1.0 - rem)


def build_pose(f, t: float) -> dict:
    p = _base_pose()
    state = f.state
    if state == "ko":
        return {
            "hip": (0, -9), "neck": (-16, -13), "head": (-25, -13),
            "hand_f": (3, -4), "elbow_f": (-5, -7),
            "hand_b": (-13, -22), "elbow_b": (-9, -16),
            "knee_f": (11, -7), "foot_f": (22, -2),
            "knee_b": (-3, -5), "foot_b": (6, -2), "lean": 0,
        }

    if state == "hurt":
        p["hip"] = (2, -42)
        p["neck"] = (-5, -67)
        p["head"] = (-9, -78)
        p["hand_f"] = (14, -72)
        p["elbow_f"] = (8, -61)
        p["hand_b"] = (-13, -68)
        p["elbow_b"] = (-11, -58)
        p["knee_f"] = (9, -21)
        p["knee_b"] = (-12, -20)
        p["foot_b"] = (-16, 0)
        p["lean"] = -6
        return p

    if state == "jump" or not f.on_ground:
        p["hip"] = (0, -47)
        p["neck"] = (0, -73)
        p["head"] = (0, -84)
        p["knee_f"] = (12, -39)
        p["foot_f"] = (16, -31)
        p["knee_b"] = (-10, -38)
        p["foot_b"] = (-14, -33)
        p["hand_f"] = (14, -63)
        p["elbow_f"] = (10, -55)
        p["hand_b"] = (-14, -61)
        p["elbow_b"] = (-11, -54)
        return p

    if state == "crouch":
        p["hip"] = (0, -29)
        p["neck"] = (0, -54)
        p["head"] = (0, -65)
        p["knee_f"] = (12, -18)
        p["foot_f"] = (13, 0)
        p["knee_b"] = (-12, -18)
        p["foot_b"] = (-13, 0)
        p["hand_f"] = (9, -51)
        p["elbow_f"] = (8, -42)
        p["hand_b"] = (4, -49)
        p["elbow_b"] = (-2, -44)
        return p

    if state == "block":
        p["neck"] = (-1, -69)
        p["head"] = (-1, -80)
        p["hand_f"] = (13, -67)
        p["elbow_f"] = (6, -57)
        p["hand_b"] = (10, -60)
        p["elbow_b"] = (2, -51)
        p["knee_f"] = (9, -22)
        p["foot_f"] = (11, 0)
        p["foot_b"] = (-12, 0)
        p["lean"] = -2
        return p

    if state == "heal":
        p["head"] = (1, -80)
        p["hand_f"] = (5, -72)
        p["elbow_f"] = (8, -60)
        p["hand_b"] = (-6, -47)
        p["elbow_b"] = (-8, -58)
        p["lean"] = 1
        return p

    if state == "attack" and f.move is not None:
        m = f.move
        ext = _attack_extent(m, t)
        key = m.key
        if key in ("jab", "punch"):
            p["hand_f"] = (8 + 24 * ext, -64 + 2 * ext)
            p["elbow_f"] = (8 + 12 * ext, -62)
            p["head"] = (2 * ext, -81)
            p["neck"] = (1.5 * ext, -70)
            p["hand_b"] = (-7 - 3 * ext, -54)
            p["lean"] = 2 * ext
        elif key == "kick":
            p["foot_f"] = (9 + 29 * ext, -32 * ext)
            p["knee_f"] = (9 + 14 * ext, -22 - 9 * ext)
            p["hip"] = (-2 * ext, -44)
            p["hand_f"] = (8 - 7 * ext, -57)
            p["elbow_f"] = (7 - 2 * ext, -62)
            p["hand_b"] = (-10 - 8 * ext, -62)
            p["lean"] = -5 * ext
        elif key in ("ora", "muda", "ora_kick", "muda_kick", "star_finger"):
            p["hand_f"] = (25, -65)
            p["elbow_f"] = (14, -64)
            p["hand_b"] = (-8, -52)
            p["neck"] = (1, -70)
            p["head"] = (2, -81)
            p["lean"] = 2
        elif key == "road_roller":
            p["hand_f"] = (20, -72)
            p["elbow_f"] = (12, -68)
            p["hand_b"] = (-8, -55)
            p["lean"] = -2
        return p

    if f.ult_pose > 0:
        p["hand_f"] = (27, -68)
        p["elbow_f"] = (16, -66)
        p["hand_b"] = (-10, -54)
        p["head"] = (2, -81)
        p["neck"] = (1, -70)
        p["lean"] = 2
        return p

    if f.summon_pose > 0:
        p["hand_f"] = (7, -98)
        p["elbow_f"] = (5, -80)
        p["hand_b"] = (-12, -56)
        p["head"] = (1, -82)
        p["lean"] = -1
        return p

    if state == "walk":
        ph = f.anim_t * 9.0
        sw = math.sin(ph)
        p["foot_f"] = (9 + 7 * sw, -max(0.0, sw) * 4)
        p["knee_f"] = (6 + 5 * sw, -22 + 1.5 * sw)
        p["foot_b"] = (-10 - 7 * sw, -max(0.0, -sw) * 4)
        p["knee_b"] = (-7 - 5 * sw, -22 - 1.5 * sw)
        p["hand_f"] = (8 - 6 * sw, -51)
        p["elbow_f"] = (9 - 2 * sw, -61)
        p["hand_b"] = (-8 + 6 * sw, -50)
        p["elbow_b"] = (-9 + 2 * sw, -60)
        p["hip"] = (0, -44 + abs(sw) * 0.8)
        p["neck"] = (1, -70 + abs(sw) * 0.8)
        p["head"] = (1, -81 + abs(sw) * 0.8)
        p["lean"] = 1.5
        return p

    # idle breathing
    bob = math.sin(t * 2.6 + f.anim_t) * 1.1
    p["hip"] = (0, -44 + bob * 0.25)
    p["neck"] = (0, -70 + bob)
    p["head"] = (0, -81 + bob)
    p["hand_f"] = (8, -50 + bob)
    p["elbow_f"] = (9, -61 + bob)
    p["hand_b"] = (-8, -49 + bob)
    p["elbow_b"] = (-9, -61 + bob)
    return p


# ------------------------------------------------------------------ fighter
def draw_fighter(surface, f, t: float):
    """Draw a fighter at f.x, feet at GROUND_Y - f.jump_y.

    Uses the imported sprite art when available (with code-driven squash,
    stretch, bob, lean and hit recoil) and falls back to the procedural
    skeleton otherwise.
    """
    if draw_sprite_fighter(surface, f, t):
        return
    _draw_skeleton_fighter(surface, f, t)


def _draw_skeleton_fighter(surface, f, t: float):
    colors = CHAR_PALETTES[f.character]
    pose = build_pose(f, t)
    facing = f.facing
    ox = f.x
    oy = GROUND_Y - f.jump_y

    def T(pt):
        return (ox + pt[0] * facing, oy + pt[1])

    hip = T(pose["hip"])
    neck = T(pose["neck"])
    head = T(pose["head"])
    hand_f, elbow_f = T(pose["hand_f"]), T(pose["elbow_f"])
    hand_b, elbow_b = T(pose["hand_b"]), T(pose["elbow_b"])
    knee_f, foot_f = T(pose["knee_f"]), T(pose["foot_f"])
    knee_b, foot_b = T(pose["knee_b"]), T(pose["foot_b"])
    out = colors["outline"]

    # shadow (drawn by FightScreen too; local soft shadow helps grounding)
    _ellipse_shadow(surface, ox, GROUND_Y + 1, 15, 3)

    # coat tails behind everything
    _draw_coat(surface, f, colors, hip, neck, facing, t)

    # back limbs
    _limb(surface, T((-2, -67)), elbow_b, 4, colors["uniform_dark"], out)
    _limb(surface, elbow_b, hand_b, 4, colors["uniform_dark"], out)
    _circle(surface, out, hand_b, 3)
    _circle(surface, colors["skin_sh"], hand_b, 2)
    _limb(surface, hip, knee_b, 6, colors["legs_dark"], out)
    _limb(surface, knee_b, foot_b, 6, colors["legs_dark"], out)
    _shoe(surface, foot_b[0] - 1 * facing, foot_b[1], facing, colors)

    # torso
    _draw_torso(surface, f, colors, hip, neck, facing)

    # front leg
    _limb(surface, hip, knee_f, 7, colors["legs"], out)
    _limb(surface, knee_f, foot_f, 7, colors["legs"], out)
    _line(surface, colors["uniform_hi"], (hip[0], hip[1] + 2), (knee_f[0], knee_f[1] + 1), 1)
    _shoe(surface, foot_f[0], foot_f[1], facing, colors, big=True)

    # head
    _draw_head(surface, f, colors, head, neck, facing, t)

    # front arm
    shoulder = T((2, -67))
    _limb(surface, shoulder, elbow_f, 4, colors["uniform"], out)
    _limb(surface, elbow_f, hand_f, 4, colors["uniform"], out)
    _circle(surface, out, hand_f, 3)
    _circle(surface, colors["skin"], hand_f, 2)

    # accessories
    _draw_accessories(surface, f, colors, pose, facing, t)


def _ellipse_shadow(surface, x, y, rx, ry, alpha=90):
    shadow = pygame.Surface((rx * 2 + 2, ry * 2 + 2), pygame.SRCALPHA)
    pygame.draw.ellipse(shadow, (0, 0, 0, alpha), (0, 0, rx * 2, ry * 2))
    surface.blit(shadow, (int(x - rx), int(y - ry)))


def _draw_torso(surface, f, c, hip, neck, facing):
    out = c["outline"]
    # jacket body
    pts = [
        (neck[0] - 7 * facing, neck[1] + 1),
        (neck[0] + 7 * facing, neck[1] + 1),
        (hip[0] + 6 * facing, hip[1]),
        (hip[0] - 6 * facing, hip[1]),
    ]
    _poly(surface, out, pts)
    inner = [
        (neck[0] - 5 * facing, neck[1] + 2),
        (neck[0] + 5 * facing, neck[1] + 2),
        (hip[0] + 4 * facing, hip[1] - 1),
        (hip[0] - 4 * facing, hip[1] - 1),
    ]
    _poly(surface, c["uniform"], inner)
    # chest highlight / shirt
    if f.character == "jotaro":
        _poly(surface, c["uniform_hi"], [
            (neck[0] - 2 * facing, neck[1] + 3),
            (neck[0] + 4 * facing, neck[1] + 3),
            (hip[0] + 2 * facing, hip[1] - 4),
            (hip[0] - 1 * facing, hip[1] - 4),
        ])
        # gold chain across the chest
        for i in range(4):
            px = neck[0] + (1 + i * 1.1) * facing
            py = neck[1] + 7 + i * 4
            _rect(surface, c["trim"], px, py, 2, 2)
        # belt
        _rect(surface, c["trim"], hip[0] - 5, hip[1] - 3, 10, 2)
        _rect(surface, (196, 154, 72), hip[0] - 2, hip[1] - 3, 4, 2)
    else:
        # DIO's green chest straps + heart
        _line(surface, c["trim"], (neck[0] - 5 * facing, neck[1] + 4),
              (hip[0] + 3 * facing, hip[1] - 6), 2)
        _line(surface, c["trim"], (neck[0] + 5 * facing, neck[1] + 4),
              (hip[0] - 3 * facing, hip[1] - 6), 2)
        _draw_heart(surface, neck[0] + 1 * facing, neck[1] + 11, c["trim"], 2)
        _rect(surface, c["uniform_dark"], hip[0] - 5 * facing, hip[1] - 3, 7, 2)


def _draw_coat(surface, f, c, hip, neck, facing, t):
    out = c["outline"]
    sway = math.sin(t * 2.2 + f.anim_t) * 1.2
    if f.character == "jotaro":
        pts = [
            (neck[0] - 9 * facing, neck[1] + 1),
            (neck[0] + 8 * facing, neck[1] + 2),
            (hip[0] + 9 * facing, hip[1] + 10),
            (hip[0] + 3 * facing, hip[1] + 17),
            (hip[0] - 8 * facing, hip[1] + 15 + sway),
            (hip[0] - 17 * facing, hip[1] + 9 + sway),
            (hip[0] - 11 * facing, hip[1] + 1),
        ]
        _poly(surface, out, pts)
        inner = [(x + (2 * facing if x < hip[0] else -2 * facing), y + 1) for x, y in pts]
        _poly(surface, c["coat"], inner)
        _line(surface, c["coat_hi"], (neck[0] - 7 * facing, neck[1] + 3),
              (hip[0] - 13 * facing, hip[1] + 9), 1)
        # jagged coat tails
        for i in range(3):
            tx = hip[0] - (6 + i * 4) * facing
            _rect(surface, c["uniform_dark"], tx, hip[1] + 12, 2, 5)
    else:
        pts = [
            (neck[0] - 9 * facing, neck[1] + 1),
            (neck[0] + 8 * facing, neck[1] + 2),
            (hip[0] + 9 * facing, hip[1] + 5),
            (hip[0] + 4 * facing, hip[1] + 12),
            (hip[0] - 9 * facing, hip[1] + 9 + sway),
            (hip[0] - 14 * facing, hip[1] + 2),
        ]
        _poly(surface, out, pts)
        inner = [(x + (2 * facing if x < hip[0] else -2 * facing), y + 1) for x, y in pts]
        _poly(surface, c["coat"], inner)
        _line(surface, c["coat_hi"], (neck[0] - 6 * facing, neck[1] + 3),
              (hip[0] - 9 * facing, hip[1] + 5), 1)


def _draw_head(surface, f, c, head, neck, facing, t):
    hx, hy = head
    out = c["outline"]
    # neck
    _limb(surface, neck, (hx, hy + 7), 5, c["skin_sh"], out)

    # back hair
    if f.character == "jotaro":
        _poly(surface, out, [
            (hx - 9, hy + 4), (hx - 7, hy - 5), (hx - 2, hy - 4),
            (hx - 4, hy + 2), (hx - 1, hy + 5),
        ])
        _poly(surface, c["hair"], [
            (hx - 7, hy + 3), (hx - 6, hy - 3), (hx - 3, hy - 3),
            (hx - 4, hy + 1), (hx - 2, hy + 4),
        ])
    else:
        _poly(surface, out, [
            (hx - 10, hy + 8), (hx - 11, hy - 1), (hx - 7, hy - 3),
            (hx - 9, hy - 12), (hx - 3, hy - 6), (hx - 1, hy - 16),
            (hx + 3, hy - 7), (hx + 6, hy - 13), (hx + 9, hy - 5),
            (hx + 10, hy + 3), (hx + 4, hy + 2), (hx - 3, hy + 6),
        ])
        _poly(surface, c["hair"], [
            (hx - 8, hy + 6), (hx - 9, hy - 1), (hx - 6, hy - 2),
            (hx - 7, hy - 10), (hx - 2, hy - 5), (hx, hy - 13),
            (hx + 3, hy - 6), (hx + 5, hy - 11), (hx + 7, hy - 4),
            (hx + 8, hy + 2), (hx + 3, hy + 1), (hx - 2, hy + 4),
        ])
        _line(surface, c["hair_sh"], (hx - 8, hy + 4), (hx - 8, hy - 6), 1)
        _line(surface, c["hair_sh"], (hx + 7, hy + 3), (hx + 6, hy - 4), 1)

    # face
    _circle(surface, out, (hx, hy), 8)
    _circle(surface, c["skin"], (hx, hy), 7)
    # jaw / chin
    _rect(surface, c["skin"], hx - 3, hy + 5, 7, 3)
    _rect(surface, c["skin_sh"], hx - 1, hy + 7, 4, 1)
    # ear
    _rect(surface, c["skin_sh"], hx - 7, hy + 1, 2, 3)

    # eyes
    hurt = f.state in ("hurt", "ko")
    ex = hx + 3
    if hurt:
        _line(surface, out, (ex - 1, hy - 1), (ex + 2, hy - 1), 1)
        _line(surface, out, (hx - 4, hy - 1), (hx - 2, hy - 1), 1)
    else:
        _rect(surface, (250, 248, 238), ex - 1, hy - 2, 3, 2)
        _rect(surface, c["eye"], ex, hy - 2, 2, 2)
        _rect(surface, out, ex + 1, hy - 1, 1, 1)
        _rect(surface, (250, 248, 238), hx - 4, hy - 2, 2, 2)
        _rect(surface, c["eye"], hx - 4, hy - 2, 1, 2)
        # angry brow
        _line(surface, c["hair"] if f.character == "dio" else out,
              (ex - 1, hy - 4), (ex + 2, hy - 3), 1)
        _line(surface, out, (hx - 5, hy - 3), (hx - 2, hy - 4), 1)
    # nose
    _rect(surface, c["skin_sh"], hx + 6, hy + 1, 2, 1)
    # mouth
    if f.state in ("attack", "hurt", "ko") or f.ult_pose > 0:
        _rect(surface, (92, 40, 48), hx + 1, hy + 4, 4, 2)
    else:
        _line(surface, (150, 82, 74), (hx + 1, hy + 5), (hx + 4, hy + 5), 1)

    # headgear
    if f.character == "jotaro":
        cap = [
            (hx - 8, hy - 3), (hx - 7, hy - 9), (hx + 4, hy - 10),
            (hx + 8, hy - 5), (hx + 8, hy - 2), (hx - 8, hy - 2),
        ]
        _poly(surface, out, cap)
        _poly(surface, c["cap"], [
            (hx - 6, hy - 4), (hx - 6, hy - 8), (hx + 3, hy - 9),
            (hx + 6, hy - 5), (hx + 6, hy - 3), (hx - 6, hy - 3),
        ])
        # brim
        _rect(surface, out, hx + 1, hy - 5, 12, 4)
        _rect(surface, c["cap_hi"], hx + 2, hy - 4, 10, 2)
        # gold band + emblem
        _rect(surface, c["trim"], hx - 6, hy - 4, 13, 2)
        _rect(surface, (255, 230, 140), hx + 2, hy - 4, 2, 2)
        _line(surface, c["cap_hi"], (hx - 4, hy - 8), (hx + 2, hy - 8), 1)
    else:
        # solid swept-back hair cap + three spikes (avoids a "crown" look)
        # hairline / fringe over the forehead (spikes live behind the head)
        _poly(surface, out, [
            (hx - 9, hy - 6), (hx + 9, hy - 6), (hx + 8, hy - 3),
            (hx + 2, hy - 4), (hx - 2, hy - 3), (hx - 7, hy - 4),
        ])
        _poly(surface, c["hair"], [
            (hx - 7, hy - 5), (hx + 7, hy - 5), (hx + 7, hy - 4),
            (hx + 2, hy - 4), (hx - 2, hy - 4), (hx - 5, hy - 4),
        ])
        # sideburns
        _rect(surface, c["hair"], hx - 9, hy + 1, 2, 5)
        _rect(surface, c["hair"], hx + 8, hy + 1, 2, 6)
        _line(surface, c["hair_hi"], (hx - 3, hy - 9), (hx + 1, hy - 5), 1)
        _line(surface, c["hair_hi"], (hx + 4, hy - 9), (hx + 5, hy - 5), 1)


def _draw_accessories(surface, f, c, pose, facing, t):
    hip = pose["hip"]
    if f.character == "jotaro":
        # belt buckle star
        _draw_star(surface, f.x + hip[0] * facing, GROUND_Y - f.jump_y + hip[1] - 2,
                   c["trim"], 2)
        if f.state == "heal":
            # cigarette + ember
            hx = f.x + pose["hand_f"][0] * facing
            hy = GROUND_Y - f.jump_y + pose["hand_f"][1]
            if facing > 0:
                _rect(surface, (238, 236, 226), hx + 1, hy - 1, 4, 1)
                _rect(surface, (255, 138, 48), hx + 5, hy - 1, 2, 2)
            else:
                _rect(surface, (238, 236, 226), hx - 4, hy - 1, 4, 1)
                _rect(surface, (255, 138, 48), hx - 5, hy - 1, 2, 2)
    else:
        if f.state == "heal":
            hx = f.x + pose["hand_f"][0] * facing
            hy = GROUND_Y - f.jump_y + pose["hand_f"][1]
            # wine bottle
            _rect(surface, (32, 60, 46), hx - 2, hy + 1, 5, 9)
            _rect(surface, (58, 104, 74), hx - 1, hy + 2, 2, 6)
            _rect(surface, (210, 196, 160), hx - 1, hy - 2, 3, 4)
            _rect(surface, (238, 226, 190), hx - 1, hy - 3, 3, 2)
        # heart knee pad
        kx = f.x + pose["knee_f"][0] * facing
        ky = GROUND_Y - f.jump_y + pose["knee_f"][1]
        _draw_heart(surface, kx, ky, c["trim"], 2)


# ------------------------------------------------------------------ icons
def _draw_heart(surface, x, y, color, size=3):
    s = max(1, size)
    _rect(surface, color, x - s, y - s, s, s)
    _rect(surface, color, x + 1, y - s, s, s)
    _rect(surface, color, x - s, y, s * 2 + 1, s)
    _rect(surface, color, x - s + 1, y + s, s * 2 - 1, s)
    _rect(surface, color, x - 1, y + s * 2, s + 1, s)


def _draw_star(surface, x, y, color, size=3):
    s = max(1, size)
    _rect(surface, color, x - 1, y - s * 2, s, s * 4 + 1)
    _rect(surface, color, x - s * 2, y - 1, s * 4 + 1, s)
    _rect(surface, color, x - s, y - s, s * 2 + 1, s * 2 + 1)


def draw_star_icon(surface, x, y, color, size=3):
    _draw_star(surface, x, y, color, size)


def draw_heart_icon(surface, x, y, color, size=3):
    _draw_heart(surface, x, y, color, size)


# ------------------------------------------------------------------ stands
def draw_stand(surface, f, t: float):
    if not f.stand_active and f.stand_alpha <= 0:
        return
    if draw_sprite_stand(surface, f, t):
        return
    _draw_skeleton_stand(surface, f, t)


def _draw_skeleton_stand(surface, f, t: float):
    pal = STAND_PALETTES[f.character]
    facing = f.facing
    attacking = f.state == "attack" and f.move is not None
    offset = 8 if attacking else -20
    if f.ult_pose > 0 or f.state == "timestop":
        offset = -26
    sx = f.x + offset * facing
    sy = GROUND_Y - f.jump_y + 2

    tmp = pygame.Surface((220, 180), pygame.SRCALPHA)
    ox, oy = 110, 168
    bob = math.sin(t * 2.0 + 1.3) * 2.0

    def T(pt):
        return (ox + pt[0] * facing, oy + pt[1] + bob)

    # aura: concentric rings instead of muddy filled blobs
    pulse = 0.5 + 0.5 * math.sin(t * 3.4)
    for i, (r, a) in enumerate(((46, 60), (38, 80), (30, 110))):
        pygame.draw.circle(tmp, (*pal["body_hi"], a), (ox, oy - 58), int(r + pulse * 2), 1)
    for i in range(6):
        ang = t * 0.9 + i * math.pi / 3
        px = ox + math.cos(ang) * 42
        py = oy - 58 + math.sin(ang) * 46
        tmp.fill((*pal["accent"], 170), (int(px), int(py), 2, 2))

    hip = T((0, -54))
    neck = T((0, -92))
    head = T((0, -106))
    out = pal["outline"]

    # cape / back aura shape
    if f.character == "dio":
        _poly(tmp, (*pal["accent2"], 210), [
            (neck[0] - 9, neck[1]), (neck[0] + 9, neck[1]),
            (hip[0] + 15, hip[1] + 16), (hip[0] - 15, hip[1] + 16),
        ])
    else:
        _poly(tmp, (*pal["hair"], 230), [
            (head[0] - 9, head[1] + 2), (head[0] - 12, head[1] + 16),
            (head[0] - 7, head[1] + 12), (head[0] - 5, head[1] + 20),
            (head[0] - 1, head[1] + 12),
        ])

    # legs
    foot_f = T((11, -4))
    foot_b = T((-11, -4))
    knee_f = T((10, -28))
    knee_b = T((-10, -28))
    _limb(tmp, hip, knee_b, 7, pal["body_sh"], out)
    _limb(tmp, knee_b, foot_b, 7, pal["body_sh"], out)
    _limb(tmp, hip, knee_f, 8, pal["body"], out, pal["body_hi"])
    _limb(tmp, knee_f, foot_f, 8, pal["body"], out, pal["body_hi"])
    if f.character == "dio":
        _draw_heart(tmp, knee_f[0], knee_f[1], pal["accent"], 2)

    # torso
    _poly(tmp, out, [
        (neck[0] - 9, neck[1] + 1), (neck[0] + 9, neck[1] + 1),
        (hip[0] + 8, hip[1]), (hip[0] - 8, hip[1]),
    ])
    _poly(tmp, pal["body"], [
        (neck[0] - 7, neck[1] + 2), (neck[0] + 7, neck[1] + 2),
        (hip[0] + 6, hip[1] - 1), (hip[0] - 6, hip[1] - 1),
    ])
    _poly(tmp, pal["body_hi"], [
        (neck[0] - 4, neck[1] + 3), (neck[0] + 2, neck[1] + 3),
        (hip[0] + 1, hip[1] - 2), (hip[0] - 4, hip[1] - 2),
    ])

    # shoulders / pads
    _circle(tmp, out, T((-8, -88)), 6)
    _circle(tmp, pal["accent"], T((-8, -88)), 5)
    _circle(tmp, out, T((8, -88)), 6)
    _circle(tmp, pal["accent"], T((8, -88)), 5)
    if f.character == "jotaro":
        _rect(tmp, pal["gold"], T((5, -86))[0] - 2, T((5, -86))[1], 4, 3)
    else:
        _draw_heart(tmp, T((0, -78))[0], T((0, -78))[1], pal["accent"], 2)

    # head
    _circle(tmp, out, head, 9)
    _circle(tmp, pal["body"], head, 8)
    _rect(tmp, pal["body_sh"], head[0] - 2, head[1] + 6, 6, 3)
    _rect(tmp, (250, 250, 245), head[0] + 3, head[1] - 2, 3, 2)
    _rect(tmp, pal["eye"], head[0] + 4, head[1] - 2, 2, 2)
    _rect(tmp, (250, 250, 245), head[0] - 5, head[1] - 2, 2, 2)
    _rect(tmp, pal["eye"], head[0] - 5, head[1] - 2, 1, 2)
    if f.character == "jotaro":
        # headband with tails
        _rect(tmp, pal["gold"], head[0] - 8, head[1] - 7, 16, 3)
        _line(tmp, pal["gold"], (head[0] - 8, head[1] - 6), (head[0] - 16, head[1] - 2), 2)
        _line(tmp, pal["gold"], (head[0] - 8, head[1] - 5), (head[0] - 15, head[1] + 4), 1)
    else:
        # twin vents
        _rect(tmp, out, head[0] - 6, head[1] - 14, 4, 8)
        _rect(tmp, pal["gold"], head[0] - 5, head[1] - 13, 2, 6)
        _rect(tmp, out, head[0] + 3, head[1] - 14, 4, 8)
        _rect(tmp, pal["gold"], head[0] + 4, head[1] - 13, 2, 6)
        _rect(tmp, pal["accent"], head[0] - 7, head[1] + 5, 15, 3)

    # arms
    if f.state == "attack" and f.move is not None and f.move.key in ("ora", "muda"):
        # rapid punch afterimages
        for i, (dx, dy, col) in enumerate((
            (34, -76, pal["body_sh"]), (40, -82, pal["body"]),
            (36, -70, pal["body_hi"]),
        )):
            hx = T((dx + (i - 1) * 3, dy))[0]
            hy = T((dx + (i - 1) * 3, dy))[1]
            _limb(tmp, T((8, -88)), (hx, hy), 5, col, out)
            _circle(tmp, out, (hx, hy), 4)
            _circle(tmp, pal["accent"], (hx, hy), 2)
        _line(tmp, pal["accent"], (T((18, -78))[0], T((18, -78))[1]),
              (T((48, -78))[0], T((48, -78))[1]), 1)
    elif f.state == "attack" and f.move is not None and f.move.key in ("ora_kick", "muda_kick"):
        # stand kick: extended front leg + trailing afterimage
        kick_knee = T((20, -40))
        kick_foot = T((46, -46))
        _limb(tmp, T((4, -50)), kick_knee, 8, pal["body"], out, pal["body_hi"])
        _limb(tmp, kick_knee, kick_foot, 8, pal["body"], out, pal["body_hi"])
        _circle(tmp, out, kick_foot, 4)
        _circle(tmp, pal["accent"], kick_foot, 2)
        _line(tmp, pal["accent"], (T((26, -42))[0], T((26, -42))[1]),
              (T((58, -50))[0], T((58, -50))[1]), 1)
        _limb(tmp, T((8, -88)), T((24, -74)), 6, pal["body_sh"], out)
    elif f.state == "attack" and f.move is not None and f.move.key == "star_finger":
        _limb(tmp, T((8, -84)), T((28, -74)), 5, pal["body"], out, pal["body_hi"])
        _circle(tmp, out, T((29, -72)), 4)
        _circle(tmp, pal["accent"], T((29, -72)), 2)
    elif f.ult_pose > 0 or f.state == "timestop":
        _limb(tmp, T((8, -88)), T((30, -76)), 6, pal["body"], out, pal["body_hi"])
        _limb(tmp, T((-8, -88)), T((-30, -76)), 6, pal["body"], out, pal["body_hi"])
        _circle(tmp, pal["accent"], T((31, -74)), 3)
        _circle(tmp, pal["accent"], T((-31, -74)), 3)
    elif f.state == "attack" and f.move is not None and f.move.key == "road_roller":
        _limb(tmp, T((8, -88)), T((14, -114)), 6, pal["body"], out, pal["body_hi"])
        _circle(tmp, pal["accent"], T((14, -112)), 3)
    else:
        # arms relaxed at the sides, fists clenched
        _limb(tmp, T((-10, -88)), T((-13, -70)), 7, pal["body_sh"], out)
        _limb(tmp, T((-13, -70)), T((-10, -52)), 7, pal["body_sh"], out)
        _circle(tmp, out, T((-10, -50)), 4)
        _circle(tmp, pal["body_sh"], T((-10, -50)), 3)
        _limb(tmp, T((10, -88)), T((13, -70)), 7, pal["body"], out, pal["body_hi"])
        _limb(tmp, T((13, -70)), T((10, -52)), 7, pal["body"], out, pal["body_hi"])
        _circle(tmp, out, T((10, -50)), 4)
        _circle(tmp, pal["body"], T((10, -50)), 3)

    # floating sparkles
    for i in range(3):
        px = ox + math.sin(t * 1.7 + i * 2.1) * 34
        py = oy - 40 - ((t * 12 + i * 23) % 70)
        tmp.fill((*pal["accent"], 140), (int(px), int(py), 2, 2))

    alpha = int(235 * max(0.0, min(1.0, f.stand_alpha)))
    tmp.set_alpha(alpha)
    surface.blit(tmp, (int(sx - ox), int(sy - oy)))

    # Star Finger beam is drawn on the main surface so it can reach far.
    if f.state == "attack" and f.move is not None and f.move.key == "star_finger":
        t0 = max(0.0, min(1.0, (f.move_t - 0.18) / 0.1))
        if t0 > 0:
            x0 = sx + 30 * facing
            y0 = sy - 72
            x1 = f.x + (f.move.reach + 12) * facing
            glow = pygame.Surface((abs(x1 - x0) + 30, 26), pygame.SRCALPHA)
            gx = 15 if facing > 0 else abs(x1 - x0) + 15
            pygame.draw.line(glow, (*pal["accent"], 60), (gx, 13), (gx + (x1 - x0), 13), 9)
            pygame.draw.line(glow, (*pal["accent"], 220), (gx, 13), (gx + (x1 - x0), 13), 3)
            surface.blit(glow, (int(min(x0, x1) - 15), int(y0 - 13)))
            # knuckle segments
            for i in range(1, 5):
                kx = x0 + (x1 - x0) * i / 5
                _rect(surface, pal["accent"], kx - 1, y0 - 1, 3, 3)


# ------------------------------------------------------------------ roller
def draw_roller(surface, x, y, scale=1.0, flash=0.0):
    """Draw DIO's steamroller. (x, y) is the top-left corner."""
    s = scale
    w, h = int(96 * s), int(52 * s)
    out = (22, 18, 22)
    steel = (94, 100, 108)
    steel_hi = (142, 148, 154)
    steel_dark = (58, 62, 70)
    yellow = (214, 172, 62)
    yellow_hi = (246, 208, 96)
    rust = (150, 78, 58)
    if flash > 0:
        steel = (240, 240, 240)
        yellow = (255, 250, 220)

    def R(c, rx, ry, rw, rh):
        surface.fill(c, (int(x + rx), int(y + ry), max(1, int(rw)), max(1, int(rh))))

    # body / cab
    R(out, 2, 8, w - 4, h - 10)
    R(yellow, 4, 10, w - 8, h - 14)
    R(yellow_hi, 6, 12, w - 14, 4)
    R(steel_dark, 4, h - 12, w - 8, 5)
    # drum
    R(out, 4, 16, 44, 30)
    R(steel, 6, 18, 40, 26)
    R(steel_hi, 8, 20, 36, 4)
    for i in range(4):
        R(steel_dark, 10 + i * 9, 22, 2, 20)
    R(rust, 6, 38, 40, 4)
    # cab
    R(out, 50, 2, 34, 40)
    R(yellow, 52, 4, 30, 36)
    R(steel, 56, 8, 16, 14)
    R(steel_hi, 58, 10, 12, 3)
    R(out, 54, 24, 26, 12)
    R(steel_dark, 56, 26, 22, 8)
    # chimney
    R(out, 74, -8, 8, 12)
    R(steel_dark, 75, -7, 6, 10)
    R(steel_hi, 76, -6, 2, 8)
    # wheels
    for wx in (16, 76):
        pygame.draw.circle(surface, out, (int(x + wx), int(y + h - 6)), int(7 * s))
        pygame.draw.circle(surface, steel_dark, (int(x + wx), int(y + h - 6)), int(5 * s))
        pygame.draw.circle(surface, steel, (int(x + wx), int(y + h - 6)), int(2 * s))
    # heart emblem
    _draw_heart(surface, int(x + 68 * s), int(y + 18 * s), (188, 52, 58), max(1, int(2 * s)))
    # rivets
    for rx in (8, 30, 52, 88):
        R(steel_hi, rx, 10, 2, 2)
    # motion streaks
    if flash > 0:
        for i in range(3):
            R((255, 255, 255), 0, 4 + i * 14, 8, 2)


# ------------------------------------------------------------------ portraits
PORTRAIT_PALETTES = {
    "jotaro": {
        ".": None, "k": (16, 12, 22), "s": (236, 188, 150), "S": (196, 140, 108),
        "c": (36, 54, 74), "C": (58, 84, 114), "g": (226, 186, 96),
        "h": (26, 30, 44), "e": (104, 228, 204), "w": (242, 240, 228),
        "m": (120, 60, 60),
    },
    "dio": {
        ".": None, "k": (20, 12, 18), "s": (242, 216, 190), "S": (198, 164, 146),
        "h": (246, 214, 112), "H": (255, 240, 168), "g": (76, 164, 120),
        "r": (236, 74, 78), "w": (242, 240, 228), "m": (120, 44, 54),
    },
}

PORTRAITS = {
    "jotaro": [
        "................",
        ".....kkkkkk.....",
        "....kcccccck....",
        "...kcccccccck...",
        "...kcggggggck...",
        "...kcccccccck...",
        "..kkkkkkkkkkkk..",
        "..khhhhhhhhhhk..",
        "..khsssssssshk..",
        "..khseesseeshk..",
        "..khsssssssshk..",
        "...ksssSSsssk...",
        "....kssssssk....",
        "....kssmmssk....",
        ".....kkkkkk.....",
        "................",
    ],
    "dio": [
        "................",
        "...h..h..h..h...",
        "..hHhhHhhHhhHh..",
        ".hhHhhhhhhhhHhh.",
        ".hhhhhhhhhhhhhh.",
        ".hhsssssssssshh.",
        ".hssssssssssssh.",
        ".hsrrsssssrrssh.",
        ".hssssssssssssh.",
        "..hssssssssssh..",
        "...kssmmmmssk...",
        "....kssssssk....",
        "....kggggggk....",
        ".....kkkkkk.....",
        "................",
        "................",
    ],
}


def draw_portrait(surface, character: str, x: int, y: int, scale: int = 2,
                  border: tuple | None = None, bg: tuple | None = None):
    art = ART.portrait(character)
    if art is not None:
        size = 16 * scale
        if bg is not None:
            surface.fill(bg, (x, y, size, size))
        img = pygame.transform.scale(art, (size, size))
        surface.blit(img, (x, y))
        if border is not None:
            pygame.draw.rect(surface, border, (x - 1, y - 1, size + 2, size + 2), 1)
        return

    grid = PORTRAITS[character]
    pal = PORTRAIT_PALETTES[character]
    w = len(grid[0]) * scale
    h = len(grid) * scale
    if bg is not None:
        surface.fill(bg, (x, y, w, h))
    for row, line in enumerate(grid):
        for col, ch in enumerate(line):
            color = pal.get(ch)
            if color is None:
                continue
            surface.fill(color, (x + col * scale, y + row * scale, scale, scale))
    if border is not None:
        pygame.draw.rect(surface, border, (x - 1, y - 1, w + 2, h + 2), 1)


def draw_clock(surface, cx, cy, radius, color, hand_angle=0.0):
    pygame.draw.circle(surface, color, (int(cx), int(cy)), int(radius), 2)
    pygame.draw.circle(surface, color, (int(cx), int(cy)), max(1, int(radius * 0.12)))
    for i in range(12):
        a = i * math.pi / 6
        x0 = cx + math.cos(a) * radius * 0.72
        y0 = cy + math.sin(a) * radius * 0.72
        x1 = cx + math.cos(a) * radius * 0.86
        y1 = cy + math.sin(a) * radius * 0.86
        pygame.draw.line(surface, color, (x0, y0), (x1, y1), 1)
    pygame.draw.line(surface, color, (cx, cy),
                     (cx + math.cos(hand_angle) * radius * 0.6,
                      cy + math.sin(hand_angle) * radius * 0.6), 2)
    pygame.draw.line(surface, color, (cx, cy),
                     (cx + math.cos(hand_angle + 1.9) * radius * 0.45,
                      cy + math.sin(hand_angle + 1.9) * radius * 0.45), 1)
