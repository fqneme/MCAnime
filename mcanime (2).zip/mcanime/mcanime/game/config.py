"""Global configuration, palette and character metadata."""
from __future__ import annotations

# ---------------------------------------------------------------- rendering
GAME_W, GAME_H = 480, 270
FPS = 60
GROUND_Y = 238.0
WINDOW_W, WINDOW_H = 1440, 810
TITLE = "STAND BATTLE: STARDUST SHOWDOWN"

# ---------------------------------------------------------------- palette
BLACK = (10, 8, 16)
INK = (18, 14, 26)
WHITE = (242, 238, 226)
GOLD = (232, 188, 86)
GOLD_DARK = (150, 108, 40)
PURPLE = (148, 92, 214)
PURPLE_LIGHT = (198, 160, 255)
CYAN = (116, 230, 255)
RED = (224, 66, 74)
RED_DARK = (110, 24, 38)
GREEN = (72, 220, 104)
GREEN_DARK = (26, 120, 54)
GREEN_GHOST = (214, 230, 120)
BLUE = (80, 130, 240)
ORANGE = (240, 148, 60)
YELLOW = (248, 220, 96)
SAND = (188, 148, 92)
SAND_DARK = (132, 98, 62)

UI_BG = (20, 16, 30)
UI_PANEL = (32, 26, 46)
UI_BORDER = (92, 74, 120)
UI_TEXT = (232, 226, 212)
UI_DIM = (146, 138, 160)

# ---------------------------------------------------------------- characters
CHARACTERS = {
    "jotaro": {
        "name": "JOTARO",
        "full": "JOTARO KUJO",
        "stand": "STAR PLATINUM",
        "stand_short": "STAR PLATINUM",
        "tagline": "YARE YARE DAZE",
        "accent": (86, 196, 170),
        "accent2": (44, 118, 108),
        "power": 8,
        "speed": 7,
        "utility": 7,
    },
    "dio": {
        "name": "DIO",
        "full": "DIO BRANDO",
        "stand": "THE WORLD",
        "stand_short": "THE WORLD",
        "tagline": "IT WAS ME, DIO!",
        "accent": (232, 188, 86),
        "accent2": (150, 108, 40),
        "power": 9,
        "speed": 6,
        "utility": 8,
    },
}

# ---------------------------------------------------------------- controls
CONTROLS = {
    "left": "A",
    "right": "D",
    "jump": "W",
    "crouch": "S",
    "light": "Z",
    "kick": "X",
    "utility": "C",
    "stand": "Q",
    "ultimate": "R",
    "pause": "ESC",
}

DEFAULT_SETTINGS = {
    "music": 0.55,
    "sfx": 0.85,
    "difficulty": "NORMAL",
    "fullscreen": False,
    "screen_shake": True,
    "show_hints": True,
}

DIFFICULTIES = {
    "EASY": {"reaction": (0.30, 0.46), "aggression": 0.58, "block": 0.34, "ult_rate": 0.5},
    "NORMAL": {"reaction": (0.18, 0.30), "aggression": 0.74, "block": 0.55, "ult_rate": 0.7},
    "HARD": {"reaction": (0.11, 0.20), "aggression": 0.9, "block": 0.76, "ult_rate": 0.9},
}
