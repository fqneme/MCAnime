"""Sprite loading, palette tinting and code-driven animation.

The game ships real character art in ``assets/characters`` (built from the
reference sheet by ``tools/build_sprites.py``). This module:

* loads every fighter / Stand view and its portrait,
* builds hue-shifted "spectral" Stand variants,
* caches scaled and rotated copies so per-frame squash/stretch is cheap,
* exposes :func:`compute_transform`, the single place where every animation
  curve (bobbing, squash, stretch, lean, hit recoil) is defined.

If the art is missing the caller falls back to the procedural skeleton in
``game/sprites.py``, so the game never breaks.
"""
from __future__ import annotations

import math
import os

import numpy as np
import pygame

from .config import GROUND_Y

CHAR_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                        "assets", "characters")

# fighter id -> stand id
STAND_FOR = {"jotaro": "star_platinum", "dio": "the_world"}
VIEWS = ("front", "side", "back")

# Target heights in game pixels (GROUND_Y=238 on a 480x270 canvas).
FIGHTER_H = 96
STAND_H = 104

# Spectral colours applied on top of the Stand art.
STAND_TINT = {
    "jotaro": (150, 96, 236),
    "dio": (255, 224, 132),
}

# Tint strength: The World needs more help to read apart from DIO's own gold.
STAND_TINT_STRENGTH = {"jotaro": 0.40, "dio": 0.55}

# Fallback hue rotation, used when only fighter art exists.
STAND_HUE = {"jotaro": 205.0, "dio": 62.0}

_CACHE_LIMIT = 900


# --------------------------------------------------------------------- helpers
def _rgb_to_hsv(arr: np.ndarray) -> np.ndarray:
    a = arr.astype(np.float32) / 255.0
    mx = a.max(axis=2)
    mn = a.min(axis=2)
    d = mx - mn
    h = np.zeros_like(mx)
    mask = d > 1e-6
    r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    idx = mask & (mx == r)
    h[idx] = ((g[idx] - b[idx]) / d[idx]) % 6.0
    idx = mask & (mx == g)
    h[idx] = (b[idx] - r[idx]) / d[idx] + 2.0
    idx = mask & (mx == b)
    h[idx] = (r[idx] - g[idx]) / d[idx] + 4.0
    h *= 60.0
    s = np.where(mx > 1e-6, d / np.maximum(mx, 1e-6), 0.0)
    return np.dstack([h, s, mx])


def _hsv_to_rgb(hsv: np.ndarray) -> np.ndarray:
    h, s, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
    c = v * s
    x = c * (1 - np.abs((h / 60.0) % 2 - 1))
    m = v - c
    z = np.zeros_like(h)
    out = np.zeros((h.shape[0], h.shape[1], 3), dtype=np.float32)
    zones = (h // 60).astype(np.int32) % 6
    choices = [
        (c, x, z), (x, c, z), (z, c, x),
        (z, x, c), (x, z, c), (c, z, x),
    ]
    for i, (rr, gg, bb) in enumerate(choices):
        sel = zones == i
        out[sel] = np.stack([rr[sel], gg[sel], bb[sel]], axis=1)
    return np.clip((out + m[:, :, None]) * 255.0, 0, 255).astype(np.uint8)


def hue_shift(surf: pygame.Surface, degrees: float, sat_mul: float = 1.0,
              val_mul: float = 1.0) -> pygame.Surface:
    """Rotate hue (and optionally tweak saturation/value), keeping alpha."""
    arr = pygame.surfarray.array3d(surf).transpose(1, 0, 2)  # -> (h, w, 3)
    alpha = pygame.surfarray.array_alpha(surf)               # (w, h)
    hsv = _rgb_to_hsv(arr)
    hsv[:, :, 0] = (hsv[:, :, 0] + degrees) % 360.0
    hsv[:, :, 1] = np.clip(hsv[:, :, 1] * sat_mul, 0.0, 1.0)
    hsv[:, :, 2] = np.clip(hsv[:, :, 2] * val_mul, 0.0, 1.0)
    rgb = _hsv_to_rgb(hsv)
    out = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    pygame.surfarray.blit_array(out, rgb.transpose(1, 0, 2))
    pygame.surfarray.pixels_alpha(out)[:, :] = alpha
    return out


def colorize(surf: pygame.Surface, color: tuple, strength: float = 0.45) -> pygame.Surface:
    """Tint a sprite toward ``color`` while preserving its shading and alpha.

    The tint is scaled by each pixel's own luminance, so outlines and shadows
    stay dark instead of washing the whole silhouette toward the target colour.
    """
    arr = pygame.surfarray.array3d(surf).astype(np.float32)  # (w, h, 3)
    alpha = pygame.surfarray.array_alpha(surf)
    luma = arr.mean(axis=2, keepdims=True) / 255.0
    target = np.array(color, dtype=np.float32)[None, None, :] / 255.0
    tint = target * np.clip(luma * 2.1, 0.0, 1.0)
    rgb = arr * (1.0 - strength) + tint * 255.0 * strength
    out = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    pygame.surfarray.blit_array(out, np.clip(rgb, 0, 255).astype(np.uint8))
    pygame.surfarray.pixels_alpha(out)[:, :] = alpha
    return out


def silhouette(surf: pygame.Surface, color: tuple) -> pygame.Surface:
    """Solid-colour copy of a sprite's shape (kept for effects/outlines)."""
    mask = pygame.mask.from_surface(surf)
    return mask.to_surface(setcolor=color, unsetcolor=(0, 0, 0, 0))


def _crop_portrait(front: pygame.Surface, size: int = 40) -> pygame.Surface:
    """Head-and-shoulders crop, matching tools/build_sprites.py."""
    w, h = front.get_size()
    side = min(w, max(8, int(h * 0.42)))
    head = front.subsurface(((w - side) // 2, 0, side, side)).copy()
    return pygame.transform.scale(head, (size, size))


# -------------------------------------------------------------------- library
class ArtLibrary:
    """Loads and caches every sprite, plus animated variants of it."""

    def __init__(self, directory: str = CHAR_DIR):
        self.dir = directory
        self.fighters: dict[str, dict[str, pygame.Surface]] = {}
        self.stands: dict[str, dict[str, pygame.Surface]] = {}
        self.portraits: dict[str, pygame.Surface] = {}
        self.stand_from_fighter: dict[str, bool] = {}
        self._cache: dict[tuple, pygame.Surface] = {}
        self.loaded = False

    def ensure_loaded(self) -> None:
        """Load after the display exists (convert_alpha needs a video mode)."""
        if self.loaded or pygame.display.get_surface() is None:
            return
        self.loaded = True
        self._load()

    # ------------------------------------------------------------------ load
    def _load_surface(self, name: str) -> pygame.Surface | None:
        path = os.path.join(self.dir, f"{name}.png")
        if not os.path.exists(path):
            return None
        try:
            surf = pygame.image.load(path).convert_alpha()
        except pygame.error:
            return None
        if surf.get_width() <= 2 or surf.get_height() <= 2:
            return None
        return surf

    @staticmethod
    def _normalize(surf: pygame.Surface, target_h: int) -> pygame.Surface:
        """Scale a raw import down to the game's fighter/Stand height."""
        if surf.get_height() <= target_h:
            return surf
        w, h = surf.get_size()
        scale = target_h / h
        small = pygame.transform.smoothscale(
            surf, (max(1, round(w * scale)), target_h))
        # Keep the silhouette hard so it still reads as pixel art.
        alpha = pygame.surfarray.pixels_alpha(small)
        alpha[:, :] = np.where(alpha >= 120, 255, 0).astype(np.uint8)
        del alpha
        return small

    def _load(self) -> None:
        for char in ("jotaro", "dio"):
            views = {}
            for view in VIEWS:
                surf = self._load_surface(f"{char}_{view}")
                if surf is not None:
                    views[view] = surf
            if not views:
                # User dropped a single file per character (assets/characters/jotaro.png).
                single = self._load_surface(char)
                if single is not None:
                    views = {v: single for v in VIEWS}
            if views:
                if char == "jotaro":
                    # lift the very dark coat so he reads against the night stage
                    views = {v: hue_shift(s, 0.0, 1.08, 1.16) for v, s in views.items()}
                self.fighters[char] = {
                    v: self._normalize(s, FIGHTER_H) for v, s in views.items()
                }

        for char, stand in STAND_FOR.items():
            views = {}
            for view in VIEWS:
                surf = self._load_surface(f"{stand}_{view}")
                if surf is not None:
                    views[view] = surf
            if not views:
                single = self._load_surface(stand)
                if single is not None:
                    views = {v: single for v in VIEWS}
            if views:
                # Dedicated Stand art exists: tint it for the spectral look.
                self.stands[char] = {
                    view: colorize(self._normalize(s, STAND_H),
                                   STAND_TINT[char], STAND_TINT_STRENGTH[char])
                    for view, s in views.items()
                }
                self.stand_from_fighter[char] = False
            elif char in self.fighters:
                # No Stand art: hue-shift the fighter's own sprite.
                self.stands[char] = {
                    view: hue_shift(s, STAND_HUE[char], 1.25, 1.05)
                    for view, s in self.fighters[char].items()
                }
                self.stand_from_fighter[char] = True

        for char in ("jotaro", "dio", "star_platinum", "the_world"):
            surf = self._load_surface(f"{char}_portrait")
            if surf is None:
                # Derive a portrait from the front sprite if none was built.
                front = self.fighters.get(char, {}).get("front") or \
                        self.stands.get(char, {}).get("front")
                if front is not None:
                    surf = _crop_portrait(front)
            if surf is not None:
                self.portraits[char] = surf

    # ------------------------------------------------------------------ query
    def has_fighter(self, char: str) -> bool:
        self.ensure_loaded()
        return char in self.fighters

    def has_stand(self, char: str) -> bool:
        self.ensure_loaded()
        return char in self.stands

    def fighter_surface(self, char: str, view: str = "side") -> pygame.Surface | None:
        self.ensure_loaded()
        views = self.fighters.get(char)
        if not views:
            return None
        return views.get(view) or next(iter(views.values()))

    def stand_surface(self, char: str, view: str = "side") -> pygame.Surface | None:
        self.ensure_loaded()
        views = self.stands.get(char)
        if not views:
            return None
        return views.get(view) or next(iter(views.values()))

    def portrait(self, char: str) -> pygame.Surface | None:
        self.ensure_loaded()
        return self.portraits.get(char)

    # ------------------------------------------------------------- transforms
    def _cached(self, key, build):
        surf = self._cache.get(key)
        if surf is None:
            surf = build()
            if len(self._cache) > _CACHE_LIMIT:
                self._cache.clear()
            self._cache[key] = surf
        return surf

    def framed(self, char: str, view: str, facing: int, sx: float, sy: float,
               angle: float = 0.0, stand: bool = False,
               alpha: int = 255) -> pygame.Surface | None:
        """Return the sprite scaled / rotated / flipped and ready to blit."""
        base = (self.stand_surface(char, view) if stand
                else self.fighter_surface(char, view))
        if base is None:
            return None

        sx = max(0.4, min(2.2, sx))
        sy = max(0.4, min(2.2, sy))
        w = max(1, int(round(base.get_width() * sx)))
        h = max(1, int(round(base.get_height() * sy)))
        a = int(round(angle / 2.0)) * 2
        key = (char, view, facing, w, h, a, stand, alpha)

        def build():
            surf = pygame.transform.scale(base, (w, h))
            if facing < 0:
                surf = pygame.transform.flip(surf, True, False)
            if a:
                surf = pygame.transform.rotate(surf, a)
            if alpha < 255:
                surf = surf.copy()
                surf.set_alpha(alpha)
            return surf

        return self._cached(key, build)

    def glow(self, color: tuple, rx: int = 34, ry: int = 50,
             alpha: int = 26) -> pygame.Surface:
        """Soft cached backlight so dark sprites read against the night stage."""
        key = ("glow", color, rx, ry, alpha)
        surf = self._cache.get(key)
        if surf is None:
            w, h = rx * 2, ry * 2
            yy, xx = np.mgrid[0:h, 0:w]
            d = ((xx - rx) / rx) ** 2 + ((yy - ry) / ry) ** 2
            a = (np.clip(1.0 - d, 0.0, 1.0) ** 2 * alpha).astype(np.uint8)
            surf = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.surfarray.blit_array(
                surf, np.full((w, h, 3), color, dtype=np.uint8))
            pygame.surfarray.pixels_alpha(surf)[:, :] = a.T
            if len(self._cache) > _CACHE_LIMIT:
                self._cache.clear()
            self._cache[key] = surf
        return surf


# ------------------------------------------------------------------ singleton
ART = ArtLibrary()


# --------------------------------------------------------------- animation
def _ease_out(x: float) -> float:
    x = max(0.0, min(1.0, x))
    return 1 - (1 - x) * (1 - x)


def attack_curve(move, move_t: float) -> float:
    """0 at rest, rising to 1 at the active frames, easing back down."""
    if move is None:
        return 0.0
    if move_t < move.startup:
        return 0.35 * (move_t / max(1e-4, move.startup))
    if move_t < move.startup + move.active:
        return 1.0
    rem = (move_t - move.startup - move.active) / max(1e-4, move.recovery)
    return max(0.0, 1.0 - _ease_out(rem))


def compute_transform(f, t: float) -> dict:
    """Every procedural animation in one place.

    Returns ``sx, sy`` (squash/stretch), ``angle`` (degrees), ``dx, dy``
    (pixel offset from the anchor) and ``alpha``.
    """
    out = {"sx": 1.0, "sy": 1.0, "angle": 0.0, "dx": 0.0, "dy": 0.0, "alpha": 255}
    facing = f.facing
    state = f.state
    breathe = math.sin(t * 2.4 + f.anim_t * 0.7)

    if state == "ko":
        # topple away from the attacker, settle on the ground
        k = _ease_out(min(1.0, f.ko_timer / 0.55))
        out["angle"] = -72 * k * facing
        out["dy"] = 10 * k
        out["sx"] = 1.0 + 0.06 * k
        out["sy"] = 1.0 - 0.06 * k
        return out

    if state == "hurt":
        # short, snappy recoil: rotate back and slide away
        k = max(0.0, min(1.0, f.hurt_t / 0.22))
        shake = math.sin(f.anim_t * 70) * 0.5 * k
        out["angle"] = -9 * k * facing
        out["dx"] = -5 * k * facing + shake
        out["dy"] = -1.5 * k
        out["sx"] = 1.0 + 0.05 * k
        out["sy"] = 1.0 - 0.04 * k
        return out

    if not f.on_ground or state == "jump":
        # stretch going up, squash on the way down
        rising = f.vy < 0
        k = min(1.0, abs(f.vy) / 330.0)
        out["sx"] = 1.0 - 0.07 * k
        out["sy"] = 1.0 + 0.09 * k
        out["angle"] = -3 * facing * (1 if rising else -1)
        return out

    if state == "crouch":
        out["sx"] = 1.10
        out["sy"] = 0.80
        out["dy"] = 1.0
        return out

    if state == "block":
        out["sx"] = 1.04
        out["sy"] = 0.97
        out["dx"] = -1.2 * facing
        out["angle"] = -1.5 * facing
        return out

    if state == "heal":
        # slow sway while smoking / drinking
        out["dy"] = math.sin(t * 2.0) * 0.8
        out["angle"] = math.sin(t * 1.6) * 1.2 * facing
        out["sx"] = 1.0 + 0.012 * breathe
        out["sy"] = 1.0 - 0.012 * breathe
        return out

    if state == "attack" and f.move is not None:
        m = f.move
        ext = attack_curve(m, f.move_t)
        key = m.key
        if key in ("ora", "muda"):
            # rapid punch flurry: fast horizontal squash + micro shake
            jitter = math.sin(f.move_t * 62.0)
            out["sx"] = 1.0 + 0.055 * ext + 0.015 * jitter
            out["sy"] = 1.0 - 0.030 * ext
            out["dx"] = (2.5 * ext + 0.8 * jitter) * facing
            out["angle"] = 1.2 * ext * facing
        elif key in ("jab", "punch"):
            out["sx"] = 1.0 + 0.10 * ext
            out["sy"] = 1.0 - 0.06 * ext
            out["dx"] = 3.0 * ext * facing
            out["angle"] = 1.6 * ext * facing
        elif key == "kick":
            out["sx"] = 1.0 + 0.07 * ext
            out["sy"] = 1.0 - 0.05 * ext
            out["dx"] = 2.0 * ext * facing
            out["angle"] = -2.4 * ext * facing
        elif key in ("ora_kick", "muda_kick"):
            out["sx"] = 1.0 + 0.09 * ext
            out["sy"] = 1.0 - 0.07 * ext
            out["dx"] = 4.5 * ext * facing
            out["angle"] = -4.0 * ext * facing
        elif key == "star_finger":
            out["sx"] = 1.0 + 0.05 * ext
            out["sy"] = 1.0 - 0.03 * ext
            out["dx"] = 2.0 * ext * facing
            out["angle"] = 1.0 * ext * facing
        elif key == "road_roller":
            windup = min(1.0, f.move_t / max(0.01, m.startup))
            out["sx"] = 1.0 - 0.03 * windup
            out["sy"] = 1.0 + 0.05 * windup
            out["angle"] = -3.0 * windup * facing
            out["dx"] = -2.0 * windup * facing
        return out

    if f.ult_pose > 0:
        # arms-up pose during the summon; subtle pulse
        out["sy"] = 1.0 + 0.03 * math.sin(t * 9)
        out["dx"] = -1.5 * facing
        return out

    if f.summon_pose > 0:
        out["dy"] = -1.5
        out["sx"] = 1.02
        out["sy"] = 1.02
        return out

    if state == "walk":
        phase = f.anim_t * 9.0
        out["dy"] = -abs(math.sin(phase)) * 2.6
        out["sx"] = 1.0 + 0.022 * math.sin(phase * 2)
        out["sy"] = 1.0 - 0.022 * math.sin(phase * 2)
        out["angle"] = 1.6 * facing + math.sin(phase) * 2.0
        out["dx"] = math.sin(phase) * 0.8 * facing
        return out

    # idle breathing
    out["dy"] = breathe * 1.8
    out["sx"] = 1.0 + 0.016 * breathe
    out["sy"] = 1.0 - 0.014 * breathe
    out["angle"] = 0.6 * facing + breathe * 0.7
    return out


def stand_transform(f, t: float) -> dict:
    """The Stand floats behind, breathes slower and drifts sideways."""
    out = {"sx": 1.0, "sy": 1.0, "angle": 0.0, "dx": 0.0, "dy": 0.0, "alpha": 235}
    facing = f.facing
    bob = math.sin(t * 1.9 + 1.1)
    sway = math.sin(t * 1.3 + 0.4)

    out["dx"] = -34.0 * facing + sway * 1.6
    out["dy"] = -4.0 + bob * 2.2
    out["sx"] = 1.10 + 0.015 * bob
    out["sy"] = 1.10 - 0.015 * bob
    out["angle"] = 1.0 * facing + sway * 0.8

    if f.state == "attack" and f.move is not None:
        m = f.move
        ext = attack_curve(m, f.move_t)
        if m.key in ("ora", "muda"):
            # lunge from behind the user to in front of them, toward the target
            jitter = math.sin(f.move_t * 62.0)
            out["dx"] = (-34.0 + 66.0 * ext) * facing + jitter * 1.4
            out["sx"] = 1.10 + 0.10 * ext
            out["sy"] = 1.10 - 0.03 * ext
            out["angle"] = 1.0 * facing - 3.0 * ext * facing
        elif m.key in ("ora_kick", "muda_kick"):
            out["dx"] = (-34.0 + 62.0 * ext) * facing
            out["sx"] = 1.10 + 0.09 * ext
            out["angle"] = -4.0 * ext * facing
        elif m.key == "star_finger":
            out["dx"] = (-30.0 + 54.0 * ext) * facing
            out["sx"] = 1.10 + 0.05 * ext
            out["angle"] = 1.0 * facing
        elif m.key == "road_roller":
            windup = min(1.0, f.move_t / max(0.01, m.startup))
            out["dy"] = -4.0 - 10.0 * windup
            out["dx"] = (-34.0 + 26.0 * windup) * facing
            out["angle"] = 3.0 * windup * facing
    if f.ult_pose > 0 or f.state == "timestop":
        out["dx"] = -44.0 * facing
        out["dy"] = -12.0 + bob * 1.4
        out["sx"] = 1.16
        out["sy"] = 1.16
        out["angle"] = 0.0
    if f.stand_flash > 0:
        out["sx"] *= 1.0 + 0.10 * (f.stand_flash / 0.28)
        out["sy"] *= 1.0 + 0.10 * (f.stand_flash / 0.28)
    out["alpha"] = int(255 * max(0.0, min(1.0, f.stand_alpha)) * 0.95)
    return out


def draw_star_finger_beam(surface, f, t: float) -> None:
    """Pixel-art Star Finger: a glowing telescoping finger that reaches far."""
    if f.state != "attack" or f.move is None or f.move.key != "star_finger":
        return
    m = f.move
    grow = max(0.0, min(1.0, (f.move_t - m.startup * 0.7) / 0.12))
    if grow <= 0:
        return
    facing = f.facing
    accent = STAND_TINT[f.character] if f.character == "jotaro" else (140, 240, 255)
    core = (232, 252, 255)

    x0 = f.x + 16 * facing
    y0 = f.feet_y - 66
    length = (m.reach + 14) * grow
    x1 = x0 + length * facing

    left = int(min(x0, x1)) - 6
    width = int(abs(x1 - x0)) + 12
    layer = pygame.Surface((max(4, width), 22), pygame.SRCALPHA)
    lx = 6 if facing > 0 else width - 6
    ex = lx + (x1 - x0)

    # outer glow -> coloured shaft -> bright core
    pygame.draw.line(layer, (*accent, 70), (lx, 11), (ex, 11), 11)
    pygame.draw.line(layer, (*accent, 170), (lx, 11), (ex, 11), 5)
    pygame.draw.line(layer, (*core, 235), (lx, 11), (ex, 11), 2)
    surface.blit(layer, (left, int(y0) - 11))

    # knuckle segments marching outward
    steps = 5
    for i in range(1, steps + 1):
        kx = x0 + (x1 - x0) * i / steps
        size = 3 if i % 2 else 2
        surface.fill(accent, (int(kx) - size // 2, int(y0) - size // 2, size, size))
    # fingertip burst
    tip = (int(x1), int(y0))
    pygame.draw.circle(surface, accent, tip, 4, 1)
    pygame.draw.circle(surface, core, tip, 2)


# --------------------------------------------------------------------- draw
def draw_sprite_fighter(surface, f, t: float) -> bool:
    """Draw a fighter using the imported art. False if art is unavailable."""
    if not ART.has_fighter(f.character):
        return False
    tr = compute_transform(f, t)
    view = "side" if "side" in ART.fighters[f.character] else "front"
    img = ART.framed(f.character, view, f.facing, tr["sx"], tr["sy"],
                     tr["angle"], stand=False, alpha=tr["alpha"])
    if img is None:
        return False

    x = f.x + tr["dx"]
    y = f.feet_y + tr["dy"]
    rect = img.get_rect(midbottom=(int(round(x)), int(round(y))))

    # short afterimage trail makes one-frame attack poses read as motion
    if f.state == "attack" and f.move is not None:
        ext = attack_curve(f.move, f.move_t)
        if ext > 0.45:
            ghost = ART.framed(f.character, view, f.facing, tr["sx"] * 0.99,
                               tr["sy"] * 0.99, tr["angle"], stand=False, alpha=64)
            if ghost is not None:
                gx = int(round(x - 7 * f.facing))
                surface.blit(ghost, ghost.get_rect(midbottom=(gx, int(round(y)))))

    glow = ART.glow(f.cfg["accent"], 28, 44, 16)
    surface.blit(glow, glow.get_rect(center=(int(f.x), int(f.feet_y - 46))))
    surface.blit(img, rect)

    if f.hit_flash > 0:
        white = ART.framed(f.character, view, f.facing, tr["sx"], tr["sy"],
                           tr["angle"], stand=False, alpha=255)
        if white is not None:
            flash = colorize(white, (255, 250, 235), 0.35)
            flash.set_alpha(int(70 * (f.hit_flash / 0.14)))
            surface.blit(flash, rect)
    return True


def draw_sprite_stand(surface, f, t: float) -> bool:
    if not ART.has_stand(f.character) or f.stand_alpha <= 0:
        return False
    tr = stand_transform(f, t)
    view = "side" if "side" in ART.stands[f.character] else "front"
    img = ART.framed(f.character, view, f.facing, tr["sx"], tr["sy"],
                     tr["angle"], stand=True, alpha=tr["alpha"])
    if img is None:
        return False

    # ORA/MUDA flurry: two low-alpha copies read as a blur of fists
    if f.state == "attack" and f.move is not None and f.move.key in ("ora", "muda"):
        for off, a in ((16, 58), (8, 92)):
            ghost = ART.framed(f.character, view, f.facing, tr["sx"] * 0.98,
                               tr["sy"] * 0.98, tr["angle"], stand=True, alpha=a)
            if ghost is not None:
                gx = int(round(f.x + tr["dx"] - off * f.facing))
                surface.blit(ghost, ghost.get_rect(midbottom=(gx, int(round(f.feet_y + tr["dy"])))))

    rect = img.get_rect(midbottom=(int(round(f.x + tr["dx"])),
                                   int(round(f.feet_y + tr["dy"]))))
    glow = ART.glow(STAND_TINT[f.character], 40, 56, 30)
    surface.blit(glow, glow.get_rect(center=(int(f.x + tr["dx"]),
                                             int(f.feet_y - 56))))

    # spectral rim: a 1px halo so the Stand reads as "summoned", not standing
    rim = ART.framed(f.character, view, f.facing, tr["sx"] * 1.04,
                     tr["sy"] * 1.04, tr["angle"], stand=True, alpha=70)
    if rim is not None:
        rim_rect = rim.get_rect(midbottom=(int(round(f.x + tr["dx"])),
                                           int(round(f.feet_y + tr["dy"]))))
        surface.blit(colorize(rim, STAND_TINT[f.character], 0.85), rim_rect)

    surface.blit(img, rect)
    draw_star_finger_beam(surface, f, t)
    return True
