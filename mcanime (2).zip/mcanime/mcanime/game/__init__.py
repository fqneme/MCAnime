"""STAND BATTLE: STARDUST SHOWDOWN - a tiny JoJo-inspired pixel fighter."""
