"""Audio manager: CC0 samples, runtime pitch variants, music and voice cues."""
from __future__ import annotations

import glob
import os
import random

import numpy as np
import pygame

from .config import DEFAULT_SETTINGS

AUDIO_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "audio")


def _resample(arr: np.ndarray, speed: float) -> np.ndarray:
    n = max(1, int(len(arr) / speed))
    src = np.linspace(0.0, len(arr) - 1, n)
    return np.interp(src, np.arange(len(arr)), arr).astype(np.int16)


def _make_sound(arr: np.ndarray) -> pygame.mixer.Sound:
    """Build a Sound that matches the mixer's channel count."""
    init = pygame.mixer.get_init()
    if init and init[2] == 2 and arr.ndim == 1:
        arr = np.column_stack([arr, arr])
    return pygame.sndarray.make_sound(arr)


class AudioManager:
    def __init__(self, settings: dict | None = None):
        self.settings = dict(DEFAULT_SETTINGS)
        if settings:
            self.settings.update(settings)
        self.sounds: dict[str, pygame.mixer.Sound] = {}
        self.variants: dict[str, list[pygame.mixer.Sound]] = {}
        self.music_name: str | None = None
        self.music_duck = 1.0
        self.ok = False
        try:
            # Re-init the mixer as mono so runtime pitch-shifting is cheap and
            # array shapes are predictable.
            if pygame.mixer.get_init():
                pygame.mixer.quit()
            pygame.mixer.init(44100, -16, 1, 512)
            pygame.mixer.set_num_channels(32)
            self.voice_channel = pygame.mixer.Channel(0)
            self.ult_channel = pygame.mixer.Channel(1)
            self.ok = True
        except pygame.error:
            return
        self._load()

    # ------------------------------------------------------------------ load
    def _load(self) -> None:
        for path in glob.glob(os.path.join(AUDIO_DIR, "*.ogg")):
            name = os.path.splitext(os.path.basename(path))[0]
            try:
                self.sounds[name] = pygame.mixer.Sound(path)
            except pygame.error:
                pass
        for path in glob.glob(os.path.join(AUDIO_DIR, "voice_*.wav")):
            name = os.path.splitext(os.path.basename(path))[0]
            try:
                self.sounds[name] = pygame.mixer.Sound(path)
            except pygame.error:
                pass

        # Small family of pitched impacts so repeated hits never sound cloned.
        # Files are named e.g. punch_light_1.ogg / punch_light_2.ogg, so group
        # them under one logical sound name.
        families = {
            "punch_light": (0.90, 1.0, 1.10),
            "punch_heavy": (0.88, 1.0, 1.12),
            "kick_medium": (0.92, 1.0, 1.08),
            "kick_heavy": (0.90, 1.0, 1.10),
            "whoosh": (0.88, 1.0, 1.12),
            "step": (0.94, 1.04),
            "roller_impact": (0.92, 1.0, 1.08),
            "ui_click": (0.95, 1.05),
            "metal_clang": (0.72, 0.82),
        }
        for name, ratios in families.items():
            group = [
                snd for key, snd in self.sounds.items()
                if key == name or (key.startswith(name + "_") and key[len(name) + 1:].isdigit())
            ]
            if not group:
                continue
            self.sounds[name] = group[0]
            bucket = list(group)
            try:
                arr = pygame.sndarray.array(group[0]).astype(np.int16)
                if arr.ndim > 1:
                    arr = arr[:, 0]
                for r in ratios:
                    if abs(r - 1.0) < 0.001:
                        continue
                    bucket.append(_make_sound(_resample(arr, r)))
            except (pygame.error, ValueError):
                pass
            self.variants[name] = bucket

    # ------------------------------------------------------------------ play
    def play(self, name: str, volume: float = 1.0, vary: bool = True) -> None:
        if not self.ok:
            return
        bucket = self.variants.get(name)
        snd = random.choice(bucket) if (bucket and vary) else self.sounds.get(name)
        if snd is None:
            return
        snd.set_volume(max(0.0, min(1.0, volume * self.settings["sfx"])))
        snd.play()

    def voice(self, key: str, volume: float = 1.0) -> None:
        if not self.ok:
            return
        snd = self.sounds.get(f"voice_{key}")
        if snd is None:
            return
        self.voice_channel.stop()
        snd.set_volume(max(0.0, min(1.0, volume * self.settings["sfx"])))
        self.voice_channel.play(snd)

    def ultimate_voice(self, key: str, volume: float = 1.0) -> None:
        if not self.ok:
            return
        snd = self.sounds.get(f"voice_{key}")
        if snd is None:
            return
        self.ult_channel.stop()
        snd.set_volume(max(0.0, min(1.0, volume * self.settings["sfx"])))
        self.ult_channel.play(snd)

    # ----------------------------------------------------------------- music
    def music(self, name: str | None, fade_ms: int = 600) -> None:
        if not self.ok:
            return
        if name == self.music_name:
            return
        self.music_name = name
        try:
            pygame.mixer.music.fadeout(250)
            if name:
                path = os.path.join(AUDIO_DIR, f"{name}.ogg")
                if os.path.exists(path):
                    pygame.mixer.music.load(path)
                    pygame.mixer.music.set_volume(
                        max(0.0, min(1.0, self.settings["music"] * self.music_duck))
                    )
                    pygame.mixer.music.play(-1, fade_ms=fade_ms)
        except pygame.error:
            pass

    def set_duck(self, duck: float) -> None:
        self.music_duck = duck
        if self.ok:
            try:
                pygame.mixer.music.set_volume(
                    max(0.0, min(1.0, self.settings["music"] * self.music_duck))
                )
            except pygame.error:
                pass

    def apply_volumes(self) -> None:
        self.set_duck(self.music_duck)

    def stop_music(self) -> None:
        self.music_name = None
        if self.ok:
            pygame.mixer.music.fadeout(300)

    def stop_all(self) -> None:
        if self.ok:
            pygame.mixer.stop()
            self.voice_channel.stop()
            self.ult_channel.stop()
