"""Application shell: window, fixed canvas scaling, settings and main loop."""
from __future__ import annotations

import json
import os

import pygame

from .audio import AudioManager
from .art import ART
from .config import (
    DEFAULT_SETTINGS, DIFFICULTIES, FPS, GAME_H, GAME_W, TITLE,
)
from .screens import MenuScreen
from .sprites import draw_portrait
from .stage import Stage

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
SETTINGS_PATH = os.environ.get(
    "MCANIME_SETTINGS", os.path.join(BASE_DIR, "settings.json")
)


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(TITLE)
        self.settings = self._load_settings()
        self.windowed_size = self._best_window_size()
        self.window = None
        self._apply_display()
        icon = pygame.Surface((32, 32), pygame.SRCALPHA)
        draw_portrait(icon, "jotaro", 0, 0, 2, bg=(20, 16, 28))
        pygame.display.set_icon(icon)
        ART.ensure_loaded()
        self.canvas = pygame.Surface((GAME_W, GAME_H)).convert()
        self.audio = AudioManager(self.settings)
        self.stage = Stage()
        self.clock = pygame.time.Clock()
        self.running = True
        self.last_character = "jotaro"
        self.screen = MenuScreen(self)

    # ------------------------------------------------------------------ setup
    def _load_settings(self):
        s = dict(DEFAULT_SETTINGS)
        try:
            with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                s.update(data)
        except (OSError, ValueError):
            pass
        if s.get("difficulty") not in DIFFICULTIES:
            s["difficulty"] = "NORMAL"
        for key in ("music", "sfx"):
            try:
                s[key] = max(0.0, min(1.0, float(s[key])))
            except (TypeError, ValueError):
                s[key] = DEFAULT_SETTINGS[key]
        return s

    def save_settings(self):
        try:
            with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=2)
        except OSError:
            pass

    def _best_window_size(self):
        try:
            info = pygame.display.Info()
            max_w = max(640, info.current_w - 80)
            max_h = max(360, info.current_h - 120)
            scale = min(max_w // GAME_W, max_h // GAME_H, 3)
            scale = max(1, scale)
            return GAME_W * scale, GAME_H * scale
        except pygame.error:
            return GAME_W * 3, GAME_H * 3

    def _apply_display(self):
        try:
            if self.settings.get("fullscreen"):
                self.window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            else:
                self.window = pygame.display.set_mode(self.windowed_size, pygame.RESIZABLE)
        except pygame.error:
            self.settings["fullscreen"] = False
            self.window = pygame.display.set_mode(self.windowed_size, pygame.RESIZABLE)

    def apply_display(self):
        self._apply_display()

    # ------------------------------------------------------------------ loop
    def set_screen(self, screen):
        self.screen = screen

    def quit(self):
        self.running = False

    def mouse_pos(self):
        w, h = self.window.get_size()
        scale = max(1, min(w // GAME_W, h // GAME_H))
        dw, dh = GAME_W * scale, GAME_H * scale
        ox, oy = (w - dw) // 2, (h - dh) // 2
        mx, my = pygame.mouse.get_pos()
        if ox <= mx < ox + dw and oy <= my < oy + dh:
            return ((mx - ox) // scale, (my - oy) // scale)
        return None

    def run(self):
        while self.running:
            dt = self.clock.tick(FPS) / 1000.0
            dt = min(dt, 0.05)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.VIDEORESIZE and not self.settings.get("fullscreen"):
                    self.windowed_size = (max(480, event.w), max(270, event.h))
                    self.window = pygame.display.set_mode(self.windowed_size, pygame.RESIZABLE)
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                    self.settings["fullscreen"] = not self.settings.get("fullscreen")
                    self.apply_display()
                    self.save_settings()
                else:
                    self.screen.handle_event(event)

            self.screen.update(dt)
            self.screen.draw(self.canvas)
            self._present()
            pygame.display.flip()
        self.save_settings()
        pygame.quit()

    def _present(self):
        w, h = self.window.get_size()
        scale = max(1, min(w // GAME_W, h // GAME_H))
        dw, dh = GAME_W * scale, GAME_H * scale
        scaled = pygame.transform.scale(self.canvas, (dw, dh))
        self.window.fill((0, 0, 0))
        self.window.blit(scaled, ((w - dw) // 2, (h - dh) // 2))
