"""Fighter state machine: movement, attacks, Stand toggle, heals and damage."""
from __future__ import annotations

import math
import random

import pygame

from .config import CHARACTERS, GROUND_Y
from .moves import Move, get_move

GRAVITY = 980.0
JUMP_V = -330.0
WALK_SPEED = 104.0
MAX_ULT = 100.0
ULT_RATE = 2.6


class Fighter:
    def __init__(self, character: str, x: float, facing: int = 1, is_ai: bool = False):
        self.character = character
        self.cfg = CHARACTERS[character]
        self.is_ai = is_ai
        self.x = float(x)
        self.facing = facing
        self.jump_y = 0.0
        self.vy = 0.0
        self.on_ground = True

        self.hp = 100.0
        self.max_hp = 100.0
        self.ult = 12.0 if not is_ai else 0.0
        self.max_ult = MAX_ULT

        self.state = "idle"
        self.anim_t = 0.0
        self.move: Move | None = None
        self.move_t = 0.0
        self.hit_done: set[int] = set()
        self.roller_spawned = False
        self.cooldowns: dict[str, float] = {}
        self.hurt_t = 0.0
        self.ko_timer = 0.0
        self.hit_flash = 0.0

        self.stand_active = False
        self.stand_alpha = 0.0
        self.stand_flash = 0.0
        self.summon_pose = 0.0
        self.ult_pose = 0.0

        self.blocking = False
        self.crouching = False
        self.input_x = 0
        self.input_crouch = False
        self.input_block = False
        self.jump_requested = False
        self.vx = 0.0

        self.heal_left = 0.0
        self.heal_rate = 0.0
        self.heal_accum = 0.0
        self.heal_done = False
        self.smoke_t = 0.0
        self.step_t = 0.0
        self.walked = 0.0
        self.rush_t = 0.0
        self.grunt_cd = 0.0
        self.last_hit_from: Fighter | None = None

        self.ai = None

    # ------------------------------------------------------------------ misc
    @property
    def name(self):
        return self.cfg["name"]

    @property
    def feet_y(self):
        return GROUND_Y - self.jump_y

    def can_act(self) -> bool:
        return self.state in ("idle", "walk", "crouch", "block") and self.on_ground

    def is_busy(self) -> bool:
        return self.state in ("attack", "heal", "hurt", "ko")

    def cooldown(self, key: str) -> float:
        return max(0.0, self.cooldowns.get(key, 0.0))

    def action_ready_special(self) -> bool:
        move = get_move(self.character, self.stand_active, "c")
        if move is None or move.special in ("heal", "heal_instant"):
            return False
        return self.cooldown(move.key) <= 0

    def hurtbox(self) -> pygame.Rect:
        height = 60 if self.crouching else 84
        return pygame.Rect(int(self.x - 12), int(self.feet_y - height), 24, height)

    def hitbox(self, move: Move) -> pygame.Rect:
        x1 = self.x + 6 * self.facing
        x2 = self.x + (move.reach + 6) * self.facing
        left = min(x1, x2)
        width = abs(x2 - x1)
        top = self.feet_y - move.hit_high
        bottom = self.feet_y - move.hit_low
        return pygame.Rect(int(left), int(top), max(4, int(width)), max(4, int(bottom - top)))

    def chest(self):
        return (self.x, self.feet_y - 58)

    # ------------------------------------------------------------------ actions
    def face(self, opponent: "Fighter"):
        if opponent.x > self.x + 1:
            self.facing = 1
        elif opponent.x < self.x - 1:
            self.facing = -1

    def try_attack(self, slot: str, game) -> bool:
        if not self.can_act():
            return False
        move = get_move(self.character, self.stand_active, slot)
        if move is None:
            return False
        if self.cooldown(move.key) > 0:
            return False
        if move.special in ("heal", "heal_instant") and self.hp >= self.max_hp - 0.5:
            return False
        self.face(game.opponent_of(self))
        self.move = move
        self.move_t = 0.0
        self.hit_done = set()
        self.roller_spawned = False
        self.rush_t = 0.0
        self.cooldowns[move.key] = move.cooldown
        self.state = "heal" if move.special in ("heal", "heal_instant") else "attack"
        self.blocking = False
        self.crouching = False
        if move.lunge:
            self.vx += move.lunge * self.facing
        if move.special == "heal":
            self.heal_left = move.heal_total
            self.heal_rate = move.heal_total / max(0.1, move.heal_duration)
            self.heal_accum = 0.0
            self.heal_done = False
            game.audio.voice("heal_jotaro", 0.9)
            game.audio.play("whoosh", 0.35)
        elif move.special == "heal_instant":
            self.heal_left = move.heal_total
            self.heal_rate = 0.0
            self.heal_accum = 0.0
            self.heal_done = False
            game.audio.voice("heal_dio", 0.95)
            game.audio.play("whoosh", 0.3)
        else:
            if move.voice:
                game.audio.voice(move.voice, 0.9 if "muda" not in move.voice else 1.0)
            game.audio.play("whoosh", 0.35)
            if move.special == "roller":
                game.audio.play("metal_clang", 0.35)
            game.effects.add_speed_lines(
                self.x + 20 * self.facing, self.feet_y - 62,
                self.facing, (230, 220, 255), count=4, spread=26,
            )
        return True

    def try_toggle_stand(self, game) -> bool:
        if not self.can_act():
            return False
        if self.stand_flash > 0:
            return False
        self.stand_active = not self.stand_active
        self.stand_flash = 0.28
        self.summon_pose = 0.45 if self.stand_active else 0.0
        self.blocking = False
        game.audio.play("whoosh", 0.7)
        game.audio.play("metal_clang", 0.25)
        game.effects.add_ring(self.x, self.feet_y - 46,
                              (170, 120, 255) if self.character == "jotaro" else (255, 208, 100),
                              radius=8, speed=170, life=0.35, width=2)
        game.effects.add_dust(self.x, self.feet_y - 2, 8,
                              (170, 130, 210) if self.character == "jotaro" else (230, 190, 110))
        game.effects.add_text(self.x, self.feet_y - 100,
                              "STAND ON" if self.stand_active else "STAND OFF",
                              (200, 170, 255) if self.character == "jotaro" else (255, 220, 120),
                              scale=1, life=0.7)
        return True

    def try_ult(self, game) -> bool:
        if not self.can_act() or not self.stand_active:
            return False
        if self.ult < self.max_ult - 0.01:
            return False
        self.ult = 0.0
        self.ult_pose = 1.2
        game.start_time_stop(self)
        return True

    def jump(self, game):
        if self.on_ground and self.can_act():
            self.vy = JUMP_V
            self.on_ground = False
            self.state = "jump"
            game.audio.play("whoosh", 0.25)

    # ------------------------------------------------------------------ update
    def update(self, dt: float, opponent: "Fighter", game, frozen: bool = False):
        self.anim_t += dt
        self.hit_flash = max(0.0, self.hit_flash - dt)
        self.stand_flash = max(0.0, self.stand_flash - dt)
        self.grunt_cd = max(0.0, self.grunt_cd - dt)
        self.summon_pose = max(0.0, self.summon_pose - dt)
        self.ult_pose = max(0.0, self.ult_pose - dt)
        for k in list(self.cooldowns):
            self.cooldowns[k] = max(0.0, self.cooldowns[k] - dt)

        target_alpha = 1.0 if self.stand_active else 0.0
        if self.stand_alpha < target_alpha:
            self.stand_alpha = min(1.0, self.stand_alpha + dt * 4.5)
        elif self.stand_alpha > target_alpha:
            self.stand_alpha = max(0.0, self.stand_alpha - dt * 5.0)

        if frozen:
            return

        if self.state != "ko":
            rate = 1.0
            if self.is_ai:
                rate = 0.7
            self.ult = min(self.max_ult, self.ult + ULT_RATE * rate * dt)

        if self.state == "ko":
            self.ko_timer += dt
            self.vx *= 0.90
            self.x += self.vx * dt
            self._clamp_x()
            self._physics(dt)
            return

        if self.state == "hurt":
            self.hurt_t -= dt
            self.vx *= 0.86
            self.x += self.vx * dt
            self._clamp_x()
            if self.hurt_t <= 0 and self.on_ground:
                self.state = "idle"
            self._physics(dt)
            return

        if self.state == "heal":
            self._update_heal(dt, game)
            self._physics(dt)
            return

        if self.state == "attack":
            self._update_attack(dt, opponent, game)
            self._physics(dt)
            return

        # free movement
        if self.on_ground:
            self.face(opponent)
            self.blocking = False
            self.crouching = False
            if self.input_block:
                self.state = "block"
                self.blocking = True
                self.crouching = self.input_crouch
                self.vx *= 0.8
            elif self.input_crouch:
                self.state = "crouch"
                self.crouching = True
            elif self.input_x:
                self.state = "walk"
                self.x += self.input_x * WALK_SPEED * dt
                self.walked += abs(self.input_x * WALK_SPEED * dt)
                self.step_t -= dt
                if self.step_t <= 0:
                    self.step_t = 0.27
                    game.audio.play("step", 0.22)
            else:
                self.state = "idle"
            if self.jump_requested:
                self.jump(game)
        else:
            self.state = "jump"
            self.x += self.input_x * WALK_SPEED * 0.72 * dt
            self.crouching = False
            self.blocking = False

        self.jump_requested = False
        self.vx *= 0.82
        self.x += self.vx * dt
        self._clamp_x()
        self._physics(dt)

    def _physics(self, dt: float):
        if not self.on_ground:
            self.vy += GRAVITY * dt
            self.jump_y -= self.vy * dt
            if self.jump_y <= 0:
                self.jump_y = 0.0
                self.vy = 0.0
                self.on_ground = True
                if self.state == "jump":
                    self.state = "idle"

    def _clamp_x(self):
        self.x = max(26.0, min(454.0, self.x))

    def _update_attack(self, dt: float, opponent: "Fighter", game):
        if self.move is None:
            self.state = "idle"
            return
        m = self.move
        prev = self.move_t
        self.move_t += dt
        if m.key in ("ora", "muda") and self.move_t < m.startup + m.active:
            self.rush_t -= dt
            if self.rush_t <= 0:
                self.rush_t = 0.15
                word = "ORA!" if m.key == "ora" else "MUDA!"
                col = (150, 230, 255) if m.key == "ora" else (255, 218, 120)
                game.effects.add_text(
                    self.x + (28 + random.uniform(-6, 14)) * self.facing,
                    self.feet_y - 96 + random.uniform(-6, 6), word, col,
                    scale=1, life=0.38, vy=-26,
                )
        for i, ht in enumerate(m.hit_times):
            if i not in self.hit_done and prev < ht <= self.move_t:
                self.hit_done.add(i)
                game.try_hit(self, opponent, m)
        if m.special == "roller" and not self.roller_spawned and self.move_t >= m.startup * 0.9:
            self.roller_spawned = True
            game.spawn_roller(self, m)
        if self.move_t >= m.duration:
            self.state = "idle"
            self.move = None
            self.move_t = 0.0
            self.hit_done = set()

    def _update_heal(self, dt: float, game):
        if self.move is None:
            self.state = "idle"
            return
        m = self.move
        self.move_t += dt
        if m.special == "heal":
            if self.heal_left > 0:
                amount = min(self.heal_left, self.heal_rate * dt)
                self.heal_left -= amount
                self.hp = min(self.max_hp, self.hp + amount)
                self.heal_accum += amount
                if self.heal_accum >= 2.0:
                    self.heal_accum = 0.0
                    game.effects.add_text(self.x, self.feet_y - 92, "+2",
                                          (130, 255, 150), scale=1, life=0.5)
            self.smoke_t -= dt
            if self.smoke_t <= 0:
                self.smoke_t = 0.11
                game.effects.add_smoke(self.x + 6 * self.facing, self.feet_y - 78,
                                       (210, 210, 220), count=1)
        else:
            if not self.heal_done and self.move_t >= 0.45:
                self.heal_done = True
                self.hp = min(self.max_hp, self.hp + m.heal_total)
                game.effects.add_text(self.x, self.feet_y - 96, f"+{int(m.heal_total)}",
                                      (130, 255, 150), scale=2, life=0.9)
                game.effects.add_ring(self.x, self.feet_y - 50, (140, 240, 160),
                                      radius=8, speed=130, life=0.4, width=2)
                game.audio.play("ui_confirm", 0.4)
        if self.move_t >= m.duration:
            self.state = "idle"
            self.move = None
            self.move_t = 0.0

    # ------------------------------------------------------------------ damage
    def receive_hit(self, damage: float, move: Move, attacker: "Fighter", blocked: bool, game):
        self.last_hit_from = attacker
        if blocked:
            self.vx += move.knockback * 0.28 * attacker.facing
            self.hp = max(0.0, self.hp - damage)
            self.ult = min(self.max_ult, self.ult + damage * 0.25)
            game.effects.add_hit(self.x - 8 * self.facing, self.feet_y - 58,
                                 (160, 210, 255), 0.7, blocked=True)
            game.effects.add_text(self.x, self.feet_y - 78, "BLOCK",
                                  (150, 200, 255), scale=1, life=0.5)
            if self.hp <= 0:
                self._die(attacker, game)
            return

        self.hp = max(0.0, self.hp - damage)
        self.hit_flash = 0.14
        self.ult = min(self.max_ult, self.ult + damage * 0.35)
        if damage >= 8 and self.grunt_cd <= 0 and random.random() < 0.7:
            self.grunt_cd = 0.3
            game.audio.play(f"grunt_{random.randint(1, 10)}", 0.32)
        # Taking a hit interrupts Jotaro's cigarette / DIO's bottle.
        if self.state == "heal":
            self.heal_left = 0.0
            game.effects.add_text(self.x, self.feet_y - 100, "INTERRUPTED!",
                                  (255, 130, 120), scale=1, life=0.7)
        self.state = "hurt"
        self.move = None
        self.move_t = 0.0
        self.hurt_t = move.hitstun
        self.vx += move.knockback * attacker.facing
        self.crouching = False
        self.blocking = False
        game.effects.add_hit(self.x, self.feet_y - 58, (255, 236, 160), 1.2 + damage / 18)
        game.effects.add_text(self.x, self.feet_y - 86, f"{int(damage)}",
                              (255, 220, 120) if damage < 20 else (255, 150, 100),
                              scale=2, life=0.7)
        if self.hp <= 0:
            self._die(attacker, game)

    def _die(self, attacker: "Fighter", game):
        self.state = "ko"
        self.hp = 0.0
        self.ko_timer = 0.0
        self.stand_active = False
        self.vx = 120 * attacker.facing
        game.effects.add_shake(1.0)
        game.effects.add_flash(0.7)
        game.on_ko(self, attacker)
