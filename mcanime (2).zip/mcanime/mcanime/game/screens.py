"""All screens: main menu, character select, fight, settings, info, results."""
from __future__ import annotations

import math
import random

import pygame

from . import font, ui
from .ai import AI
from .config import (
    CHARACTERS, DIFFICULTIES, GAME_H, GAME_W, GOLD, GROUND_Y, PURPLE,
    RED, UI_BG, UI_DIM, UI_TEXT, WHITE, YELLOW,
)
from .effects import Effects
from .fighter import Fighter
from .sprites import draw_fighter, draw_roller, draw_stand


class Screen:
    def __init__(self, game):
        self.game = game
        self.t = 0.0

    def handle_event(self, event):
        pass

    def update(self, dt):
        self.t += dt

    def draw(self, surface):
        pass


# ------------------------------------------------------------------ menu
class MenuScreen(Screen):
    ITEMS = ["FIGHT", "SETTINGS", "INFO", "QUIT"]

    def __init__(self, game):
        super().__init__(game)
        self.selected = 0
        self.game.audio.music("bgm_menu")
        self.game.audio.set_duck(1.0)
        self.p1 = Fighter("jotaro", 76, 1)
        self.p1.stand_active = True
        self.p1.stand_alpha = 1.0
        self.p2 = Fighter("dio", 404, -1)
        self.p2.stand_active = True
        self.p2.stand_alpha = 1.0
        self.item_rects = []

    def _item_rects(self):
        y = 120
        w = 210
        return [(GAME_W // 2 - w // 2, y + i * 26 - 9, w, 22) for i in range(len(self.ITEMS))]

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_w, pygame.K_UP):
                self.selected = (self.selected - 1) % len(self.ITEMS)
                self.game.audio.play("ui_move", 0.5)
            elif event.key in (pygame.K_s, pygame.K_DOWN):
                self.selected = (self.selected + 1) % len(self.ITEMS)
                self.game.audio.play("ui_move", 0.5)
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_z):
                self._activate()
        elif event.type == pygame.MOUSEMOTION:
            pos = self.game.mouse_pos()
            if pos:
                for i, r in enumerate(self._item_rects()):
                    if pygame.Rect(*r).collidepoint(pos) and i != self.selected:
                        self.selected = i
                        self.game.audio.play("ui_move", 0.4)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = self.game.mouse_pos()
            if pos:
                for i, r in enumerate(self._item_rects()):
                    if pygame.Rect(*r).collidepoint(pos):
                        self.selected = i
                        self._activate()
                        break

    def _activate(self):
        self.game.audio.play("ui_confirm", 0.7)
        if self.selected == 0:
            self.game.set_screen(SelectScreen(self.game))
        elif self.selected == 1:
            self.game.set_screen(SettingsScreen(self.game))
        elif self.selected == 2:
            self.game.set_screen(InfoScreen(self.game))
        else:
            self.game.quit()

    def update(self, dt):
        super().update(dt)
        self.p1.anim_t += dt
        self.p2.anim_t += dt
        self.p1.stand_alpha = 1.0
        self.p2.stand_alpha = 1.0

    def draw(self, surface):
        self.game.stage.draw(surface, self.t)
        overlay = pygame.Surface((GAME_W, GAME_H), pygame.SRCALPHA)
        overlay.fill((6, 4, 14, 112))
        surface.blit(overlay, (0, 0))

        # fighters flanking the menu
        draw_stand(surface, self.p1, self.t)
        draw_stand(surface, self.p2, self.t)
        draw_fighter(surface, self.p1, self.t)
        draw_fighter(surface, self.p2, self.t)

        ui.draw_logo(surface, GAME_W // 2, 22, self.t)
        ui.draw_menu_list(surface, self.ITEMS, self.selected, GAME_W // 2, 120,
                          spacing=26, t=self.t, width=210, accent=GOLD)
        font.draw_text(surface, "W/S  SELECT      ENTER  CONFIRM", GAME_W // 2, 238, 1,
                       UI_DIM, align="center")
        font.draw_text(surface, "A FAN-MADE JOJO FIGHTER", GAME_W // 2, 252, 1,
                       (120, 104, 140), align="center")
        ui.scanlines(surface, 20, 3)


# ------------------------------------------------------------------ select
class SelectScreen(Screen):
    def __init__(self, game):
        super().__init__(game)
        self.chars = ["jotaro", "dio"]
        self.selected = 0 if getattr(game, "last_character", "jotaro") == "jotaro" else 1
        self.game.audio.music("bgm_menu")
        self.game.audio.set_duck(1.0)
        self.cards = [(38, 52, 190, 184), (252, 52, 190, 184)]

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_a, pygame.K_LEFT):
                self.selected = 0
                self.game.audio.play("ui_move", 0.5)
            elif event.key in (pygame.K_d, pygame.K_RIGHT):
                self.selected = 1
                self.game.audio.play("ui_move", 0.5)
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_z):
                self._start()
            elif event.key == pygame.K_ESCAPE:
                self.game.set_screen(MenuScreen(self.game))
        elif event.type == pygame.MOUSEMOTION:
            pos = self.game.mouse_pos()
            if pos:
                for i, r in enumerate(self.cards):
                    if pygame.Rect(*r).collidepoint(pos) and i != self.selected:
                        self.selected = i
                        self.game.audio.play("ui_move", 0.4)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = self.game.mouse_pos()
            if pos:
                for i, r in enumerate(self.cards):
                    if pygame.Rect(*r).collidepoint(pos):
                        if i == self.selected:
                            self._start()
                        else:
                            self.selected = i
                            self.game.audio.play("ui_move", 0.4)

    def _start(self):
        self.game.audio.play("ui_confirm", 0.8)
        player = self.chars[self.selected]
        enemy = self.chars[1 - self.selected]
        self.game.set_screen(FightScreen(self.game, player, enemy))

    def draw(self, surface):
        self.game.stage.draw(surface, self.t)
        overlay = pygame.Surface((GAME_W, GAME_H), pygame.SRCALPHA)
        overlay.fill((5, 4, 12, 196))
        surface.blit(overlay, (0, 0))
        font.draw_text(surface, "CHOOSE YOUR STAND", GAME_W // 2, 14, 2, GOLD,
                       shadow=(0, 0, 0), outline=(20, 10, 30), align="center")
        font.draw_text(surface, "THE OTHER FIGHTER BECOMES YOUR CPU OPPONENT", GAME_W // 2, 33, 1,
                       UI_DIM, align="center")
        for i, (x, y, w, h) in enumerate(self.cards):
            ch = self.chars[i]
            cfg = CHARACTERS[ch]
            ui.draw_character_card(surface, x, y, w, h, ch, cfg, i == self.selected, self.t)
            tag = "P1" if i == self.selected else "CPU"
            col = GOLD if i == self.selected else UI_DIM
            font.draw_text(surface, tag, x + 8, y + 8, 1, col, shadow=(0, 0, 0))
        diff = self.game.settings["difficulty"]
        font.draw_text(surface, f"DIFFICULTY: {diff}", GAME_W // 2, 242, 1, UI_DIM, align="center")
        font.draw_text(surface, "A/D  SELECT      ENTER  FIGHT      ESC  BACK", GAME_W // 2, 254, 1,
                       UI_TEXT, align="center")
        ui.scanlines(surface, 18, 3)


# ------------------------------------------------------------------ settings
class SettingsScreen(Screen):
    def __init__(self, game):
        super().__init__(game)
        self.selected = 0
        self.rows = 6

    def _change(self, direction):
        s = self.game.settings
        if self.selected == 0:
            s["music"] = max(0.0, min(1.0, round(s["music"] + 0.1 * direction, 2)))
            self.game.audio.apply_volumes()
        elif self.selected == 1:
            s["sfx"] = max(0.0, min(1.0, round(s["sfx"] + 0.1 * direction, 2)))
        elif self.selected == 2:
            keys = list(DIFFICULTIES)
            idx = keys.index(s["difficulty"])
            s["difficulty"] = keys[(idx + direction) % len(keys)]
        elif self.selected == 3:
            s["fullscreen"] = not s["fullscreen"]
            self.game.apply_display()
        elif self.selected == 4:
            s["screen_shake"] = not s["screen_shake"]
        elif self.selected == 5:
            s["show_hints"] = not s["show_hints"]
        self.game.audio.play("ui_move", 0.5)
        self.game.save_settings()

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_w, pygame.K_UP):
                self.selected = (self.selected - 1) % self.rows
                self.game.audio.play("ui_move", 0.4)
            elif event.key in (pygame.K_s, pygame.K_DOWN):
                self.selected = (self.selected + 1) % self.rows
                self.game.audio.play("ui_move", 0.4)
            elif event.key in (pygame.K_a, pygame.K_LEFT):
                self._change(-1)
            elif event.key in (pygame.K_d, pygame.K_RIGHT):
                self._change(1)
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                if self.selected >= 3:
                    self._change(1)
            elif event.key == pygame.K_ESCAPE:
                self.game.audio.play("ui_click", 0.6)
                self.game.set_screen(MenuScreen(self.game))

    def draw(self, surface):
        self.game.stage.draw(surface, self.t)
        ui.draw_settings(surface, self.game.settings, self.selected, None, self.t)
        ui.scanlines(surface, 18, 3)


# ------------------------------------------------------------------ info
class InfoScreen(Screen):
    def __init__(self, game):
        super().__init__(game)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key in (
            pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_SPACE
        ):
            self.game.audio.play("ui_click", 0.6)
            self.game.set_screen(MenuScreen(self.game))

    def draw(self, surface):
        self.game.stage.draw(surface, self.t)
        ui.draw_info(surface, self.t)
        ui.scanlines(surface, 20, 3)


# ------------------------------------------------------------------ fight
class Roller:
    def __init__(self, owner, target_x, move):
        self.owner = owner
        self.x = target_x
        self.y = -80.0
        self.vy = 0.0
        self.move = move
        self.landed = False
        self.land_t = 0.0
        self.hit = False

    def update(self, dt, game, defender):
        if not self.landed:
            self.vy += 1600 * dt
            self.y += self.vy * dt
            if self.y >= GROUND_Y - 54:
                self.y = GROUND_Y - 54
                self.landed = True
                game.roller_impact(self, defender)
        else:
            self.land_t += dt

    def draw(self, surface):
        # growing shadow
        if not self.landed:
            k = max(0.0, min(1.0, (self.y + 80) / (GROUND_Y - 54 + 80)))
            w = int(20 + 46 * k)
            shadow = pygame.Surface((w, 8), pygame.SRCALPHA)
            pygame.draw.ellipse(shadow, (0, 0, 0, int(60 + 90 * k)), (0, 0, w, 8))
            surface.blit(shadow, (int(self.x - w / 2), int(GROUND_Y - 5)))
        draw_roller(surface, self.x - 48, self.y, 1.0,
                    flash=0.0 if not self.landed else max(0.0, 0.2 - self.land_t))


class FightScreen(Screen):
    def __init__(self, game, player_char="jotaro", enemy_char="dio"):
        super().__init__(game)
        game.last_character = player_char
        self.player = Fighter(player_char, 152, 1, is_ai=False)
        self.enemy = Fighter(enemy_char, 328, -1, is_ai=True)
        self.ai = AI(self.enemy, game.settings["difficulty"])
        self.enemy.ai = self.ai
        self.effects = Effects()
        self.audio = game.audio
        self.world = pygame.Surface((GAME_W, GAME_H))
        self.vignette = pygame.Surface((GAME_W, GAME_H), pygame.SRCALPHA)
        for i in range(14):
            a = int(46 * (1 - i / 14))
            pygame.draw.rect(self.vignette, (0, 0, 0, a),
                             (i * 2, i * 2, GAME_W - i * 4, GAME_H - i * 4), 2)

        self.phase = "intro"
        self.phase_t = 2.6
        self.fight_announced = False
        self.time_left = 99.0
        self.combo = 0
        self.combo_timer = 0.0
        self.combo_owner = None
        self.player_ghost = 100.0
        self.enemy_ghost = 100.0

        self.hitstop = 0.0
        self.time_stop_owner: Fighter | None = None
        self.time_stop_timer = 0.0
        self.time_stop_duration = 3.0
        self.tick_timer = 0.0

        self.paused = False
        self.pause_selected = 0
        self.results_selected = 0
        self.winner: Fighter | None = None
        self.rollers: list[Roller] = []
        self.banner = None
        self.hint_timer = 9.0 if game.settings["show_hints"] else 0.0
        self.ko_played = False
        self.music_started = False

        self.game.audio.music("bgm_fight")
        self.game.audio.set_duck(1.0)

    # ------------------------------------------------------------- helpers
    def opponent_of(self, f):
        return self.enemy if f is self.player else self.player

    def is_frozen(self, f):
        return self.time_stop_owner is not None and self.time_stop_owner is not f

    def show_banner(self, title, sub="", color=GOLD, scale=4, duration=0.9):
        self.banner = {"title": title, "sub": sub, "color": color,
                       "scale": scale, "t": duration, "max": duration}

    # ------------------------------------------------------------- time stop
    def start_time_stop(self, owner):
        self.time_stop_owner = owner
        self.time_stop_timer = self.time_stop_duration
        self.tick_timer = 0.0
        self.game.audio.set_duck(0.22)
        self.game.audio.ultimate_voice("za_warudo" if owner.character == "dio" else "star_platinum_world", 1.0)
        self.game.audio.play("metal_clang", 0.5)
        self.effects.add_flash(0.85)
        self.effects.add_shake(1.0)
        self.effects.add_ring(owner.x, owner.feet_y - 60, (180, 150, 255),
                              radius=10, speed=420, life=0.6, width=3)

    def end_time_stop(self):
        owner = self.time_stop_owner
        self.time_stop_owner = None
        self.time_stop_timer = 0.0
        self.game.audio.set_duck(1.0)
        self.game.audio.voice("time_resume", 0.85)
        self.effects.add_flash(0.35)
        self.effects.add_ring(self.player.x if owner is self.player else self.enemy.x,
                              GROUND_Y - 50, (255, 255, 255), radius=20, speed=300,
                              life=0.4, width=2)
        self.show_banner("TIME RESUMES", "", WHITE, 2, 0.8)

    # ------------------------------------------------------------- damage
    def try_hit(self, attacker, defender, move):
        if defender.state == "ko":
            return
        hb = attacker.hitbox(move)
        hurt = defender.hurtbox()
        if not hb.colliderect(hurt):
            return
        frozen = self.is_frozen(defender)
        facing_each_other = defender.facing == -attacker.facing
        blocked = (defender.blocking and facing_each_other and not frozen
                   and move.special != "unblockable")
        if move.unblockable:
            blocked = False
        damage = move.damage * (move.block_ratio if blocked else 1.0)
        self._land_hit(attacker, defender, move, blocked, damage,
                       hb.centerx, hurt.centery)

    def _land_hit(self, attacker, defender, move, blocked, damage, hx, hy):
        if self.combo_timer <= 0 or self.combo_owner is not attacker:
            self.combo = 0
        if not blocked:
            self.combo += 1
            self.combo_owner = attacker
            self.combo_timer = 1.35
        # damage scaling on long combos
        if not blocked and self.combo > 5:
            damage *= 0.8
        defender.receive_hit(damage, move, attacker, blocked, self)
        if not blocked:
            attacker.ult = min(attacker.max_ult, attacker.ult + move.meter_gain)
        self.hitstop = max(self.hitstop, move.hitstop)
        if blocked:
            self.game.audio.play("metal_clang", 0.55)
            self.game.audio.play("kick_medium", 0.25)
        else:
            if move.special != "roller":
                self.game.audio.play(move.sound, 0.95)
            if move.damage >= 13:
                self.game.audio.play("thud", 0.35)
        if move.key == "star_finger":
            self.effects.add_text(defender.x, defender.feet_y - 106, "STAR FINGER",
                                  (120, 240, 255), scale=1, life=0.7)
        if move.key == "road_roller":
            self.effects.add_shake(1.0)

    def spawn_roller(self, owner, move):
        target = self.opponent_of(owner)
        self.rollers.append(Roller(owner, target.x, move))
        self.game.audio.play("whoosh", 0.7)
        self.game.audio.play("metal_clang", 0.45)
        self.effects.add_ring(target.x, GROUND_Y - 8, (255, 210, 100),
                              radius=6, speed=180, life=0.5, width=2)
        self.effects.add_text(target.x, GROUND_Y - 108, "!", (255, 90, 80),
                              scale=3, life=0.9, vy=-8)

    def roller_impact(self, roller, defender):
        self.game.audio.play("roller_impact_1", 1.0)
        self.game.audio.play("roller_impact_2", 0.8)
        self.effects.add_dust(roller.x, GROUND_Y - 2, 28, (200, 168, 120), 1.8)
        self.effects.add_shake(1.0)
        self.effects.add_flash(0.4)
        self.effects.add_ring(roller.x, GROUND_Y - 18, (255, 220, 140),
                              radius=10, speed=260, life=0.45, width=3)
        if roller.hit or defender.state == "ko":
            return
        if abs(defender.x - roller.x) < 62 and defender.jump_y < 40:
            roller.hit = True
            blocked = defender.blocking and defender.facing == -roller.owner.facing
            damage = roller.move.damage * (roller.move.block_ratio if blocked else 1.0)
            self._land_hit(roller.owner, defender, roller.move, blocked, damage,
                           defender.x, defender.feet_y - 40)
        else:
            self.effects.add_text(roller.x, GROUND_Y - 70, "MISSED",
                                  (180, 180, 190), scale=2, life=0.8)

    # ------------------------------------------------------------- events
    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return
        if self.phase == "results":
            if event.key in (pygame.K_w, pygame.K_UP):
                self.results_selected = (self.results_selected - 1) % 3
                self.game.audio.play("ui_move", 0.5)
            elif event.key in (pygame.K_s, pygame.K_DOWN):
                self.results_selected = (self.results_selected + 1) % 3
                self.game.audio.play("ui_move", 0.5)
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.game.audio.play("ui_confirm", 0.8)
                if self.results_selected == 0:
                    self.game.set_screen(FightScreen(self.game, self.player.character, self.enemy.character))
                elif self.results_selected == 1:
                    self.game.set_screen(SelectScreen(self.game))
                else:
                    self.game.set_screen(MenuScreen(self.game))
            return

        if self.paused:
            if event.key in (pygame.K_w, pygame.K_UP):
                self.pause_selected = (self.pause_selected - 1) % 3
                self.game.audio.play("ui_move", 0.5)
            elif event.key in (pygame.K_s, pygame.K_DOWN):
                self.pause_selected = (self.pause_selected + 1) % 3
                self.game.audio.play("ui_move", 0.5)
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.game.audio.play("ui_confirm", 0.8)
                if self.pause_selected == 0:
                    self.paused = False
                    self.game.audio.set_duck(0.22 if self.time_stop_owner else 1.0)
                elif self.pause_selected == 1:
                    self.game.set_screen(FightScreen(self.game, self.player.character, self.enemy.character))
                else:
                    self.game.set_screen(MenuScreen(self.game))
            elif event.key == pygame.K_ESCAPE:
                self.paused = False
                self.game.audio.set_duck(0.22 if self.time_stop_owner else 1.0)
            return

        if event.key == pygame.K_ESCAPE:
            self.paused = True
            self.pause_selected = 0
            self.game.audio.set_duck(0.35)
            self.game.audio.play("ui_click", 0.6)
            return

        if self.phase != "fight" or self.is_frozen(self.player):
            return
        if event.key == pygame.K_z:
            self.player.try_attack("z", self)
        elif event.key == pygame.K_x:
            self.player.try_attack("x", self)
        elif event.key == pygame.K_c:
            self.player.try_attack("c", self)
        elif event.key == pygame.K_q:
            self.player.try_toggle_stand(self)
        elif event.key == pygame.K_r:
            if self.player.try_ult(self):
                pass
            elif self.player.ult < self.player.max_ult:
                self.game.audio.play("ui_click", 0.35)
        elif event.key == pygame.K_w:
            self.player.jump_requested = True

    # ------------------------------------------------------------- update
    def update(self, dt):
        self.t += dt
        if self.banner:
            self.banner["t"] -= dt
            if self.banner["t"] <= 0:
                self.banner = None
        if self.paused:
            return
        if self.phase == "results":
            self.effects.update(dt)
            return

        if self.phase == "intro":
            self.phase_t -= dt
            if not self.fight_announced and self.phase_t <= 1.1:
                self.fight_announced = True
                self.game.audio.play("announcer_fight", 0.9)
                self.show_banner("FIGHT!", "", GOLD, 5, 0.8)
            if self.phase_t <= 0:
                self.phase = "fight"
            self.effects.update(dt)
            return

        # hitstop freezes the action for a few frames
        if self.hitstop > 0:
            self.hitstop = max(0.0, self.hitstop - dt)
            self.effects.update(dt * 0.35)
            self._update_ghosts(dt)
            return

        # fight / ko
        if self.phase == "fight":
            self.time_left -= dt
            if self.time_left <= 0:
                self.time_left = 0
                self._time_up()
                return
            self.hint_timer = max(0.0, self.hint_timer - dt)
            self._player_inputs()
            self._update_ai(dt)
        else:
            # freeze player input once the round is decided
            self.player.input_x = 0
            self.player.input_block = False
            self.enemy.input_x = 0
            self.enemy.input_block = False
            self.phase_t -= dt
            if self.phase_t <= 0 and not self.ko_played:
                self._finish_match()
                return

        # time stop countdown
        if self.time_stop_owner is not None:
            self.time_stop_timer -= dt
            self.tick_timer -= dt
            if self.tick_timer <= 0:
                self.tick_timer = 0.5
                self.game.audio.play("ui_click", 0.18)
            if self.time_stop_timer <= 0:
                self.end_time_stop()

        # fighters
        frozen_player = self.is_frozen(self.player)
        frozen_enemy = self.is_frozen(self.enemy)
        if not frozen_player:
            self.player.update(dt, self.enemy, self, frozen=False)
        if not frozen_enemy:
            self.enemy.update(dt, self.player, self, frozen=False)
        if self.phase == "fight":
            self._separate()

        for r in list(self.rollers):
            r.update(dt, self, self.enemy if r.owner is self.player else self.player)
        self.rollers = [r for r in self.rollers if not r.landed or r.land_t < 1.2]

        if self.combo_timer > 0:
            self.combo_timer -= dt
            if self.combo_timer <= 0:
                self.combo = 0
        self._update_ghosts(dt)
        self.effects.update(dt)
        if not self.game.settings["screen_shake"]:
            self.effects.trauma = 0.0

    def _player_inputs(self):
        keys = pygame.key.get_pressed()
        if self.is_frozen(self.player):
            self.player.input_x = 0
            self.player.input_block = False
            self.player.jump_requested = False
            return
        left = keys[pygame.K_a]
        right = keys[pygame.K_d]
        crouch = keys[pygame.K_s]
        dx = (1 if right else 0) - (1 if left else 0)
        back_key = left if self.player.facing == 1 else right
        dist = abs(self.enemy.x - self.player.x)
        threat = dist < 105 or self.enemy.state == "attack"
        self.player.input_x = dx
        self.player.input_crouch = crouch
        self.player.input_block = back_key and threat
        if back_key and not threat:
            self.player.input_x = -self.player.facing
        if self.player.input_block:
            self.player.input_x = 0

    def _update_ai(self, dt):
        if self.is_frozen(self.enemy):
            self.enemy.input_x = 0
            self.enemy.input_block = False
            self.enemy.jump_requested = False
            return
        self.ai.update(dt, self.player, self)

    def _separate(self):
        a, b = self.player, self.enemy
        if a.state == "ko" or b.state == "ko":
            return
        dx = b.x - a.x
        if abs(dx) >= 46:
            return
        push = (46 - abs(dx)) / 2
        sign = 1 if dx >= 0 else -1
        a_frozen = self.is_frozen(a)
        b_frozen = self.is_frozen(b)
        if a_frozen and b_frozen:
            return
        if a_frozen:
            # Never move a frozen fighter: shove the active one instead.
            b.x += push * 2 * sign
        elif b_frozen:
            a.x -= push * 2 * sign
        else:
            a.x -= push * sign
            b.x += push * sign
        a._clamp_x()
        b._clamp_x()

    def _update_ghosts(self, dt):
        if self.player_ghost > self.player.hp:
            self.player_ghost = max(self.player.hp, self.player_ghost - 34 * dt)
        else:
            self.player_ghost = self.player.hp
        if self.enemy_ghost > self.enemy.hp:
            self.enemy_ghost = max(self.enemy.hp, self.enemy_ghost - 34 * dt)
        else:
            self.enemy_ghost = self.enemy.hp

    # ------------------------------------------------------------- outcomes
    def on_ko(self, loser, winner):
        if self.phase != "fight":
            return
        self.winner = winner
        self.phase = "ko"
        self.phase_t = 3.2
        self.hitstop = 0.0
        self.time_stop_owner = None
        self.game.audio.set_duck(0.55)
        self.game.audio.play("announcer_game_over", 0.7)
        self.show_banner("K.O.", f"{winner.cfg['full']} WINS", RED, 5, 2.2)
        if winner.character == "dio":
            self.game.audio.voice("wryyy", 0.9)
        else:
            self.game.audio.voice("yare_yare", 0.9)

    def _time_up(self):
        self.winner = self.player if self.player.hp >= self.enemy.hp else self.enemy
        self.phase = "ko"
        self.phase_t = 2.6
        self.show_banner("TIME UP", f"{self.winner.cfg['full']} WINS", YELLOW, 4, 2.0)
        self.game.audio.play("announcer_game_over", 0.7)

    def _finish_match(self):
        self.ko_played = True
        self.phase = "results"
        self.results_selected = 0
        self.game.audio.set_duck(0.75)
        if self.winner is self.player:
            self.game.audio.play("announcer_you_win", 0.9)
            self.game.audio.voice("yare_yare" if self.player.character == "jotaro" else "wryyy", 0.9)
        else:
            self.game.audio.play("announcer_you_lose", 0.9)

    # ------------------------------------------------------------- draw
    def draw(self, surface):
        frozen = self.time_stop_owner is not None
        self.game.stage.draw(self.world, self.t, frozen=frozen)
        # shadows
        for f in (self.player, self.enemy):
            sh = pygame.Surface((42, 9), pygame.SRCALPHA)
            pygame.draw.ellipse(sh, (0, 0, 0, 95), (0, 0, 42, 9))
            self.world.blit(sh, (int(f.x - 21), int(GROUND_Y - 4)))

        fighters = sorted((self.player, self.enemy), key=lambda f: f.x)
        for f in fighters:
            attacking = (f.state == "attack" and f.move is not None
                         and f.move.key in ("ora", "muda", "ora_kick",
                                            "muda_kick", "star_finger"))
            if f.stand_alpha > 0 and not attacking:
                draw_stand(self.world, f, self.t)
            draw_fighter(self.world, f, self.t)
            if f.stand_alpha > 0 and attacking:
                draw_stand(self.world, f, self.t)
            if self.is_frozen(f):
                ui.draw_frozen_aura(self.world, f, self.t)

        for r in self.rollers:
            r.draw(self.world)
        self.effects.draw(self.world)
        self.effects.draw_flash(self.world)

        ox, oy = self.effects.get_shake()
        surface.fill((0, 0, 0))
        surface.blit(self.world, (ox, oy))
        surface.blit(self.vignette, (0, 0))

        if self.time_stop_owner is not None:
            ui.draw_time_stop(surface, self.time_stop_owner, max(0.0, self.time_stop_timer),
                              self.time_stop_duration, self.t)

        ui.draw_hud(surface, self.player, self.enemy, self.time_left, self.combo,
                    self.combo_owner, self.player_ghost, self.enemy_ghost,
                    show_hints=(self.hint_timer > 0 and self.time_stop_owner is None
                                and self.phase == "fight" and not self.paused),
                    hint_alpha=int(255 * min(1.0, self.hint_timer / 1.5)))

        if self.phase == "intro" and self.phase_t > 1.15:
            ui.draw_banner(surface, "ROUND 1", "JOTARO KUJO  VS  DIO BRANDO", GOLD, 4, 92)

        if self.banner:
            a = min(1.0, self.banner["t"] / 0.3)
            col = tuple(int(c * (0.45 + 0.55 * a)) for c in self.banner["color"])
            ui.draw_banner(surface, self.banner["title"], self.banner["sub"],
                           col, self.banner["scale"], 118)

        if self.paused:
            ui.draw_pause(surface, self.pause_selected, self.t)
        elif self.phase == "results" and self.winner:
            ui.draw_results(surface, self.player, self.enemy, self.winner,
                            self.results_selected, self.t)
        ui.scanlines(surface, 14, 3)
