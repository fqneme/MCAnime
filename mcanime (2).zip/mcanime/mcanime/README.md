# STAND BATTLE: STARDUST SHOWDOWN

A small, complete 2D pixel-art fighting game inspired by **Mortal Kombat** and
**JoJo's Bizarre Adventure**. Two fighters, two Stands, one stopped clock.

![Main menu](shots/01_menu.png)

| Character select | Stand rush |
|---|---|
| ![Select](shots/02_select.png) | ![ORA](shots/04_ora.png) |

| Time stop | Road roller |
|---|---|
| ![Time stop](shots/07_time_stop.png) | ![Road roller](shots/06_road_roller.png) |

---

## Quick start

```bash
python -m pip install -r requirements.txt
python main.py
```

* Python 3.10+ (tested on 3.13)
* `pygame-ce` 2.5+ and `numpy`
* Windows, Linux or macOS. The window uses an internal **480x270** canvas scaled
  with nearest-neighbour pixels, so the art stays crunchy at any size.
* `F11` toggles fullscreen. Settings are saved to `settings.json`.

On Windows you can also double-click `run.bat`.

---

## Controls

| Key | Action |
| --- | --- |
| `W` | Jump |
| `A` / `D` | Move left / right |
| `S` | Crouch |
| `Z` | Light punch (Stand version when the Stand is out) |
| `X` | Light kick (Stand version when the Stand is out) |
| `C` | Character utility / heal (Stand version when the Stand is out) |
| `Q` | Summon / dismiss Stand |
| `R` | Time Stop ultimate (needs a full meter **and** the Stand out) |
| `Esc` | Pause |

**Blocking:** hold **back** (away from your opponent). The CPU blocks the same
way, and can cancel its own startup into a guard.

---

## Characters

### Jotaro Kujo — Star Platinum

| Slot | Base | Stand out |
| --- | --- | --- |
| `Z` | Light punch (5) | **ORA ORA!** — 5 rapid hits (20 total), 2.6s cooldown |
| `X` | Light kick (8) | **ORA!** — heavy kick (13) + strong pushback |
| `C` | **Cigarette** — heals 18 over 3s, but locks Jotaro in place and any hit interrupts it. 9s cooldown | **Star Finger** — 15 damage at up to 178px, 4s cooldown |
| `R` | — | **Star Platinum: The World** — freezes the opponent for 3s |

### DIO — The World

| Slot | Base | Stand out |
| --- | --- | --- |
| `Z` | Light punch (5) | **MUDA MUDA!** — 6 rapid hits (30 total), 3s cooldown |
| `X` | Light kick (8) | **MUDA!** — heavy kick (14) + strong pushback |
| `C` | **Blood bottle** — instantly restores 26 HP after a short drink. 13s cooldown | **ROAD ROLLER DA!** — long wind-up, then a steamroller falls for 34 damage in an area. 14s cooldown |
| `R` | — | **ZA WARUDO! TOKI WO TOMARE!** — freezes the opponent for 3s |

### Ultimate / Time Stop

* The ultimate meter fills passively (2.6/s) and from dealing/taking damage.
* `R` only works with **100% meter** and the Stand summoned.
* During the 3 seconds of stopped time the opponent is completely frozen
  (state machine, animation, physics and input all pause), the stage freezes,
  the music ducks and the owner can land a free combo.
* The HUD shows the meter, a flashing **R TIME STOP READY** prompt, Stand state
  and the utility cooldown.

---

## The CPU

A compact state machine in `game/ai.py`:

```
approach -> attack -> block -> retreat -> summon / special / heal
```

It walks toward the player, guards on reaction (difficulty-dependent), spaces
itself, uses Stand specials at the right range, heals when low, and will pop its
own Time Stop when its meter is full. Difficulty changes reaction time, guard
chance and aggression:

* `EASY` — slow reactions, rare blocks
* `NORMAL` — the default
* `HARD` — fast guard reactions, aggressive spacing, frequent specials

---

## Project structure

```
main.py                 entry point
game/
  app.py                window, fixed canvas scaling, main loop, settings
  config.py             resolution, palette, character metadata, difficulties
  font.py               hand-made 5x7 bitmap font (pixel-perfect UI)
  audio.py              CC0 loader, runtime pitch variants, music, voice cues
  art.py                sprite loading, Stand tinting, code-driven animation
  moves.py              every move's frame data and damage
  fighter.py            fighter state machine, heals, damage, Stand toggle
  ai.py                 CPU state machine
  sprites.py            sprite-based drawing + procedural fallback, props
  stage.py              Cairo rooftop stage
  effects.py            particles, sparks, floating text, shake, hitstop visuals
  ui.py                 HUD, menus, cards, time-stop overlay, results
  screens.py            menu / select / fight / settings / info screens
assets/characters/      imported sprites, Stand art and portraits
assets/audio/           40 CC0 samples & music loops + 13 processed voice cues
tools/
  build_sprites.py      split/de-halo/downscale source art into game sprites
  gen_voice.py          regenerate the voice cues (edge-tts + numpy processing)
  screenshot.py         headless screenshot harness (shots/*.png)
  anim_strip.py         renders animation strips + prints transform samples
  simtest.py            full-match regression test
  mechtest.py           blocking / timeout / AI ult / heal checks
  apptest.py            drives the real app loop headlessly
  flowtest.py           menu -> select -> fight -> results -> rematch flow
  test_asset_layouts.py checks opaque single-file imports + background removal
shots/                  captured screenshots
```

---

## Character art and animation

The fighters and Stands are real imported sprites, animated entirely in code —
no hand-drawn animation frames.

### 1. Importing the art

Drop your source images in `assets/characters/` using either layout:

```
assets/characters/jotaro.png          # one file per character (any background)
assets/characters/dio.png
assets/characters/star_platinum.png
assets/characters/the_world.png
```

or keep the 4x3 reference sheet as `assets/characters/jojo_sheet.png`.
Then run the build step once:

```bash
python tools/build_sprites.py
```

It writes game-ready files:

```
assets/characters/jotaro_front.png   jotaro_side.png   jotaro_back.png
assets/characters/dio_front.png      dio_side.png      dio_back.png
assets/characters/star_platinum_*.png, the_world_*.png
assets/characters/jotaro_portrait.png, dio_portrait.png, ...
```

What the build does per figure:

1. **Background removal** — hardens the alpha channel to a 0/255 mask at a
   threshold, kills the light anti-aliasing fringe by darkening near-white
   pixels inside the silhouette, and falls back to a border **flood fill with
   colour tolerance** when the source is fully opaque (e.g. a flat white JPG).
2. **Trim** to the figure's bounding box.
3. **Downscale** to the game's fighter height (96 px) with an area filter,
   followed by an unsharp pass so the palette stays punchy at small sizes.
4. **Palette reduction** (48 colours) so the result reads as crisp pixel art.
5. **Portrait** — a square head-and-shoulders crop saved as `*_portrait.png`.

The runtime is forgiving: if only `jotaro.png` exists, `ArtLibrary` uses it for
every view and auto-scales it, so the game still works without the build step.

### 2. Code-driven animation

All motion comes from `compute_transform()` in `game/art.py`, which returns
`sx`, `sy` (squash/stretch), `angle`, `dx`, `dy` and `alpha` for the current
state. The sprite is then scaled/rotated/flipped from a small cache, so it
costs almost nothing per frame.

| State | Animation |
| --- | --- |
| Idle | sine **bobbing** (`dy = sin(t) * 1.8`), gentle squash `sx 1±0.016`, micro-lean |
| Walk | faster bob, 2.2% counter-squash, swaying lean, small horizontal shift |
| Jump | **stretch** upward (`sy 1.09`) and **squash** on descent, lean into the arc |
| Crouch | strong squash `sx 1.10 / sy 0.80` |
| Block | slight crouch, lean away from the opponent |
| Punch / kick | **squash & stretch** on the active frames (`sx 1.10 / sy 0.94`), forward `dx`, lean, plus a one-frame afterimage |
| ORA / MUDA flurry | 6% stretch with a 62 Hz micro-jitter so the flurry reads as vibration |
| Heal | slow sway and breathing, no attack stretch |
| Hit reaction | **rotation** (`-9°`) + displacement away from the attacker + squash, decaying over the hitstun |
| K.O. | rotates ~72° and drops, settling with a small squash |
| Time stop | arms-up pose with a pulsing stretch |

The attack curve is `attack_curve(move, move_t)`: it ramps up during startup,
holds 1.0 through the active frames, then eases back down during recovery.

### 3. Stands

Stands use their own imported art and are **tinted in code** (`colorize()`), so
they read as summoned spirits rather than recoloured copies:

* **Star Platinum** — purple/violet tint (`(150, 96, 236)`, 40% strength)
* **The World** — pale gold tint (`(255, 224, 132)`, 55% strength)

They are drawn **slightly larger** (×1.10), **floating** above the ground
(`dy = -4 + bob`), and **offset behind** the fighter (`dx = -34 * facing`), with
a soft backlight and a 1px spectral rim. During ORA/MUDA they lunge forward to
the target with two low-alpha afterimages; during Time Stop they hover higher
and larger behind the user.

If only fighter art is available, `ArtLibrary` falls back to a **hue shift** of
the fighter's own sprite (`STAND_HUE`: 205° for Jotaro, 62° for DIO).

### 4. Props drawn in code

* **Star Finger** — a telescoping beam with an outer glow, coloured shaft,
  bright core, marching knuckle segments and a fingertip burst
  (`draw_star_finger_beam`).
* **Road Roller** — a full pixel-art steamroller built from rectangles and
  circles: yellow cab, steel drum with seams, chimney, wheels, rivets and a
  heart emblem, plus a growing ground shadow and landing flash
  (`draw_roller` in `game/sprites.py`).

Both are still drawn procedurally because they need to scale, glow and animate
independently of the character art.

---

## Audio

This project deliberately avoids raw mathematical synthesis for sound effects.

**CC0 sound effects and music — Kenney (kenney.nl), mirrored by gamesounds.xyz:**

* *Impact Sounds* — punches, kicks, metal, wood, footsteps
* *Foley Sounds / Woosh* — attack whooshes
* *UI Audio* — menu clicks and confirms
* *Voiceover Pack Fighter* — announcer ("FIGHT!", results)
* *Music Loops* — `Time Driving` (menu) and `Infinite Descent` (fight)

All of these packs are **Creative Commons Zero (CC0 1.0)**. Attribution is not
required, but it is included here as a thank-you.

**Voice cues** (`assets/audio/voice_*.wav`) are placeholders generated with
Microsoft Edge's neural TTS (`edge-tts`) and then processed locally with numpy:
tape-style pitch shift, tube saturation, slap-back echo and fades. They are not
ripped from the anime and contain no copyrighted audio. Regenerate them with:

```bash
python -m pip install edge-tts
python tools/gen_voice.py
```

The cue list covers **ORA ORA**, **MUDA MUDA**, **ZA WARUDO / Star Platinum: The
World**, **ROAD ROLLER DA**, **STAR FINGER**, **YARE YARE DAZE**, **WRYYYY**,
the two heals and the time-resume line.

> JoJo's Bizarre Adventure is © Hirohiko Araki / Shueisha. This is a
> non-commercial fan project and is not affiliated with the rights holders.
> Replace the placeholder voice lines with recorded or CC0 performances before
> any public release.

---

## Implementation steps / code diff

The build is documented step by step in [`STEPS.md`](STEPS.md) — each step lists
the files added and the key diff hunk (core loop, controls, Stand toggle, time
stop, AI, heals, audio, menus/HUD).

Quick verification suite:

```bash
python tools/simtest.py    # full bot-vs-bot matches + ult/roller assertions
python tools/mechtest.py   # block, timeout, AI ult, heal, jump checks
python tools/apptest.py     # runs the real app loop through every screen
python tools/flowtest.py    # menu -> select -> fight -> results -> menu flow
python tools/screenshot.py # regenerates shots/*.png
```

All three test scripts exit non-zero on failure.
